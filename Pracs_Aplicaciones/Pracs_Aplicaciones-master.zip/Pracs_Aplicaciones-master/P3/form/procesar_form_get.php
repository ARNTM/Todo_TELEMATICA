<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
	<p>
	
		<?php
		
		if(empty($_GET["nombre"]) or empty($_GET["apellidos"]) or empty($_GET["dni"]) or empty($_GET["tipo"])) {echo "No se ha identificado al completo";}
		
		else {echo "Hola " . $_GET["nombre"] ." " .$_GET["apellidos"].  
		"<table>
				<tr>
					<td>Nombre</td>
					<td>Apellidos</td>
					<td>DNI</td>
					<td>PERFIL</td>
				</tr>
				<tr>
					<td>".$_GET["nombre"]."</td>
					<td>".$_GET["apellidos"]."</td>
					<td>".$_GET["dni"]."</td>
					<td>".$_GET["perfil"]."</td>
				</tr>
			</table>";}
		
		?>
	</p>
	
</body>
</html>
