<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
	<p>
		<?php
		
		if(empty($_POST["nombre"]) or empty($_POST["apellidos"]) or empty($_POST["dni"]) or empty($_POST["tipo"])) {echo "No se ha identificado al completo";}
		
				else {echo "Hola " . $_POST["nombre"] ." " .$_POST["apellidos"].  
		"<table>
				<tr>
					<th>Nombre</th>
					<th>Apellidos</th>
					<th>DNI</th>
					<th>PERFIL</th>
				</tr>
				<tr>
					<td>".$_POST["nombre"]."</td>
					<td>".$_POST["apellidos"]."</td>
					<td>".$_POST["dni"]."</td>
					<td>".$_POST["perfil"]."</td>
				</tr>
			</table>";}
		
		?>
	</p>
	
</body>
</html>
