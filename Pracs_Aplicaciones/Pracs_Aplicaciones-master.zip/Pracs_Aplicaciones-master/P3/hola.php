<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
	<h1><?php echo "Hola mundo";?></h1>
</body>
</html>