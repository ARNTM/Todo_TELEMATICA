<?php 
	$hoy = date("Y-m-d H:i:s");
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>La hora</title>
</head>

<body>
	<h1><?php echo $hoy;?></h1>
</body>
</html>