<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Server</title>
</head>

<body>
	<p><pre><?php print_r($_SERVER) ?></pre></p>
</body>
</html>
