<?php 

	if(isset($_COOKIE['descargas'])){
		setcookie('descargas',$_COOKIE['descargas']+1,time()+3600);
	}
	else {
		setcookie('descargas',2,time()+3600);
		if($_COOKIE['descargas'] <= 10){
			echo 'Descarga';
		}
		else {
			echo 'No puedes descargar';
		}
	}

?>