<?php
function conectaBBDD(){

	
	$usuario = 'ai';
	$pwd = 'iKvgOtzRkwJWa5rb';
	$bd="ai";
	$host="localhost";
	$dsn="mysql:$host=localhost;dbname=$bd";
	
	try {
		$conexion = new PDO($dsn,$usuario,$pwd);
	} catch (PDOException $e) {
 		echo 'Error en la conexión: ' . $e->getMessage();
	};

    return $conexion;

}

function getVideos(){
	
	// Nos conectamos con la base de datos
	$conexion=conectaBBDD();
	
	$sentencia="SELECT * FROM VIDEOS";
	$ejecucion=$conexion->query($sentencia);
	$devolver=array();
	
	// Metemos en un array los datos obtenido, como un array asociativo (indice como string)
	while($datos=$ejecucion->fetch(PDO::FETCH_ASSOC)){

		$devolver[]=$datos;
	}	
	
	// Cerramos la conexión
	$ejecucion = null;
	$conexion = null;
	
	return $devolver; 
	
}

function getVideoConcreto($id){
	
	// Nos conectamos con la base de datos
	$conexion=conectaBBDD();
	
	$sentencia="SELECT * FROM VIDEOS WHERE ID='$id'";
	$ejecucion=$conexion->query($sentencia);
	$devolver=array();
	
	// Metemos en un array los datos obtenido, como un array asociativo (indice como string)
	while($datos=$ejecucion->fetch(PDO::FETCH_ASSOC)){

		$devolver=$datos;
	}	
	
	// Cerramos la conexión
	$ejecucion = null;
	$conexion = null;
	
	return $devolver; 
	
}

function insertVideo($titulo,$descripcion,$pais,$foto){
	
	// Nos conectamos con la base de datos
	$conexion=conectaBBDD();
	
	$sentencia="INSERT INTO VIDEOS(TITULO, DESCRIPCION, PAIS, URLFOTO) VALUES ('$titulo','$descripcion','$pais','$foto')";
	$ejecucion=$conexion->query($sentencia);
	if($ejecucion) $devolver='OK';
	else $devolver='NO';
	
	// Cerramos la conexión
	$ejecucion = null;
	$conexion = null;

	return $devolver;
	
}
?>