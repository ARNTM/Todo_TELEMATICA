<?php 

	if(isset($_COOKIE['visita'])){
		setcookie('visita',$_COOKIE['visita']+1,time()+3600);
	}
	else {
		setcookie('visita',2,time()+3600);
	}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Numero de visitas</title>
</head>

<body>
	<p>Esta página ha sido visitada 
		<?php 
			if(isset($_COOKIE['visita'])) echo $_COOKIE['visita'];
			else echo '1';
		?> 
		veces</p>
</body>
</html>