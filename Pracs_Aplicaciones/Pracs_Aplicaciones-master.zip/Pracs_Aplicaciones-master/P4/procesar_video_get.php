<?php
include ("funciones/funciones_sql.php");
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
	<p>
		<?php
		
		if(empty($_GET["titulo"]) or empty($_GET["descripcion"]) or empty($_GET["pais"]) or empty($_GET["imagen"])) { print_r($_GET);
			echo "No se ha identificado al completo";}
		
				else {
					$ok=insertVideo($_GET["titulo"],$_GET["descripcion"],$_GET["pais"],$_GET["imagen"]);
					if($ok='OK') echo 'Insertado correctamente';
						else echo 'Error al insertar';
				}
		
		?>
	</p>
	
</body>
</html>
