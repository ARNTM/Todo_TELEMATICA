<?php
include ("funciones/funciones_sql.php");
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
	<p>
		<?php
		if(empty($_POST["titulo"]) or empty($_POST["descripcion"]) or empty($_POST["pais"]) or empty($_FILES["imagen"])) {
			print_r($_POST);
			echo "No se ha identificado al completo";}
		
				else {
					$target_dir = "img/";
					$target_file = $target_dir . basename($_FILES["imagen"]["name"]);
					$sube = true;
					$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
					
					if (file_exists($target_file)) {
  						echo "Ya hay una foto con el mismo nombre. ";
  						$sube = false;
					}
					
					if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
  						echo "Formato no válido. ";
						$sube = false;
					}
					
					if ($sube){
						move_uploaded_file($_FILES["imagen"]["tmp_name"], $target_file);
						$ok=insertVideo($_POST["titulo"],$_POST["descripcion"],$_POST["pais"],$target_file);
						if($ok='OK') echo 'Insertado correctamente';
						else echo 'Error al insertar';
					}
					
				}
		
		?>
	</p>
	
</body>
</html>
