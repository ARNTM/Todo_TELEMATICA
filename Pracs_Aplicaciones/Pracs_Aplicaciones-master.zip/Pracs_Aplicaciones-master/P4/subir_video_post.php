<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
</head>

<body>
	
	<form method="POST" action="procesar_video_post.php" enctype="multipart/form-data">
		<p>Titulo: <input type="text" id="titulo" name="titulo" size="40"></p>
		<p>Descripcion: <input type="text" id="descripcion" name="descripcion" size="40"></p>
		<p>País: <input type="text" id="pais" name="pais" size="40"></p>
		<p>Foto: <input type="file" id="imagen" name="imagen" size="40"></p>
		<p>
			<input type="submit" value="Enviar">
			<input type="reset" value="Borrar">
		</p>
	</form>
</body>
</html>

