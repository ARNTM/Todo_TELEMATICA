<?php 
	include ("funciones/funciones_sql.php");
header("Content-Type: text/html;charset=utf-8");
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Videos</title>
</head>
	<body>
		<table>
			
				<?php 
				if(empty($_GET["id"])){echo "No hay ID";}
				else {
					$video = getVideoConcreto($_GET['id']);
					if($video == null) {
						echo "No hay peliculas con esa ID";
					}
					else{
						$devolver = '	
							<tr>
								<th>FOTO</th>
								<th>TITULO</th>
								<th>PAIS</th>
								<th>DESCRIPCION</th>
							</tr>
							<tr>
								<td><img src="'.$video['urlfoto'].'" width="100" height="100"></td>
								<td>'.$video['titulo'].'</td>
								<td>'.$video['pais'].'</td>
								<td>'.$video['descripcion'].'</td>
							</tr>
							';
						echo $devolver;
					}
				}
 
				?>

		</table>
	<form method="POST" action="procesar_video_post.php" enctype="multipart/form-data">
								<p>Nombre: <input type="text" id="titulo" name="titulo" size="40"></p>
								<p>Comentario: <input type="text" id="descripcion" name="descripcion" size="40"></p>
								<p>
									<input type="submit" value="Enviar">
									<input type="reset" value="Borrar">
								</p>
							</form>
	</body>
</html>