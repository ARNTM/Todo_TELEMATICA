<?php 
	include ("funciones/funciones_sql.php");
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Videos</title>
</head>
	<body>
		<table>
			<tr>
				<th>FOTO</th>
				<th>TITULO</th>
				<th>PAIS</th>
				<th>VER COMPLETO</th>
			</tr>

				<?php 
				$videos = getVideos();
				foreach ($videos as $video) {

					$devolver = '
					<tr>
						<td><img src="'.$video['urlfoto'].'" width="100" height="100"></td>

						<td>'.$video['titulo'].'</td>

						<td>'.$video['pais'].'</td>
						<td><a href="video.php?id='.$video['id'].'">Enlace</a></td>
					</tr>';
					echo $devolver;
				}  
				?>

		</table>
	</body>
</html>