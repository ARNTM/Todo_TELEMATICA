<?php 

	if(isset($_COOKIE[$_GET['idProducto']])){
		setcookie($_GET['idProducto'],$_GET['idProducto'],time()+3600);
		if(sizeof($_COOKIE) <= 10){echo 'Adelante con su descarga';}
		else {echo 'No puede descargar  más';}
	}
	else {
		setcookie($_GET['idProducto'],$_GET['idProducto'],time()+3600);
	}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Numero de visitas</title>
</head>

<body>
	<p>Esta página ha sido visitada 
		<?php 
			if(isset($_COOKIE['visita'])) echo $_COOKIE['visita'];
			else echo '1';
		?> 
		veces</p>
</body>
</html>