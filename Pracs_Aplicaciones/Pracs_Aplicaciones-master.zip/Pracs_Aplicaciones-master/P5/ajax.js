//Hacemos el objeto global
var httpRequest;
var imgSrc;

function addClick() {
	var imgs=document.getElementsByTagName("img");
	for (var i=0; i<imgs.length; i++) {
		imgs[i].onclick=getInfo;
	}
}

function getInfo(val) {
	imgSrc=val.target.getAttribute('src');
	httpRequest = new XMLHttpRequest();
	httpRequest.onreadystatechange = showLightbox;
	httpRequest.open('GET', 'getInfo.php?id='+val.target.getAttribute('id'), true);
	httpRequest.send(null);


	lightbox(val);

}

function showLightbox()  {
	try {
		if (httpRequest.readyState === 4) {
			if (httpRequest.status === 200) {
				//Obtenemos la respuesta correctamente
				//alert(httpRequest.responseText);
				var box=document.getElementById("lightbox");
				var e=document.getElementById("lightbox");
				box.innerHTML='<img src="'+imgSrc+'"><br>'+httpRequest.responseText+'<br><a href="" onclick="hide()">Cerrar</a>';
				//box.innerHTML=httpRequest.responseText+'<a href="" onclick="hide()">Cerrar</a>';

			} else {
				alert('There was a problem with the request.');
			}
		}

	} catch (e) {
		alert('Caught Exception: ' + e.description);
	}
}

function lightbox (e) {
	var box=document.getElementById("lightbox");
	//box.innerHTML='<img src="'+e.getAttribute('src')+'"><br><a href="" onclick="hide()">Cerrar</a>';
	box.style='display:block';
	box.innerHTML='<progress ></progress>'; 
}
function hide(e) {
	document.getElementById("lightbox").style='display:none';

}

//Añadimos el evento click cuando el documento este cargado
document.body.onload=addClick;

