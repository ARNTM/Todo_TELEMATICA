<?php 
include 'header.php';
$link = new PDO('mysql:host=localhost;dbname=ai', 'ai', 'iKvgOtzRkwJWa5rb');
if (!$link) {
    die('No se puede conectar: ' . mysql_error());
}
//echo 'Connected successfully';

$query ="SELECT id, titulo, pais, urlfoto FROM videos";

$result = $link->query($query);

if (!$result) {
    $message  = 'Mensaje de error: ' . $link->errorInfo() . "\n";
    $message .= 'Consulta: ' . $query;
    die($message);
}
echo '<body>';
echo '<h1> VIDEOS </h1>';
echo '<div id="lightbox"></div>';
echo '<table id="tabla"><th>Título</th><th>Pais</th><th>Imagen</th>';

while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
	echo '<tr><td><a href="video.php?id='.$row['id'].'">'.$row['titulo'].'</a></td><td>'.$row['pais'].'</td><td><img onclick="getInfo(this)" id="'.$row['id'].'" src="'.$row['urlfoto'].'"></td></tr>'; 
}


echo '</table></body>';

$result=null;
$link=null;
