<?php
$link = new PDO('mysql:host=localhost;dbname=ai', 'ai', 'iKvgOtzRkwJWa5rb');
if (!$link) {
    die('No se puede conectar: ' . mysql_error());
}
//echo 'Connected successfully';

$query ="SELECT  descripcion FROM videos WHERE id=".$_GET['id'];

$result = $link->query($query);

if (!$result) {
    $message  = 'Mensaje de error: ' . $link->errorInfo() . "\n";
    $message .= 'Consulta: ' . $query;
    die($message);
}
$row = $result->fetch(PDO::FETCH_ASSOC);
echo $row["descripcion"];

$result=null;
$link=null;
?>
