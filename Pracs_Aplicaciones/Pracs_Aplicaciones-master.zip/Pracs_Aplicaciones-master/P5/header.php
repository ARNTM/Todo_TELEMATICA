<?php 
//Script para mostrar una cabera comun a todos nuestros scripts. En realidad, no incluye codigo php pero se guarda 
//como php para incluirlo luego con include
?>
<!DOCTYPE html>
<head>
<meta charset='utf-8'>
<title> VIDEOS</title>
<link rel="stylesheet" href="estilo.css" type="text/css">
<script src="ajax.js" type="text/javascript" defer></script>
</head>
<html>
