function J = computeCost(X, y, theta)
%COMPUTECOST Calcula el coste para la regresion lineal
%   J = COMPUTECOST(X, y, theta) calcula el coste de usar theta como 
%   parametro de regresion lineal de los datos X e y

m = length(y); % numero de ejemplos de entrenamiento

% Debes devolver el siguiente valor correctamente calculado
J = 0;

% ==================== INTRODUCE AQUI TU CODIGO ======================
% Instrucciones: Calcula el coste de usar el valor de theta introducido
%               J debe ser igual al coste que calcules.


% =========================================================================

    J = (1/(2*m)) * sum(((X*theta) - y).^2);

end
