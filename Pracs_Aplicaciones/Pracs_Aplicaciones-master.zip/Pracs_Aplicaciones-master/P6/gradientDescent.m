function [theta, J_history] = gradientDescent(X, y, theta, alpha, num_iters)
%GRADIENTDESCENT Realiza descenso del gradiente para aprender theta
%   theta = GRADIENTDESENT(X, y, theta, alpha, num_iters) actualiza theta 
%   mendiante num_iters iteraciones con tasa de aprendizaje alpha

m = length(y); % numero de ejmplos
J_history = zeros(num_iters, 1);

for iter = 1:num_iters

    % ====================== INTRODUCE AQUI TU CODIGO ======================
    % Instrucciones: Realiza un paso del descenso del gradiente en cada
    % iteraci�n
    % ======================================================================

    % guarda el coste J en cada iteracion  
    t1 = theta(1) - (alpha/m)*(sum((theta(1)*X(:,1) + theta(2)*X(:,2) - y).*X(:,1)));
    t2 = theta(2) - (alpha/m)*(sum((theta(1)*X(:,1) + theta(2)*X(:,2) - y).*X(:,2)));

    theta = [t1; t2];
    
    J_history(iter+1) = computeCost(X, y, theta);

end

end
