function plotData(x, y)
%   PLOTDATA(x,y) representa los datos de beneficio "y" frente a poblaci�n
%   "x"

% ====================== ESCRIBE AQUI TU CODIGO ======================
% Instrucciones: Representa "x" frente a "y" mediante los comandos
%               "figure" y "plot". Usa los comandos "xlabel" y "ylabel" 
%               para indicar las etiquetas de cada eje.
%

 % abre una ventana "figure"

 % representa la figura
 % indica la etiqueta del eje y
 % indica la etiqueta del eje x

% ============================================================

    plot(x,y,'rx','MarkerSize',10);
    ylabel('Beneficio en 10,000s');
    xlabel('Poblaci�n de la cuidad en 10,000s');
    
end
