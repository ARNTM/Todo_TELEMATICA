function varargout = menu(varargin)
% MENU Application M-file for menu.fig
%    FIG = MENU launch menu GUI.
%    MENU('callback_name', ...) invoke the named callback.

% Last Modified by GUIDE v2.0 04-Feb-2002 17:56:52

if nargin == 0  % LAUNCH GUI

	fig = openfig(mfilename,'reuse');

	% Generate a structure of handles to pass to callbacks, and store it. 
	handles = guihandles(fig);
	guidata(fig, handles);
    
%Aqui meto lo que quiero q ocurra al principio!
    axes(handles.axesPolar)
%     h=scDraw([0.5,1,2],[0.5,1,2]);
    scDraw([0.5,1,2],[0.5,1,2]);
 %Ponemos los ejes de la linea con el generador y su linea de inyeccion
 %de energia electromagnetica
    graf=handles.axesLinea;
    axes(graf) %seleccionamos la grafica
    cla;       %borro lo que hubiera!
    axis([-0.25-0.25/8 1+0.25/8 -4.3 4.3]);
    grid on;  %pongo rejilla!
    axis manual;  %Asi fijo los ejes para las graficas que vengan.
    hold on;      % y pongo esto para que se fijen los ejes!
    set(graf,'Color',[0.50,0.50,0.50]); %Color gris de fondo...
        %pongo las etiquetas de la amplitud de la tension
    set(graf,'YTickLabel',[-1,-1/2,0,1/2,1]);
        %pongo las etiquetas de longitud
    LabelsX=[-0.25:0.25:1];  
    set(graf,'XTick',LabelsX);
    cadena=['Line Lenght'];
    xlabel(cadena,'VerticalAlignment','middle');
 
    dibujaLinea(0.25,1,1,handles);  %llamo a la funcion que dibuja la linea y demas...    

 %para la grafica del osciloscopio!
    graf=handles.axesOsc;
    axes(graf) %seleccionamos la grafica
    cla;       %borro lo que hubiera!
    axis([0 1 -1 1]);
    grid on;  %pongo rejilla!
    axis manual;  %Asi fijo los ejes para las graficas que vengan.
    hold on;      % y pongo esto para que se fijen los ejes!
    set(graf,'Color',[0.50,0.50,0.50]); %Color gris de fondo...
        %pongo las etiquetas de la amplitud de la tension
    set(graf,'YTickLabel',[-1,-1/2,0,1/2,1]);
        %pongo las etiquetas de longitud
    LabelsX=[0:0.1:1];  
    set(graf,'XTick',LabelsX);
    cadena=['Time'];
    xlabel(cadena,'VerticalAlignment','middle');
    %creamos una estructura que contiene 4 campos time,V,I,P, donde vamos
    %a ir creando y guardando las ondas TOTALES de tension, corriente
    %y potencia y su evolucion con el tiempo, que se guarda en t!
    Osc.time=zeros(1);
    Osc.V=zeros(1);
    Osc.I=zeros(1);
    Osc.P=zeros(1);    
    %Y esta estructura Osc con sus cuatro campos la guardamos en la
    %propiedad 'UserData' de handles.axesOsc
    set(handles.axesOsc,'UserData',Osc);
    
   %La imagen la guardo por si quiero dibujar sobre ella markers!
   %sera la estructura de la imagen reinicializada!
    Graf.l=zeros(1);
    Graf.F=0;
    Graf.handles=handles;
    Graf.Graf1=zeros(1);
    Graf.Graf2=zeros(1);
    Graf.Graf3=zeros(1);    
    Graf.GrafActual=0;      
    set(handles.frameGraf,'UserData',Graf);
    
    %El logo de la escuela!
    img = imread('logo-upct.jpg','jpg');
    axes(handles.axesLogo)
    axis off
    imshow(img);    
    
	if nargout > 0
		varargout{1} = fig;
	end

elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK

	try
		[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
	catch
		disp(lasterr);
	end

end


%| ABOUT CALLBACKS:
%| GUIDE automatically appends subfunction prototypes to this file, and 
%| sets objects' callback properties to call them through the FEVAL 
%| switchyard above. This comment describes that mechanism.
%|
%| Each callback subfunction declaration has the following form:
%| <SUBFUNCTION_NAME>(H, EVENTDATA, HANDLES, VARARGIN)
%|
%| The subfunction name is composed using the object's Tag and the 
%| callback type separated by '_', e.g. 'slider2_Callback',
%| 'figure1_CloseRequestFcn', 'axis1_ButtondownFcn'.
%|
%| H is the callback object's handle (obtained using GCBO).
%|
%| EVENTDATA is empty, but reserved for future use.
%|
%| HANDLES is a structure containing handles of components in GUI using
%| tags as fieldnames, e.g. handles.figure1, handles.slider2. This
%| structure is created at GUI startup using GUIHANDLES and stored in
%| the figure's application data using GUIDATA. A copy of the structure
%| is passed to each callback.  You can store additional information in
%| this structure at GUI startup, and you can change the structure
%| during callbacks.  Call guidata(h, handles) after changing your
%| copy to replace the stored original so that subsequent callbacks see
%| the updates. Type "help guihandles" and "help guidata" for more
%| information.
%|
%| VARARGIN contains any extra arguments you have passed to the
%| callback. Specify the extra arguments by editing the callback
%| property in the inspector. By default, GUIDE sets the property to:
%| <MFILENAME>('<SUBFUNCTION_NAME>', gcbo, [], guidata(gcbo))
%| Add any extra arguments after the last argument, before the final
%| closing parenthesis.



% --------------------------------------------------------------------
function varargout = editAmp_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.editAmp.
Vp=get(handles.editAmp,'String');
if (str2num(Vp))<=0
    cadena=['Sorry, but amplitude must be greater than zero Peak-Volts!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editAmp,'String','-');
    set(handles.editAmp,'UserData',-1);
    set(handles.textPower,'String','--> Power= -  Watts   ( -   dBm )');
    set(handles.textPower,'UserData',-1);       
    
else
    cadena=['Wave Peak-Amplitude is set to ',Vp,' Volts'];
    set(handles.textInfo,'String',cadena);
    set(handles.editAmp,'UserData',str2num(Vp));   %Guardo como NUMERO!!
    Zog=get(handles.editReZg,'UserData');
    if (Zog==inf)  %No habia metido todavia la impedancia caracteristica!
       %No hago nada
    else
       Vp=str2num(Vp);
       APower=Vp^2/(2*Zog);  %Available Power
       cadena=['    Power= ',num2str(APower),' Watts ( ',...
               num2str(10*log10(APower)+30),' dBm )'];
       set(handles.textPower,'String',cadena);
       set(handles.textPower,'UserData',APower);       
    end    
end


% --------------------------------------------------------------------
function varargout = editZo_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.editAmp.
Zo=get(handles.editZo,'String');
if (str2num(Zo))<=0
    cadena=['Sorry, but characteristic impedance must be real and greater than zero!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editZo,'String','-');
    set(handles.editZo,'UserData',-1);
    set(handles.textPower,'String','--> Power= -  Watts   ( -   dBm )');
    set(handles.textPower,'UserData',-1);       
    
else
    cadena=['Characteristic Impedance of the transmission line is set to ',Zo,' Ohms'];
    set(handles.textInfo,'String',cadena);
    set(handles.editZo,'UserData',str2num(Zo));   %Guardo como NUMERO!!
    Zo=str2num(Zo);  %Lo paso a numero para que no me de problemas!    
    
    
    %Compruebo si habia metido la impedancia de carga para 
    %cambiar el coeficiente de reflexion!!
    ReZL=get(handles.editReZL,'UserData');    
    ImZL=get(handles.editImZL,'UserData');    
    if (ReZL==inf)|(ImZL==inf)
      %Si no lo habia metido no hago nada mas
    else  %Pero si estaba metido ya puedo calcular el coefte. de reflexion!
%     cadena=['Load Impedance is set to ',num2str(ReZL),' +j ',num2str(ImZL),' Ohms'];
%     set(handles.textInfo,'String',cadena);
      % Y ahora ponemos el coeficiente de reflexion en modulo y fase
      %---------------------------------------------------------------
     ZL=ReZL+j*ImZL; %Impedancia de carga en numero complejo!
     RhoL=(ZL-Zo)/(ZL+Zo);     % Coeficiente de reflexion complejo!
     %En UserData de textRhoL guardo el valor de cfte. de reflexion complejo!
     set(handles.textRhoL,'UserData',RhoL);     
     ModRhoL=abs(RhoL);                     %Modulo
     AngleRhoLRad=atan2(imag(RhoL),real(RhoL)); %Angulo en radianes
     AngleRhoLDeg=AngleRhoLRad*180/pi;         %Angulo en grados    
     
     %lo metemos en los textos correspondientes!
     set(handles.textModRhoL,'String',num2str(ModRhoL));
     set(handles.textModRhoL,'UserData',ModRhoL);

     %En UserData de textAngleRho siempre guardamos el angulo de Rho en radianes!
     set(handles.textAngleRhoL,'UserData',AngleRhoLRad);
     %Elegimos representacion en radianes o en grados:
     Deg=get(handles.radiobuttonDeg,'Value');
     if Deg==1
       AngleRhoL=AngleRhoLDeg;
     else
       AngleRhoL=AngleRhoLRad;
     end
     
     if sign(AngleRhoL)>0
     cadena=['+j',num2str(abs(AngleRhoL))];
     else
     cadena=['-j',num2str(abs(AngleRhoL))];
     end
    
     set(handles.textAngleRhoL,'String',cadena);
    end    

    %Compruebo si habia metido la impedancia de generador para 
    %cambiar el coeficiente de reflexion!!
    ReZg=get(handles.editReZg,'UserData');    
    ImZg=get(handles.editImZg,'UserData');    
    if (ReZg==inf)|(ImZg==inf)
      %Si no lo habia metido no hago nada mas
    else  %Pero si estaba metido ya puedo calcular el coefte. de reflexion!
%     cadena=['Load Impedance is set to ',num2str(ReZL),' +j ',num2str(ImZL),' Ohms'];
%     set(handles.textInfo,'String',cadena);
      % Y ahora ponemos el coeficiente de reflexion en modulo y fase
      %---------------------------------------------------------------
     Zg=ReZg+j*ImZg; %Impedancia de carga en numero complejo!
     Rhog=(Zg-Zo)/(Zg+Zo);     % Coeficiente de reflexion complejo!
     %En UserData de textRhog guardo el valor de cfte. de reflexion complejo!
     set(handles.textRhog,'UserData',Rhog);     
     ModRhog=abs(Rhog);                     %Modulo
     AngleRhogRad=atan2(imag(Rhog),real(Rhog)); %Angulo en radianes
     AngleRhogDeg=AngleRhogRad*180/pi;         %Angulo en grados    
     
     %lo metemos en los textos correspondientes!
     set(handles.textModRhog,'String',num2str(ModRhog));
     set(handles.textModRhog,'UserData',ModRhog);

     %En UserData de textAngleRho siempre guardamos el angulo de Rho en radianes!
     set(handles.textAngleRhog,'UserData',AngleRhogRad);
     %Elegimos representacion en radianes o en grados:
     Deg=get(handles.radiobuttonDeg,'Value');
     if Deg==1
       AngleRhog=AngleRhogDeg;
     else
       AngleRhog=AngleRhogRad;
     end
     
     if sign(AngleRhog)>0
     cadena=['+j',num2str(abs(AngleRhog))];
     else
     cadena=['-j',num2str(abs(AngleRhog))];
     end
    
     set(handles.textAngleRhog,'String',cadena);
    end    
        
    
%---------------------------------------------------------------------    
    %Comprobamos si tenemos q actualizar la Carta de Smith (si habia
    %alguna impedancia (de carga o generador) metida!
    
    RhoL=get(handles.textRhoL,'UserData'); %cofte. de reflexion complejo!
    Rhog=get(handles.textRhog,'UserData'); %cofte. de reflexion complejo!    
     %Representamos en la Carta de Smith el rho load que sea
    if (RhoL==inf)
        if(Rhog==inf)
            %No dibujo nada!
        else
            %Redibujo el Rhog solo!
            axes(handles.axesPolar);
            cla;
            scDraw([0.5,1,2],[0.5,1,2]);
            plot(real(Rhog),imag(Rhog),'mo','MarkerFaceColor','m');             
        end
    else
     %ReDibujo el RhoL
     axes(handles.axesPolar);
     cla;
     scDraw([0.5,1,2],[0.5,1,2]);
     %polar(AngleRhoRad,ModRho,'co','MarkerFaceColor','c');
     plot(real(RhoL),imag(RhoL),'co','MarkerFaceColor','c'); 
     if (Rhog==inf)
     else
         %Rediujo Rhog sin borrar la grafica de RhoL
         plot(real(Rhog),imag(Rhog),'mo','MarkerFaceColor','m'); 
     end
    end
    
end

% --------------------------------------------------------------------
function varargout = editEr_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.editAmp.
Er=get(handles.editEr,'String');
if (str2num(Er))<1
    cadena=['Sorry, but characteristic impedance must be real and greater or equal to one!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editEr,'String','-');
    set(handles.editEr,'UserData',-1);
    %Cambio la velocidad de propagacion
    set(handles.textVp,'UserData',-1);    
    cadena=['--> Vp= - m/sg'];
    set(handles.textVp,'String',cadena);
    
else
    set(handles.editEr,'UserData',str2num(Er));
    %Cambio la velocidad de propagacion    
    mu=4*pi*1E-7;epslon=1/(36*pi*1E9);
    Co=1/sqrt(mu*epslon);
    Vp=Co/sqrt(str2num(Er));
    %En UserData de textVp guardo la velocidad de propagacion en m/seg
    set(handles.textVp,'UserData',Vp);    
    cadena=['--> Vp= ',num2str(Vp/1000),' Km/sg'];
    set(handles.textVp,'String',cadena);   
    %Texto de informacion
    cadena=['Relative Dielectric Cosntant of the transmission line is set to ',Er,...
            ' so the Phase Velocity is ',num2str(Vp/1000),' Km/sg'];
    set(handles.textInfo,'String',cadena);
    
    
   %Miro si estan introducidas Lambda para cambiarla al variar Er!!
    Lambda=get(handles.textLambda,'UserData'); %en m !
    % Si estaba Lambda estaba fo (MHz), seguro!
    fo=get(handles.editFreq,'UserData');  % en MHz
    if (Lambda==-1)
        %si no estaba metida no hago nada!!
    else
      %Cambio la longitud de onda
      Lambda=Vp/(fo*1E6); % Long. de onda en m!
      set(handles.textLambda,'UserData',Lambda);    
      cadena=['--> Lambda= ',num2str(Lambda),' m'];
      set(handles.textLambda,'String',cadena);
      
      %Y ahora miro por si estaba L tambien cambiarlo!
      L=get(handles.textL,'UserData'); %en m !
      % Si estaba L estaba N (numero de lambdas), seguro!
      N=get(handles.editN,'UserData');
      if (L==-1)
        %si no estaba metida no hago nada!!
      else
        %Cambio la longitud de la linea!
        L=Lambda*N; % Long. de linea en m!
        set(handles.textL,'UserData',L);    
        cadena=['--> L= ',num2str(L),' m'];
        set(handles.textL,'String',cadena); 
      end
     
     end
end

% --------------------------------------------------------------------
function varargout = editFreq_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.editAmp.
fo=get(handles.editFreq,'String');
  %En UserData de textVp guardo la velocidad de propagacion (m/sg)
Vp=get(handles.textVp,'UserData');
%Miro si esta introducida Vp
if (Vp==-1)
    cadena=['Please, insert first Er!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editFreq,'String','-');
    set(handles.editFreq,'UserData',-1);    
    return;
end

if (str2num(fo))<=0
    cadena=['Sorry, but frequency must be greater than zero!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editFreq,'String','-');
    set(handles.editFreq,'UserData',-1);
        %Cambio la longitud de onda
    set(handles.textLambda,'UserData',-1);    
    cadena=['--> Lambda= - m'];
    set(handles.textLambda,'String',cadena);    

else
    cadena=['Center Analysis Frequency is set to ',fo,' MHz'];
    set(handles.textInfo,'String',cadena);
    set(handles.editFreq,'UserData',str2num(fo)); %Guardo la 
                                  %  frecuencia en MHz como NUMERO!!   
    %Cambio la longitud de onda
    Lambda=Vp/(str2num(fo)*1E6); % Long. de onda en m!
    set(handles.textLambda,'UserData',Lambda);    
    cadena=['--> Lambda= ',num2str(Lambda),' m'];
    set(handles.textLambda,'String',cadena);  
    
      %Y ahora miro por si estaba L para cambiarlo!
      L=get(handles.textL,'UserData'); %en m !
      % Si estaba L estaba N (numero de lambdas), seguro!
      N=get(handles.editN,'UserData');
      if (L==-1)
        %si no estaba metida no hago nada!!
      else
        %Cambio la longitud de la linea!
        L=Lambda*N; % Long. de linea en m!
        set(handles.textL,'UserData',L);    
        cadena=['--> L= ',num2str(L),' m'];
        set(handles.textL,'String',cadena); 
      end  
    
end


% --------------------------------------------------------------------
function varargout = editN_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.editAmp.
N=get(handles.editN,'String');
  %En UserData de textLambda guardo la longitud de onda (m)
Lambda=get(handles.textLambda,'UserData');    
%Miro si estan introducidas Lambda (para ello debe estar metida Er y freq
if (Lambda==-1)
    cadena=['Please, insert first the frequency and Er!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editN,'String','-');
    set(handles.editN,'UserData',-1);    
    return;
end

%si sigo por aqui es que estaban metidos esos datos...
if (str2num(N))<=0
    cadena=['Sorry, but length of the transmission line be greater than zero!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editN,'String','-');
    set(handles.editN,'UserData',-1);
    %Cambio la longitud de linea
    set(handles.textL,'UserData',-1);    
    cadena=['--> L= - m'];
    set(handles.textL,'String',cadena);    
else
    set(handles.editN,'UserData',str2num(N)); 
    %Cambio la longitud de linea
    L=str2num(N)*Lambda; % En m!
    % La longitud en NUMERO la guardo en UserData de textL
    set(handles.textL,'UserData',L);       
    cadena=['--> L= ',num2str(L),' m'];
    set(handles.textL,'String',cadena); 
    %Texto informativo!
    cadena=['Length of the transmission line is set to ',N,' wavelenghts, that is '...
            ,num2str(L),' m'];
    set(handles.textInfo,'String',cadena);

end

% --------------------------------------------------------------------
function varargout = editReZL_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.editAmp.
ReZL=get(handles.editReZL,'String');
  %En UserData de editZo guardo la Zo (Ohmios)
Zo=get(handles.editZo,'UserData');    
%Miro si estan introducida Zo
if (Zo==-1)
    cadena=['Please, insert first the Characteristic Impedance Zo!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editReZL,'String','-');
    set(handles.editReZL,'UserData',inf);    
    return;
end

%si sigo por aqui es que estaban metidos esos datos...
    set(handles.editReZL,'UserData',str2num(ReZL)); 
    %Texto informativo!  
    cadena=['Real Part of the Load Impedance is set to ',ReZL,' Ohms'];
    set(handles.textInfo,'String',cadena);
%Compruebo si habia metido la parte imaginaria!
ImZL=get(handles.editImZL,'UserData');    
if ImZL==inf
      %Si no lo habia metido no hago nada mas
else  %Pero si estaba metido ya puedo calcular el coefte. de reflexion!
  cadena=['Load Impedance is set to ',ReZL,' +j ',num2str(ImZL),' Ohms'];
  set(handles.textInfo,'String',cadena);

  % Y ahora ponemos el coeficiente de reflexion en modulo y fase
  %---------------------------------------------------------------
  ReZL=str2num(ReZL);  %Lo paso a numero para q no de problemas!
  
  ZL=ReZL+j*ImZL; %Impedancia de carga en numero complejo!
  RhoL=(ZL-Zo)/(ZL+Zo);     % Coeficiente de reflexion complejo!
  %En UserData de textRhoL guardo el valor de cfte. de reflexion complejo!
  set(handles.textRhoL,'UserData',RhoL);
  ModRhoL=abs(RhoL);                     %Modulo
  AngleRhoLRad=atan2(imag(RhoL),real(RhoL)); %Angulo en radianes
  AngleRhoLDeg=AngleRhoLRad*180/pi;         %Angulo en grados

  %Representamos en la Carta de Smith el rho load
  axes(handles.axesPolar);
  cla;
  scDraw([0.5,1,2],[0.5,1,2]);
  %polar(AngleRhoRad,ModRho,'co','MarkerFaceColor','c');
  plot(real(RhoL),imag(RhoL),'co','MarkerFaceColor','c');
  %Miramos si esaba calculado el rho generator para dibujarlo tambien!
  Rhog=get(handles.textRhog,'UserData');
  if (Rhog==inf) %eso es q no estaba metido y no hago nada mas
  else
      plot(real(Rhog),imag(Rhog),'mo','MarkerFaceColor','m');  %Lo dibujo en azul!
  end

  %lo metemos en los textos correspondientes!
  set(handles.textModRhoL,'String',num2str(ModRhoL));
  set(handles.textModRhoL,'UserData',ModRhoL);

  %En UserData de textAngleRho siempre guardamos el angulo de Rho en radianes!
  set(handles.textAngleRhoL,'UserData',AngleRhoLRad);
  %Elegimos representacion en radianes o en grados:
  Deg=get(handles.radiobuttonDeg,'Value');
  if Deg==1
     AngleRhoL=AngleRhoLDeg;
  else
     AngleRhoL=AngleRhoLRad;
  end

  if sign(AngleRhoL)>0
  cadena=['+j',num2str(abs(AngleRhoL))];
  else
  cadena=['-j',num2str(abs(AngleRhoL))];
  end
    
  set(handles.textAngleRhoL,'String',cadena);
    
end


% --------------------------------------------------------------------
function varargout = editImZL_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.editAmp.
ImZL=get(handles.editImZL,'String');
  %En UserData de editZo guardo la Zo (Ohmios)
Zo=get(handles.editZo,'UserData');
ReZL=get(handles.editReZL,'UserData');
%Miro si estan introducida Zo y ReZL
if (Zo==-1)|(ReZL==inf)
    cadena=['Please, insert first the Characteristic Impedance Zo and the Real Part of Z load!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editImZL,'String','-');
    set(handles.editImZL,'UserData',inf);    
    return;
end

%si sigo por aqui es que estaban metidos esos datos...
set(handles.editImZL,'UserData',str2num(ImZL)); 
 %Texto informativo!  
cadena=['Load Impedance is set to ',num2str(ReZL),' +j ',ImZL,' Ohms'];
set(handles.textInfo,'String',cadena);

% Y ahora ponemos el coeficiente de reflexion en modulo y fase
%---------------------------------------------------------------
ImZL=str2num(ImZL);   %lo paso a numero para no tener problemas!
ZL=ReZL+j*ImZL;          %Impedancia de carga en numero complejo!
RhoL=(ZL-Zo)/(ZL+Zo);     % Coeficiente de reflexion complejo!
%En UserData de textRhoL guardo el valor de cfte. de reflexion complejo!
set(handles.textRhoL,'UserData',RhoL);
ModRhoL=abs(RhoL);                     %Modulo
AngleRhoLRad=atan2(imag(RhoL),real(RhoL)); %Angulo en radianes
AngleRhoLDeg=AngleRhoLRad*180/pi;            %Angulo en grados

%Representamos en la Carta de Smith el rho load
axes(handles.axesPolar);
cla;
scDraw([0.5,1,2],[0.5,1,2]);
%polar(AngleRhoRad,ModRho,'co','MarkerFaceColor','c');
plot(real(RhoL),imag(RhoL),'co','MarkerFaceColor','c');
%Miramos si esaba calculado el rho generator para dibujarlo tambien!
Rhog=get(handles.textRhog,'UserData');
if (Rhog==inf) %eso es q no estaba metido y no hago nada mas
else
   plot(real(Rhog),imag(Rhog),'mo','MarkerFaceColor','m');  %Lo dibujo en azul!
end

%lo metemos en los textos correspondientes!
set(handles.textModRhoL,'String',num2str(ModRhoL));
set(handles.textModRhoL,'UserData',ModRhoL);

%En UserData de textAngleRho siempre guardamos el angulo de Rho en radianes!
set(handles.textAngleRhoL,'UserData',AngleRhoLRad);
%Elegimos representacion en radianes o en grados:
Deg=get(handles.radiobuttonDeg,'Value');
if Deg==1
    AngleRhoL=AngleRhoLDeg;
else
    AngleRhoL=AngleRhoLRad;
end

if sign(AngleRhoL)>0
cadena=['+j',num2str(abs(AngleRhoL))];
else
cadena=['-j',num2str(abs(AngleRhoL))];
end
    
set(handles.textAngleRhoL,'String',cadena);


% --------------------------------------------------------------------
function varargout = editReZg_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.editAmp.
ReZg=get(handles.editReZg,'String');
  %En UserData de editZo guardo la Zo (Ohmios)
Zo=get(handles.editZo,'UserData');    
%Miro si estan introducida Zo
if (Zo==-1)
    cadena=['Please, insert first the Characteristic Impedance Zo!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editReZg,'String','-');
    set(handles.editReZg,'UserData',inf);    
    return;
end

   %para ver si habia metido al amplitud para poner
   %la Potencia Disponble por el Generador
    Vp=get(handles.editAmp,'UserData');    
    %NOTA MUY IMPORTANTE:
    %la parte real de la impedancia del generador es considerada como
    %la impedancia caracterisitca de la linea del generador!!
    Zog=str2num(ReZg); 
    if (Vp==-1)  %No habia metido todavia la amplitud de pico de tension!
       %No hago nada
    else
       APower=Vp^2/(2*Zog);  %Available Power
       cadena=['--> Power= ',num2str(APower),' Watts ( ',...
               num2str(10*log10(APower)+30),' dBm )'];
       set(handles.textPower,'String',cadena);
       set(handles.textPower,'UserData',APower);       
    end    



%si sigo por aqui es que estaban metidos esos datos...
    set(handles.editReZg,'UserData',str2num(ReZg)); 
    %Texto informativo!  
    cadena=['Real Part of the Generator Impedance is set to ',ReZg,' Ohms. It is also the Characteristic Impedance of the line of generator!'];
    set(handles.textInfo,'String',cadena);
%Compruebo si habia metido la parte imaginaria!
ImZg=get(handles.editImZg,'UserData');    
if ImZg==inf
      %Si no lo habia metido no hago nada mas
else  %Pero si estaba metido ya puedo calcular el coefte. de reflexion!
  cadena=['Generator Impedance is set to ',ReZg,' +j ',num2str(ImZg),' Ohms. The real part is also the Characteristic Impedance of the line of generator!'];
  set(handles.textInfo,'String',cadena);

  % Y ahora ponemos el coeficiente de reflexion en modulo y fase
  %---------------------------------------------------------------
  ReZg=str2num(ReZg);  %Lo paso a numero para q no de problemas!
  
  Zg=ReZg+j*ImZg; %Impedancia de carga en numero complejo!
  Rhog=(Zg-Zo)/(Zg+Zo);     % Coeficiente de reflexion complejo!
  %En UserData de textRhog guardo el valor de cfte. de reflexion complejo!
  set(handles.textRhog,'UserData',Rhog);
  ModRhog=abs(Rhog);                     %Modulo
  AngleRhogRad=atan2(imag(Rhog),real(Rhog)); %Angulo en radianes
  AngleRhogDeg=AngleRhogRad*180/pi;         %Angulo en grados

  %Representamos en la Carta de Smith el rho geneator
  axes(handles.axesPolar);
  cla;
  scDraw([0.5,1,2],[0.5,1,2]);
  plot(real(Rhog),imag(Rhog),'mo','MarkerFaceColor','m');
  %Miramos si esaba calculado el rho load para dibujarlo tambien!
  RhoL=get(handles.textRhoL,'UserData');
  if (RhoL==inf) %eso es q no estaba metido y no hago nada mas
  else
      plot(real(RhoL),imag(RhoL),'co','MarkerFaceColor','c');  %Lo dibujo en rojo!
  end

  %lo metemos en los textos correspondientes!
  set(handles.textModRhog,'String',num2str(ModRhog));
  set(handles.textModRhog,'UserData',ModRhog);

  %En UserData de textAngleRho siempre guardamos el angulo de Rho en radianes!
  set(handles.textAngleRhog,'UserData',AngleRhogRad);
  %Elegimos representacion en radianes o en grados:
  Deg=get(handles.radiobuttonDeg,'Value');
  if Deg==1
     AngleRhog=AngleRhogDeg;
  else
     AngleRhog=AngleRhogRad;
  end

  if sign(AngleRhog)>0
  cadena=['+j',num2str(abs(AngleRhog))];
  else
  cadena=['-j',num2str(abs(AngleRhog))];
  end
    
  set(handles.textAngleRhog,'String',cadena);
    
end


% --------------------------------------------------------------------
function varargout = editImZg_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.editAmp.
ImZg=get(handles.editImZg,'String');
  %En UserData de editZo guardo la Zo (Ohmios)
Zo=get(handles.editZo,'UserData');
ReZg=get(handles.editReZg,'UserData');
%Miro si estan introducida Zo y ReZg
if (Zo==-1)|(ReZg==inf)
    cadena=['Please, insert first the Characteristic Impedance Zo and the Real Part of Z generator!'];
    set(handles.textInfo,'String',cadena);
    set(handles.editImZg,'String','-');
    set(handles.editImZg,'UserData',inf);    
    return;
end

%si sigo por aqui es que estaban metidos esos datos...
set(handles.editImZg,'UserData',str2num(ImZg)); 
 %Texto informativo!  
cadena=['Generator Impedance is set to ',num2str(ReZg),' +j ',ImZg,' Ohms. The real part is also the Characteristic Impedance of the line of generator!'];
set(handles.textInfo,'String',cadena);

% Y ahora ponemos el coeficiente de reflexion en modulo y fase
%---------------------------------------------------------------
ImZg=str2num(ImZg);   %lo paso a numero para no tener problemas!
Zg=ReZg+j*ImZg;          %Impedancia de carga en numero complejo!
Rhog=(Zg-Zo)/(Zg+Zo);     % Coeficiente de reflexion complejo!
%En UserData de textRhog guardo el valor de cfte. de reflexion complejo!
set(handles.textRhog,'UserData',Rhog);
ModRhog=abs(Rhog);                     %Modulo
AngleRhogRad=atan2(imag(Rhog),real(Rhog)); %Angulo en radianes
AngleRhogDeg=AngleRhogRad*180/pi;            %Angulo en grados

%Representamos en la Carta de Smith el rho generator
axes(handles.axesPolar);
cla;
scDraw([0.5,1,2],[0.5,1,2]);
%polar(AngleRhoRad,ModRho,'co','MarkerFaceColor','c');
plot(real(Rhog),imag(Rhog),'mo','MarkerFaceColor','m');
%Miramos si esaba calculado el rho load para dibujarlo tambien!
RhoL=get(handles.textRhoL,'UserData');
if (RhoL==inf) %eso es q no estaba metido y no hago nada mas
else
   plot(real(RhoL),imag(RhoL),'co','MarkerFaceColor','c');  %Lo dibujo en rojo!
end

%lo metemos en los textos correspondientes!
set(handles.textModRhog,'String',num2str(ModRhog));
set(handles.textModRhog,'UserData',ModRhog);

%En UserData de textAngleRho siempre guardamos el angulo de Rho en radianes!
set(handles.textAngleRhog,'UserData',AngleRhogRad);
%Elegimos representacion en radianes o en grados:
Deg=get(handles.radiobuttonDeg,'Value');
if Deg==1
    AngleRhog=AngleRhogDeg;
else
    AngleRhog=AngleRhogRad;
end

if sign(AngleRhog)>0
cadena=['+j',num2str(abs(AngleRhog))];
else
cadena=['-j',num2str(abs(AngleRhog))];
end
    
set(handles.textAngleRhog,'String',cadena);





% --------------------------------------------------------------------
function varargout = radiobuttonRad_Callback(h, eventdata, handles, varargin)
%Miro si tengo algun angulo puesto y he cambiado el formato
Deg=get(handles.radiobuttonDeg,'Value');
%en UserData de textAngleRhoL y AngleRhog siempre esta AngleRho en radianes!
AngleRhoL=get(handles.textAngleRhoL,'UserData');
AngleRhog=get(handles.textAngleRhog,'UserData');
if ((AngleRhoL==inf)&(AngleRhog==inf)) |(Deg==0)
    %No hago nada si no estaba el angulo o ya estaba en radianes
else
   %AngleRhoL ya esta en radianes!
   if sign(AngleRhoL)>0
     cadena=['+j',num2str(abs(AngleRhoL))];
   else
     cadena=['-j',num2str(abs(AngleRhoL))];
   end  
   set(handles.textAngleRhoL,'String',cadena);
   %AngleRhog ya esta en radianes!
   if sign(AngleRhog)>0
     cadena=['+j',num2str(abs(AngleRhog))];
   else
     cadena=['-j',num2str(abs(AngleRhog))];
   end  
   set(handles.textAngleRhog,'String',cadena);  
end
%Cambio el boton a radianes, apago el de grados
set(handles.radiobuttonDeg,'Value',0);
set(handles.radiobuttonRad,'Value',1);   
%Texto informativo 
cadena=('Angle of reflection coeficient will be presented in radians');
set(handles.textInfo,'String',cadena);




% --------------------------------------------------------------------
function varargout = radiobuttonDeg_Callback(h, eventdata, handles, varargin)
%Miro si tengo algun angulo puesto y he cambiado el formato
Rad=get(handles.radiobuttonRad,'Value');
%en UserData de textAngleRhoL siempre esta AngleRhoL en radianes!
%y los mismo para AngleRhog!
AngleRhoL=get(handles.textAngleRhoL,'UserData');
AngleRhog=get(handles.textAngleRhog,'UserData');
if ((AngleRhoL==inf)&(AngleRhog==inf)) | (Rad==0)
    %No hago nada si no estaba ningun angulo o ya estaba en grados!
else
   %AngleRhoL y AngleRhog estan en radianes, asiq que los paso a grados!
   %AngleRhoL
   AngleRhoL=AngleRhoL*180/pi;
   if sign(AngleRhoL)>0
     cadena=['+j',num2str(abs(AngleRhoL))];
   else
     cadena=['-j',num2str(abs(AngleRhoL))];
   end  
   set(handles.textAngleRhoL,'String',cadena);
   %AngleRhog
   AngleRhog=AngleRhog*180/pi;
   if sign(AngleRhog)>0
     cadena=['+j',num2str(abs(AngleRhog))];
   else
     cadena=['-j',num2str(abs(AngleRhog))];
   end  
   set(handles.textAngleRhog,'String',cadena);
end
%Cambio el boton a grados!   
set(handles.radiobuttonRad,'Value',0);   
set(handles.radiobuttonDeg,'Value',1);   
%Texto informativo 
cadena=('Angle of reflection coeficient will be presented in degrees');
set(handles.textInfo,'String',cadena);



%----------------------------------------------------------
function X=cogeDatos(handles);
 X(1)=get(handles.editAmp,'UserData');      %Amplitud en Volts pico
 X(2)=get(handles.editFreq,'UserData');     %frecuencia en MHz 
 X(3)=get(handles.textLambda,'UserData');   %longitud de onda en m
 X(4)=get(handles.textVp,'UserData');       %velocidad de propagacion en m/sg
 X(5)=get(handles.textL,'UserData');        %Longitud de la linea
 X(6)=get(handles.textModRhoL,'UserData');  %modulo de rhoL
 X(7)=get(handles.textAngleRhoL,'UserData');%angulo en radianes de rhoL
 X(8)=get(handles.textModRhog,'UserData');   %modulo de rhog
 X(9)=get(handles.textAngleRhog,'UserData'); %angulo en radianes de rhog
 X(10)=get(handles.editZo,'UserData');       %impedancia de la linea Zo para
                                             %calculo de I,P a partir de V
 X(11)=get(handles.editReZg,'UserData'); % NOTA IMPORTANTE:
 %Cogemos la parte real de la impedancia del generador como la impedancia
 %de la linea del generador, ya que al ser una linea sin perdidas, su
 %impedancia caracteristica Zog debe ser real, y suponemos q la parte
 %imaginaria de la impedancia de salida del generador se debe a elementos
 %reactivos concentrados (condensadores y bobinas equivalentes en el conector)
 

 
 
%----------- Boton de LAUNCH WAVE ! --------------------------------- 
% --------------------------------------------------------------------
function varargout = pushbuttonVer_Callback(h, eventdata, handles, varargin)
 %Vemos si ya habia una onda lanzada para decir que no se puede lanzar otra!
 Cod=get(handles.pushbuttonVer,'UserData');
 if Cod>0
     cadena=['A wave has already been launched, reset it in order to restart!'];
     set(handles.textInfo,'String',cadena);     
     return;
 end

 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     return;
 else
     cadena=['Initializing parameters...'];
     set(handles.textInfo,'String',cadena);     
 end

 Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
 Pause=get(handles.editPause,'UserData');
 if (Res==0)|(Pause==-2)
     cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
     set(handles.textInfo,'String',cadena);     
     return;
 end

 CheckIter=get(handles.textIter,'UserData');
 if CheckIter==1
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);     
     return;     
 end
 %Ponemos el siguiente parametro a 1 para indicar q estamos en medio de 
 %iteracion y asi no hacemos caso de las teclas!
 set(handles.textIter,'UserData',1);
 
 %Inicializacion de parametros que usamos...
 Vpeak=X(1);   %Amplitud de onda progresiva incicial en Votls pico
 fo=X(2)*1E6;  %frecuencia de la onda en Hz (paso de MHz a Hz)
 lambda=X(3);  %longitud de onda en m
 vp=X(4);      %velocidad de propagacion en m/sg
 L=X(5);       %longitud de la linea en m
 ModRhoL=X(6); %modulo del coeficiente de reflexion de carga
 AngleRhoL=X(7); %angulo del coeficiente de reflexion de carga en radianes
 ModRhog=X(8); %modulo del coeficiente de reflexion de generador
 AngleRhog=X(9); %angulo del coeficiente de reflexion de generador en radianes
 beta=2*pi/lambda; %numero de onda en rad/m
 w=2*pi*fo;       %pulsacion angular en rad/seg
 T=L/vp;         %tiempo q le lleva a la onda a recorrer la linea en segundos
 Lgen=L/4;       %longitud de la linea del generador, que esta adaptada a la
                 %impedancia del mismo, y que ponemos mas peque�a que la longitud
                 %de la linea para q las reflexiones tarden menos en llegar
                 %a los limites del generador q al extremo de la linea!
 
 deltaL=lambda/Res;  %resolucion en L en metros
 deltaT=deltaL/vp;   %resolucion en t en segundos
 %Para calcular la corrientes y potencias a partir de las ondas de tension
 %usamos las impedancias caracteristicas de las lineas del gendro Zog y la larga Zo
 Zo=X(10);  %Imped. caracteristica de la linea larga
 Zog=X(11); %Imped. caracteristica de la linea del generador!
 
 %Cogemos unidades adecuadas para la longitud y el tiempo de manera que
 %podamos visualizarlas bien! Me baso en Ttotal para el tiempo y en L para longitud
   %Longitud:
 if (L>1000)
     UnitL='Km';FactorL=1/1000;
 elseif (L>0.1)
     UnitL='m';FactorL=1;
 elseif (L>1/10000)
     UnitL='mm';FactorL=1000;
 else
     UnitL='microm';FactorL=1000000;
 end
 %Guardamos FactorL en UserData de textDeltaL
 set(handles.textDeltaL,'UserData',FactorL); 
   %Tiempo:
 if (T>60)
     UnitT='min';FactorT=1/60;
 elseif (T>0.1)
     UnitT='sg';FactorT=1;
 elseif (T>1/10000)
     UnitT='msg';FactorT=1000;
 elseif (T>1/10000000)
     UnitT='micrsg';FactorT=1000000;     
 elseif (T>1/10000000000)
     UnitT='nanosg';FactorT=1000000000;
 else
     UnitT='picosg';FactorT=1000000000000;
 end
 %Guardamos FactorL en UserData de textDeltaT
 set(handles.textDeltaT,'UserData',FactorT); 
 
 
 %Ahora si podemos representar las dimensiones que manejamos con las
 %unidades mas apropiadas...
 set(handles.textTime,'String','TIME= -');
 cadena=['( ',UnitT,' )'];
 set(handles.textUnitT,'String',cadena);
 cadena=['deltaT= ',num2str(deltaT*FactorT),' ',UnitT];
 set(handles.textDeltaT,'String',cadena); 
 cadena=['deltaL= ',num2str(deltaL*FactorL),' ',UnitL];
 set(handles.textDeltaL,'String',cadena); 
  
 %Vemos que tipos de ondas hay que representar!------------------------
  CheckV=get(handles.radiobuttonVolt,'Value');
  CheckI=get(handles.radiobuttonCurr,'Value');
  CheckP=get(handles.radiobuttonPow,'Value');
 
 %Ponemos los ejes de la linea con el generador y su linea de inyeccion
 %de energia electromagnetica
 graf=handles.axesLinea;
 axes(graf) %seleccionamos la grafica
 cla;       %borro lo que hubiera!
 grid on;  %pongo rejilla!
 axis manual;  %Asi fijo los ejes para las graficas que vengan.
 hold on;      % y pongo esto para que se fijen los ejes!
 set(graf,'Color',[0.50,0.50,0.50]); %Color gris de fondo...
        %pongo las etiquetas de la amplitud de la tension
 LabelsX=[-Lgen:lambda/2:L]; %FactorL;  
 set(graf,'XTick',LabelsX);
 set(graf,'XTickLabel',LabelsX*FactorL); 
 cadena=['Line Lenght in ',UnitL];
 xlabel(cadena,'VerticalAlignment','middle');
 
 
 %Representamos la primera onda progresiva, desde el generador por la
 %linea de interfaz del mismo, hasta que llega al conector al exterior!
   %Mensaje de informacion
 if Pause==-1
     cadena=['Showing first progressive wave...Press any key to show next frame!'];
     set(handles.textInfo,'String',cadena);     
 else
     cadena=['Showing first progressive wave...'];
     set(handles.textInfo,'String',cadena);
 end

 %------------------------------------------------ 
 graf=handles.axesLinea;
 axes(graf) %seleccionamos la grafica
 grafOsc=handles.axesOsc; 
 
 Ppeak=Vpeak^2/(2*Zog)*1000;  %Paso a mWatios!
 Ipeak=Vpeak/Zog*1000;        %Paso a mAmperios!

 %---------------para ver la escala q usamos en la grafica!!
 Picos=[Vpeak,Ipeak,Ppeak];
 Checks=[CheckV,CheckI,CheckP];
 Mult=Picos.*Checks;  %asi solo hago el maximo de las unidades activas!
 MaxMult=max(Mult);
 PosMax=find(Mult==MaxMult);
 
 if PosMax==1
    axes(graf) %seleccionamos la grafica     
    ylabel('Volts');                 
    axes(grafOsc) %seleccionamos la grafica    del osciloscopio
    ylabel('Volts');                     
    Factor=Vpeak;    
elseif PosMax==2
    axes(graf)    
    ylabel('mAmps');                  
    axes(grafOsc)    
    ylabel('mAmps');                  
    Factor=Ipeak;    
elseif PosMax==3
    axes(graf)    
    ylabel('mWatts');
    axes(grafOsc)    
    ylabel('mWatts');    
    Factor=Ppeak;    
end
%el Factor sirve para determinar la escala vertical de las graficas 
%lo voy a guardar en UserData de checkboxMarkers
set(handles.checkboxMarkers,'UserData',Factor);

% Grafica de distribucion en L
 axes(graf)    
 set(graf,'YTick',[-4*Factor,-2*Factor,0,2*Factor,4*Factor]);        
 set(graf,'YTickLabel',[-4*Factor,-2*Factor,0,2*Factor,4*Factor]);     
 dibujaLinea(Lgen,L,Factor,handles); 
 axis([-Lgen-Lgen/8 L+Lgen/8 -4.3*Factor 4.3*Factor]);        
% Grafica de distribucion en T = Osciloscopio 
 axes(grafOsc)    
 set(grafOsc,'YTick',[-4*Factor,-2*Factor,0,2*Factor,4*Factor]);        
 set(grafOsc,'YTickLabel',[-4*Factor,-2*Factor,0,2*Factor,4*Factor]);     
 
 %------ Ya esta puesta la escala! ------------------

%-------------textos de valores de las ondas nuevas y anteriores!
 %Escogemos los textos de las ondas, primero mWatios, 
 %luego Voltios y luego Amperios! -Independientemente de la ESCALA!!
 if CheckP==1
    cadena1=[num2str(Ppeak),' mWatts ->'];     
 elseif CheckV==1
    cadena1=[num2str(Vpeak),' Volts ->'];
 elseif CheckI==1
    cadena1=[num2str(Ipeak),' mAmps ->'];
 end 
 set(handles.textZona1,'String',cadena1,'BackgroundColor',[0.6 0.85 1]);
 set(handles.textZona2,'String','-','BackgroundColor',[0.75 0.75 0.75]);
 set(handles.textZona3,'String','-','BackgroundColor',[0.75 0.75 0.75]);
 %------ Ya estan puestos los rotulos de ondas! ------------------ 
 
 %------------------------------------------------
 
 T1=Lgen/vp;          %Tiempo q tarda la onda en llegar al final del generador!
 l=[-Lgen:deltaL:L];  %Vector de coordenadas de longitud TOTAL
 t=[0:deltaT:T1];     %Vector de coordenadas de tiempo! 
                      %Para las iteraciones hasta la primera reflexion!!

%para dibujar en el osciloscopio
  Osc=get(handles.axesOsc,'UserData');  %cojo la estructura de datos time,V,I,P  
  LongOsc=get(handles.textLOsc,'UserData'); %el punto donde ponemos la sonda del
                                            %osciloscopio
%para dibujar los markers usamos una estructura para guardar la grafica!
  StGraf=get(handles.frameGraf,'UserData');
                                            
 %Empezamos las iteraciones!
 NumIter=floor(Lgen/deltaL +1) ; %numero de iteraciones necesarias hasta que la onda
    %progresiva inicial recorra toda la longitud de la linea del generador!
 for n=[1:NumIter]
      cadena=['Iter= ',num2str(n),'/',num2str(NumIter)];
      set(handles.textIter,'String',cadena);  
       %Actualizo el instante de tiempo
      to=t(n);  %instante q estoy evaluando!
      cadena=['TIME= ',num2str(to*FactorT)];  
      set(handles.textTime,'String',cadena);
      cadena=['( ',UnitT,' )'];
      set(handles.textUnitT,'String',cadena);
      %la onda progresiva la expresamos a partir del indice n que nos dice la
      %iteracion en que estamos, y ademas el numero de puntos en z (y en t)
      %que hemos calculado!
      %Vnueva sera la onda de tension nueva (porgresiva o regresiva)
      %que se sumara a las ondas ya presentes para calcular la onda TOTAL!
        %Cojo solo los puntos hasta donde ha llegado la onda! dede 1:n
      Vnueva=VNew(0,n,l,Vpeak,w,to,beta,0);
                        %Este es el VECTOR de la onda de
                        % tension progresiva en este instante (hasta donde
                        %haya llegado!)
      
      %Vector de onda de tension TOTAL en toda la lina de transmision!
      Vtotal=Vnueva; %como solo hay una onda al onda total es la nueva!
      Vnuevas=Vnueva;
      Vviejas=zeros(size(l));

%para dibujar en el osciloscopio usamos Osc.time,V,I,P
      Osc.time=[Osc.time,to];  %asi vamos ampiando la escala de tiempo!
      
%------- Ahora dibujo la onda de tension total o la q me pidan y la linea...------
      mira=[CheckV,CheckI,CheckP];
      Cuantos=length(find(mira==1)); %par aver si hay mas de un tipo de onda
      if CheckV==1
              G=get(handles.radiobuttonVX10,'UserData');                        
          if Cuantos>1
              %Cojo la ganancia de la sonda de tension (G=1 o G=10)
              %que se aplica a la onda de tension total, y solo cuando
              %se representa con otras ondas (de corriente y/o potencia)
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'c',1);
              StGraf.Graf1=G*Vtotal;
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'r',1);              
              StGraf.Graf1=G*Vtotal;
              StGraf.Graf2=G*Vnuevas;
              StGraf.Graf3=G*Vviejas;              
          end
          %para dibujar en el osciloscopio
          G=get(handles.radiobuttonVX10,'UserData');                        
          Osc.V=[Osc.V,G*Vtotal(l==LongOsc)];
      end
      
      if CheckI==1
          Inuevas=Vnuevas/Zog*1000; %en mAps
          Iviejas=Vviejas/Zog*1000;
          Itotal=Inuevas+Iviejas;
          if Cuantos>1
              if CheckV==0
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',1);
              else
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',0);                  
              end
              StGraf.Graf2=Itotal;              
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'r',1);              
              StGraf.Graf1=Itotal;
              StGraf.Graf2=Inuevas;
              StGraf.Graf3=Iviejas;              
          end          
          %para dibujar en el osciloscopio
          Osc.I=[Osc.I,Itotal(l==LongOsc)];          
      end
      
      if CheckP==1
          Inuevas=Vnuevas/Zog*1000; %en mAps
          Iviejas=Vviejas/Zog*1000;
          Itotal=Inuevas+Iviejas;
          
          Pnuevas=Vnuevas.*Inuevas; %en mWatts
          Pviejas=Vviejas.*Iviejas;
          Ptotal=Vtotal.*Itotal;
          if Cuantos>1
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',0);                  
              StGraf.Graf3=Ptotal;                            
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',1);              
              StGraf.Graf1=Ptotal;
              StGraf.Graf2=Pnuevas;
              StGraf.Graf3=Pviejas;                            
          end          
          %para dibujar en el osciloscopio
          Osc.P=[Osc.P,Ptotal(l==LongOsc)];
      end
      %Guardamos las ondas temporales obtenidas
      set(handles.axesOsc,'UserData',Osc);
      
      %Ahora dibujamos en el osciloscopio si esta seleccionado!
      CheckOsc=get(handles.checkboxOsc,'Value');
      if CheckOsc==1
          dibujaOsc(handles,Factor,UnitT,FactorT,UnitL,FactorL);
      end
      
%---------- Fin de escoger que dibujamos; Tension, Corriente, Potencia... ---
      
      if Pause>0  %Si Pause =0 no hago pausa!
          pause(Pause);
      elseif (Pause==-1) %Si Pause = -1 tengo que pulsar una tecla
          
          %Y dejo que se pueda medir con los markers!
          StGraf.l=l;  %El vector de coordenadas de longitud
          StGraf.F=Factor; %El Factor para la escala vertical (Vpeak,Ipeak,Ppeak...)
          StGraf.handles=handles; %Los handles para coge rlo que necesite!
          set(handles.frameGraf,'UserData',StGraf);
          %Y ahora, si esta activado lo de Markers On dibujamos los markers!
          CheckMarker=get(handles.checkboxMarkers,'Value');
          if CheckMarker==1
              %Y dibujo los markers que toquen!
              dibujaEstructGraf(handles)    
          end
          
          pause;
      elseif Pause==0
          drawnow;         
      end
      
  end %de iterar para hacer la animacion de la primera onda!
set(handles.pushbuttonVer,'UserData',1);  %Asi indico que ya se ha simulado 
                                    % la PRIMERA REFLEXION !!

%Tambien guardo el instante de tiempo por el q me habia quedado (en segundos)
%en UserData de textTime
set(handles.textTime,'UserData',to);
%Y guardo como instante inicial del paso hecho el valor 0 segundos
set(handles.textUnitT,'UserData',0);

cadena=['First reflexion reached.Press Continue, Repeat or Reset...'];
set(handles.textInfo,'String',cadena);  

 %Ponemos el siguiente parametro a 0 para indicar q YA NO 
 %estamos en medio de iteracion y asi no hacemos caso de las teclas!
 set(handles.textIter,'UserData',0);

 %------------------------------------------------------------------
    %La imagen la guardo por si quiero dibujar sobre ella markers!
   %sera la estructura de la imagen reinicializada!
    StGraf.l=l;  %El vector de coordenadas de longitud
    StGraf.F=Factor; %El Factor para la escala vertical (Vpeak,Ipeak,Ppeak...)
    StGraf.handles=handles; %Los handles para coge rlo que necesite!
    %Las graficas que almaceno depende de lo que haya representado
    %pueden ser las ondas de tension,corriente y potencia (V,I,P)
    %o de cualquiera de estas tres ondas sus ondas Totales,Nuevas y Viejas
    % handles.frameGraf.'UserData'.Graf1=grafica1;  
    % handles.frameGraf.'UserData'.Graf2=grafica2;
    % handles.frameGraf.'UserData'.Graf3=grafica3;    
    %Con handles.frameGraf.'UserData'.GrafActual digo cual es la grafica 
    %activa, que es la que hemos escogido para representar los markers!
    %Guardo al estrucutra asi creada en UserData de frameGraf!!
    set(handles.frameGraf,'UserData',StGraf);
    
    %Y ahora, si esta activado lo de Markers On dibujamos los markers!
    CheckMarker=get(handles.checkboxMarkers,'Value');
    if CheckMarker==1
     %Y dibujo los markers que toquen!
     dibujaEstructGraf(handles)    
    end
    
%--------------------------------------------------------------------------
    

%-------------- Fin de Ver la primera onda ------------------------------





%--------------------------------------------------------------------------
% -- BOTON para CONTINUAR la ANIMACION de ONDAS REFLEJADAS y TRASNMITIDAS--
% -------------------------------------------------------------------------
function varargout = pushbuttonContinue_Callback(h, eventdata, handles, varargin)
Cod=get(handles.pushbuttonVer,'UserData');  
%Con este codigo conozco por que lugar voy de las multiples reflexiones
%que puede haber... Cod=0 #No ha empezado la simulacion!
%                   Cod=1 #Ya hecha la primera onda hasta el conector ->
%                   Cod=2 #Ya hecha la primera reflexion hasta el generador <-
%                                    + transmision desde conector ->
%                                      y onda ha llegado a la carga
%------ El resto de casos son repetiutivos....! ------------------------
%                   Cod=3 #Ya hecha la segunda reflexion desde la carga <-
%                                      y onda ha llegado al conector <-
%                   Cod=4 #Ya hecha la tercera reflexion hacia la carga ->
%                                      y onda refl  ha llegado a la carga ->
%                                      y onda trans ha llegado al generador <-
%                   Cod=5 #Ya hecha la segunda reflexion desde la carga <-
%                                      y onda ha llegado al conector <-
%                   Cod=6 #Ya hecha la tercera reflexion hacia la carga ->
%                                      y onda refl  ha llegado a la carga ->
%                                      y onda trans ha llegado al generador <-
%en general:    Cod=par   == reflexion en carga    -->
%               Cod=impar == reflexion en conector <--

if Cod==0  %Primero debo comenzar la simulacion lanzando la primera onda!
    cadena=['Sorry, but you must first launch the first progressive wave!'];
    set(handles.textInfo,'String',cadena);  
    return;
end

%------- Recogida de datos e inicializacion de parametros --------------------
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     return;
 else
     cadena=['Initializing parameters...'];
     set(handles.textInfo,'String',cadena);     
 end

 Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
 Pause=get(handles.editPause,'UserData');
 if (Res==0)|(Pause==-2)
     cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
     set(handles.textInfo,'String',cadena);     
     return;
 end
     
 CheckIter=get(handles.textIter,'UserData');
 if CheckIter==1
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);     
     return;     
 end
 %Ponemos el siguiente parametro a 1 para indicar q estamos en medio de 
 %iteracion y asi no hacemos caso de las teclas!
 set(handles.textIter,'UserData',1);
 
 %Inicializacion de parametros que usamos...
 Vpeak=X(1);   %Amplitud de onda progresiva incicial en Votls pico
 fo=X(2)*1E6;  %frecuencia de la onda en Hz (paso de MHz a Hz)
 lambda=X(3);  %longitud de onda en m
 vp=X(4);      %velocidad de propagacion en m/sg
 L=X(5);       %longitud de la linea en m
 ModRhoL=X(6); %modulo del coeficiente de reflexion de carga
 AngleRhoL=X(7); %angulo del coeficiente de reflexion de carga en radianes
 ModRhog=X(8); %modulo del coeficiente de reflexion de generador
 AngleRhog=X(9); %angulo del coeficiente de reflexion de generador en radianes
 beta=2*pi/lambda; %numero de onda en rad/m
 w=2*pi*fo;       %pulsacion angular en rad/seg
 T=L/vp;         %tiempo q le lleva a la onda a recorrer la linea en segundos
 Lgen=L/4;       %longitud de la linea del generador, que esta adaptada a la
                 %impedancia del mismo, y que ponemos mas peque�a que la longitud
                 %de la linea para q las reflexiones tarden menos en llegar
                 %a los limites del generador q al extremo de la linea!
 
 deltaL=lambda/Res;  %resolucion en L en metros
 deltaT=deltaL/vp;   %resolucion en t en segundos
 %Para calcular la corrientes y potencias a partir de las ondas de tension
 %usamos las impedancias caracteristicas de las lineas del gendro Zog y la larga Zo
 Zo=X(10);  %Imped. caracteristica de la linea larga
 Zog=X(11); %Imped. caracteristica de la linea del generador!

 %Para calcular la corrientes y potencias a partir de las ondas de tension
 %usamos las impedancias caracteristicas de las lineas del gendro Zog y la larga Zo
 Zo=X(10);  %Imped. caracteristica de la linea larga
 Zog=X(11); %Imped. caracteristica de la linea del generador!
 
 %Cogemos unidades adecuadas para la longitud y el tiempo de manera que
 %podamos visualizarlas bien! Me baso en Ttotal para el tiempo y en L para longitud
   %Longitud:
 if (L>1000)
     UnitL='Km';FactorL=1/1000;
 elseif (L>0.1)
     UnitL='m';FactorL=1;
 elseif (L>1/10000)
     UnitL='mm';FactorL=1000;
 else
     UnitL='microm';FactorL=1000000;
 end
 %Guardamos FactorL en UserData de textDeltaL
 set(handles.textDeltaL,'UserData',FactorL); 
 
   %Tiempo:
 if (T>60)
     UnitT='min';FactorT=1/60;
 elseif (T>0.1)
     UnitT='sg';FactorT=1;
 elseif (T>1/10000)
     UnitT='msg';FactorT=1000;
 elseif (T>1/10000000)
     UnitT='micrsg';FactorT=1000000;     
 elseif (T>1/10000000000)
     UnitT='nanosg';FactorT=1000000000;
 else
     UnitT='picosg';FactorT=1000000000000;
 end
 %Guardamos FactorL en UserData de textDeltaL
 set(handles.textDeltaT,'UserData',FactorT); 
 

 %Vemos que tipos de ondas hay que representar!------------------------
  CheckV=get(handles.radiobuttonVolt,'Value');
  CheckI=get(handles.radiobuttonCurr,'Value');
  CheckP=get(handles.radiobuttonPow,'Value');
  
 %-------------------- ESCALA ---------------------------- 
 graf=handles.axesLinea;
 axes(graf) %seleccionamos la grafica
 grafOsc=handles.axesOsc;  

 Ppeak=Vpeak^2/(2*Zog)*1000;  %Paso a mWatios!
 Ipeak=Vpeak/Zog*1000;        %Paso a mAmperios!

 %---------------para ver la escala q usamos en la grafica!!
 Picos=[Vpeak,Ipeak,Ppeak];
 Checks=[CheckV,CheckI,CheckP];
 Mult=Picos.*Checks;  %asi solo hago el maximo de las unidades activas!
 MaxMult=max(Mult);
 PosMax=find(Mult==MaxMult);
 
 if PosMax==1
    ylabel('Volts');                  
    Factor=Vpeak;    
elseif PosMax==2
    ylabel('mAmps');                  
    Factor=Ipeak;    
elseif PosMax==3
    ylabel('mWatts');                  
    Factor=Ppeak;    
end
 
%el Factor sirve para determinar la escala vertical de las graficas 
%lo voy a guardar en UserData de checkboxMarkers
set(handles.checkboxMarkers,'UserData',Factor);

% Grafica de distribucion L
 set(graf,'YTick',[-4*Factor,-2*Factor,0,2*Factor,4*Factor]);        
 set(graf,'YTickLabel',[-4*Factor,-2*Factor,0,2*Factor,4*Factor]);     
 dibujaLinea(Lgen,L,Factor,handles); 
 axis([-Lgen-Lgen/8 L+Lgen/8 -4.3*Factor 4.3*Factor]);        
% Grafica de distribucion en T = Osciloscopio 
 axes(grafOsc)    
 set(grafOsc,'YTick',[-4*Factor,-2*Factor,0,2*Factor,4*Factor]);        
 set(grafOsc,'YTickLabel',[-4*Factor,-2*Factor,0,2*Factor,4*Factor]);     
 
%para poder dibujar en el osciloscopio
  Osc=get(handles.axesOsc,'UserData');  %cojo la estructura de datos time,V,I,P  
  LongOsc=get(handles.textLOsc,'UserData'); %el punto donde ponemos la sonda del
                                            %osciloscopio
%para dibujar los markers usamos una estructura para guardar la grafica!
  StGraf=get(handles.frameGraf,'UserData');
 
 %------ Ya esta puesta la escala! ------------------  
 
 
%------------ Fin de recogida de datos --------------------------------------

l=[-Lgen:deltaL:L];  %Vector de coordenadas de longitud TOTAL
tant=get(handles.textTime,'UserData'); %cojo el instante en que me habia quedado (en segundos!)

% -- Calculo de coeficientes de reflexion y de transmision --------------
   % Primera reflexion
   %del generador al conector, que es un poco diferente ya que es la UNICA 
   %reflexion de la onda del generador --> conector, que no habra otra igual!
   % pgen'= - pgen, ya que lo veo en la otra direccion
   % pgen=(Zg-Zo)/(Zg+Zo) pgen'=(Zo-Zg)/(Zo+Zg) --> pgen'= - pgen
   % GP =Generador Prima
 %-- Coeficiente de REFLEXION   
   modRhoGP=get(handles.textModRhog,'UserData');     %Mismo modulo
   AngRhog=get(handles.textAngleRhog,'UserData');
   angleRhoGPA=AngRhog-pi; 
      %El Angulo (en radianes) es el de Rhog pero restandole 180 grados!   
  %Correccion de la fase de los coeficientes de reflexion para que den bien!   
   angleRhoGP=angleRhoGPA-2*beta*Lgen;   

 %-- Coeficiente de TRANSMISION   
   TGP=1 +  modRhoGP*exp( j*angleRhoGPA ); %Sumo la onda incidente con la reflejada!
   modTrsGP=abs(TGP);       %Su modulo
   angleTrsGP=angle(TGP);   %Su fase
   

 %-- Coeficiente de REFLEXION desde la linea a la CARGA
   modRhoL=get(handles.textModRhoL,'UserData');     
   angleRhoLA=get(handles.textAngleRhoL,'UserData');
      %El Angulo esta en radianes!  
  %Correccion de la fase de los coeficientes de reflexion para que den bien!         
   angleRhoL=angleRhoLA-2*beta*(L+Lgen);      
      
 %-- Coeficiente de reflexion desde el generador al conector GP (Gnrtor Prima)
   modRhoG=get(handles.textModRhog,'UserData');     %Mismo modulo
   angleRhoGA=get(handles.textAngleRhog,'UserData');
  %Correccion de la fase de los coeficientes de reflexion para que den bien!            
   angleRhoG=angleRhoGA+2*beta*Lgen; 
 
 %-- Coeficiente de TRANSMISION desde el generador al conector   
   TG=1 +  modRhoG*exp( j*angleRhoGA ); %Sumo la onda incidente con la reflejada!
   modTrsG=abs(TG);       %Su modulo
   angleTrsG=angle(TG);   %Su fase



% ------------------------------------------------------------------------ 
% |   Ahora analizamos cada uno de los posibles casos de reflexiones!!   |
% ------------------------------------------------------------------------

%----------------------------------------------------------------------------
%----------------- CASO de ONDAS desde REFLEXION de CONECTOR a GENERADOR------
if Cod==1  %

 if Pause==-1
     cadena=['Showing step # ',num2str(Cod),' ...','Press any key to show next frame!'];
     set(handles.textInfo,'String',cadena);     
 else
     cadena=['Showing step # ',num2str(Cod),' ...'];
     set(handles.textInfo,'String',cadena);
 end
 
%-------------textos de valores de las ondas nuevas y anteriores!
 %Escogemos los textos de las ondas, primero mWatios, 
 %luego Voltios y luego Amperios! -Independientemente de la ESCALA!!
 if CheckP==1
    cadena1=[num2str(Ppeak*(modRhoGP^2)),' mWatts <-'];     
    cadena2=[num2str(Ppeak*(1-modRhoGP^2)),' mWatts ->'];         
 elseif CheckV==1
    cadena1=[num2str(Vpeak*modRhoGP),' Volts <-'];
    cadena2=[num2str(Vpeak*modTrsGP),' Volts ->'];    
 elseif CheckI==1
    cadena1=[num2str(Ipeak*modRhoGP),' mAmps <-'];
    cadena2=[num2str(Ipeak*modTrsGP),' mAmps ->'];    
 end 
 set(handles.textZona1,'String',cadena1,'BackgroundColor',[0.6 0.85 1]);
 set(handles.textZona2,'String',cadena2,'BackgroundColor',[0.6 0.85 1]);
 set(handles.textZona3,'String','-','BackgroundColor',[0.75 0.75 0.75]);
 %------ Ya estan puestos los rotulos de ondas! ------------------ 


 T=Lgen/vp;          %Tiempo q tarda la onda reflejada en llegar al geenrador
 t=[tant:deltaT:T+tant];  %Vector de coordenadas de tiempo! 
                     %Para las iteraciones hasta la absorcion del generador!!
 NumIterLg=floor(Lgen/deltaL +1) ; %numero de iteraciones necesarias hasta que la onda                         
     %reflejada recorra toda la longitud de la linea del generador! 
 %Vreg=zeros(size(l));   %esta sera la onda reflejada hacia el generador
 %Vpro=zeros(size(l));   %esta sera la onda transmitida hacia la carga
 %VLg=zeros(size(l));    %esta es la onda q ya esta ocupando toda la linea del gnrador
 %Vtotal=zeros(size(l)); %Esta sera la onda total en TODA las LINEAS

 
 %Empezamos las iteraciones!

 for n=[1:NumIterLg]
      cadena=['Iter= ',num2str(n),'/',num2str(NumIterLg)];
      set(handles.textIter,'String',cadena);  
       %Actualizo el instante de tiempo
      to=t(n);  %instante q estoy evaluando!
      cadena=['TIME= ',num2str(to*FactorT)];  
      set(handles.textTime,'String',cadena);
      cadena=['( ',UnitT,' )'];
      set(handles.textUnitT,'String',cadena);
      
      %Onda reflejada hacia el generador!
      %los limites [NumIterLg+1-n:NumIterLg]; %para la onda regresiva en Lg      
      %y asi formar el vector regresivo desde el conector al genrdor
      Vreg=VNew(NumIterLg+1-n,NumIterLg,l,Vpeak*modRhoGP,w,to,-beta,angleRhoGP);
        %Esta es la onda regresiva, calculada en los puntos por los q se
        %propaga, y para el resto de puntos vale cero!
        
      %Onda transmitida hacia la carga mientras tanto!        
      %los limites [NumIterLg+1:NumIterLg-2+n]; %para la onda progresiva en L, 
       % mientras la onda regresiva en Lg se propaga hasta el generador
       % y asi formar el Vector progresivo desde conector a la carga
      Vpro=VNew(NumIterLg,NumIterLg-2+n,l,Vpeak*modTrsGP,w,to,beta,angleTrsGP);

      
      %Y falta la onda que ya estaba en la linea del generador, la primera
      %onda progresiva, que ya esta ocupando toda la linea
      % Como es estacionaria, los limtes seran [1:NumIterLg];
      VLg=VNew(0,NumIterLg,l,Vpeak,w,to,beta,0);
      
      %Y para cada instante la onda total es la suma de las tres:
      Vtotal=VLg+Vreg+Vpro;
      Vnuevas=Vreg+Vpro;
      Vviejas=VLg;
      
%para dibujar en el osciloscopio usamos Osc.time,V,I,P
      Osc.time=[Osc.time,to];  %asi vamos ampiando la escala de tiempo!
                         
%------- Ahora dibujo la onda de tension total o la q me pidan y la linea...------
      mira=[CheckV,CheckI,CheckP];
      Cuantos=length(find(mira==1)); %par aver si hay mas de un tipo de onda
      if CheckV==1
              G=get(handles.radiobuttonVX10,'UserData');          
          if Cuantos>1
              %Cojo la ganancia de la sonda de tension (G=1 o G=10)
              %que se aplica a la onda de tension total, y solo cuando
              %se representa con otras ondas (de corriente y/o potencia)
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'c',1);
              StGraf.Graf1=G*Vtotal;              
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'r',1);              
              StGraf.Graf1=G*Vtotal;
              StGraf.Graf2=G*Vnuevas;
              StGraf.Graf3=G*Vviejas;                            
          end
          %para dibujar en el osciloscopio
          G=get(handles.radiobuttonVX10,'UserData');                        
          Osc.V=[Osc.V,G*Vtotal(l==LongOsc)];          
      end
      
      if CheckI==1
          Inuevas=(Vpro/Zo-Vreg/Zog)*1000; %en mAps
          Iviejas=VLg/Zog*1000;
          Itotal=Inuevas+Iviejas;
          if Cuantos>1
              if CheckV==0
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',1);
              else
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',0);                  
              end
              StGraf.Graf2=Itotal;              
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'r',1);              
              StGraf.Graf1=Itotal;
              StGraf.Graf2=Inuevas;
              StGraf.Graf3=Iviejas;              
          end          
          %para dibujar en el osciloscopio
          Osc.I=[Osc.I,Itotal(l==LongOsc)];          
      end
      
      if CheckP==1
          Inuevas=(Vpro/Zo-Vreg/Zog)*1000; %en mAps
          Iviejas=VLg/Zog*1000;
          Itotal=Inuevas+Iviejas;          
          
          Pnuevas=Vnuevas.*Inuevas; %en mWatts
          Pviejas=Vviejas.*Iviejas;
          Ptotal=Vtotal.*Itotal;
          if Cuantos>1
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',0);                  
              StGraf.Graf3=Ptotal;                                          
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',1);              
              StGraf.Graf1=Ptotal;
              StGraf.Graf2=Pnuevas;
              StGraf.Graf3=Pviejas;                            
          end          
          %para dibujar en el osciloscopio
          Osc.P=[Osc.P,Ptotal(l==LongOsc)];
      end
      %Guardamos las ondas temporales obtenidas
      set(handles.axesOsc,'UserData',Osc);
      
      %Ahora dibujamos en el osciloscopio si esta seleccionado!
      CheckOsc=get(handles.checkboxOsc,'Value');
      if CheckOsc==1
          dibujaOsc(handles,Factor,UnitT,FactorT,UnitL,FactorL);
      end

%---------- Fin de escoger que dibujamos; Tension, Corriente, Potencia... ---
      
      if Pause>0  %Si Pause =0 no hago pausa!
          pause(Pause);
      elseif (Pause==-1) %Si Pause = -1 tengo que pulsar una tecla
          
          %Y dejo que se pueda medir con los markers!
          StGraf.l=l;  %El vector de coordenadas de longitud
          StGraf.F=Factor; %El Factor para la escala vertical (Vpeak,Ipeak,Ppeak...)
          StGraf.handles=handles; %Los handles para coge rlo que necesite!
          set(handles.frameGraf,'UserData',StGraf);
          %Y ahora, si esta activado lo de Markers On dibujamos los markers!
          CheckMarker=get(handles.checkboxMarkers,'Value');
          if CheckMarker==1
              %Y dibujo los markers que toquen!
              dibujaEstructGraf(handles)    
          end
          
          pause;
      elseif Pause==0
          drawnow;
      end
      
  end %del for, iterar para hacer la animacion de la segunda parte!
  
%Tambien guardo el instante de tiempo por el q me habia quedado (en segundos)
%en UserData de textTime
set(handles.textTime,'UserData',to);
%Y el tiempo de inicio anterior en textUnitT
set(handles.textUnitT,'UserData',tant);

set(handles.pushbuttonVer,'UserData',2); %para indicar q ya hemos hecho
     %la reflexion regresiva q llega hasta el generador por su linea!

cadena=['Wave absorbed in the generator. Press Continue, Repeat or Reset...'];
set(handles.textInfo,'String',cadena);  
%--------------- FIN de PASO # 1 -------------------------------------


%----------------------------------------------------------------------------
%----------------- CASO de ONDAS desde REFLEXION de CONECTOR a CARGA---------
elseif Cod==2
 % Ahora no analizamos mas ondas reflejadas, sino que analizamos que
 %la onda que iba progresiva a la carga tiene q llegar a la carga
 % y ya hay una onda estacionaria en la linea del generador! (si existe
 % desadaptacion entre el generador y la linea que va a la carga)
 %PERO SI NECESITAMOS EL COEFICIENTE DE TRANSMISION DE LA ONDA
 %QUE SE ESTA PROPAGANDO POR LA LINEA y el de REFLEXION para conocer
 %la ONDA ESTACIONARIA q se ha formado en la linea del generador!!
 if Pause==-1
     cadena=['Showing step # ',num2str(Cod),' ...','Press any key to show next frame!'];
     set(handles.textInfo,'String',cadena);     
 else
     cadena=['Showing step # ',num2str(Cod),' ...'];
     set(handles.textInfo,'String',cadena); 
 end

%-------------textos de valores de las ondas nuevas y anteriores!
 %Escogemos los textos de las ondas, primero mWatios, 
 %luego Voltios y luego Amperios! -Independientemente de la ESCALA!!
 if CheckP==1
    cadena2=[num2str(Ppeak*(1-modRhoGP^2)),' mWatts ->'];         
 elseif CheckV==1
    cadena2=[num2str(Vpeak*modTrsGP),' Volts ->'];    
 elseif CheckI==1
    cadena2=[num2str(Ipeak*modTrsGP),' mAmps ->'];    
 end 
 cadena1=['No Reflection ->'];
 
 set(handles.textZona1,'String',cadena1,'BackgroundColor',[1 0.75 0]);
 set(handles.textZona2,'String',cadena2,'BackgroundColor',[0.6 0.85 1]);
 set(handles.textZona3,'String',cadena2,'BackgroundColor',[0.6 0.85 1]);
 %------ Ya estan puestos los rotulos de ondas! ------------------  

%----------------------------------------------------------- 
 T=(L-Lgen)/vp; %Tiempo q tarda la onda transmitida en llegar a la carga
                %desde el conector + Lg
 t=[tant:deltaT:T+tant];  %Vector de coordenadas de tiempo! 
                     %Para las iteraciones hasta la segunda reflexion!!
 NumIterLg=floor(Lgen/deltaL+1) ; %numero de iteraciones necesarias hasta que la onda                         
     %reflejada recorra toda la longitud de la linea del generador! 
     %ya que lo neecsitaremos tambien!!
 NumIterL=floor(L/deltaL+1);  %Tambien lo usare...
 NumIterLmas=floor((L-Lgen)/deltaL+1) ; %numero de iteraciones necesarias hasta que la onda                         
     %transmitida recorra la longitud de la linea que le quedaba por recorrer! 
 % Vpro   %esta sera la onda transmitida hacia la carga, que
          %le quedaba camino por recorrer hasta llgar a la carga!
 % VLg1,VLg2  %estas son las ondas q ya esta ocupando toda la linea del gnrador
 % Vtotal %Esta sera la onda total en TODA las LINEAS
                          
 %Empezamos las iteraciones!

 for n=[1:NumIterLmas]
      cadena=['Iter= ',num2str(n),'/',num2str(NumIterLmas)];
      set(handles.textIter,'String',cadena);  
       %Actualizo el instante de tiempo
      to=t(n);  %instante q estoy evaluando!
      cadena=['TIME= ',num2str(to*FactorT)];  
      set(handles.textTime,'String',cadena);
      cadena=['( ',UnitT,' )'];
      set(handles.textUnitT,'String',cadena);
             
      %Onda transmitida hacia la carga que le queda camino!        
      %limites:[NumIterLg+1:2*NumIterLg-2+n]; %para la onda progresiva en L, 
       % cuando la onda regresiva en Lg ya llego al generador!
      %para formar el Vector progresivo desde conector a la carga
      Vpro=VNew(NumIterLg,2*NumIterLg-2+n,l,Vpeak*modTrsGP,w,to,beta,angleTrsGP);
      
      %Y falta la onda que ya estaba en la linea del generador, que es
      %la suma de las dos ondas que ocupan toda la linea del generador!
      %los limites son toda la linea es estacionaria ya [1:NumIterLg];
      VLg1=VNew(0,NumIterLg,l,Vpeak,w,to,beta,0);
      VLg2=VNew(0,NumIterLg,l,Vpeak*modRhoGP,w,to,-beta,angleRhoGP);      
      VLg=VLg1+VLg2;
      
      %Y para cada instante la onda total es la suma de las dos:
      Vtotal=VLg+Vpro;
      Vnuevas=Vpro;
      Vviejas=VLg;

%para dibujar en el osciloscopio usamos Osc.time,V,I,P
      Osc.time=[Osc.time,to];  %asi vamos ampiando la escala de tiempo!
      
%------- Ahora dibujo la onda de tension total o la q me pidan y la linea...------
      mira=[CheckV,CheckI,CheckP];
      Cuantos=length(find(mira==1)); %par aver si hay mas de un tipo de onda
      if CheckV==1
              G=get(handles.radiobuttonVX10,'UserData');                        
          if Cuantos>1
              %Cojo la ganancia de la sonda de tension (G=1 o G=10)
              %que se aplica a la onda de tension total, y solo cuando
              %se representa con otras ondas (de corriente y/o potencia)
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'c',1);
              StGraf.Graf1=G*Vtotal;              
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'r',1);              
              StGraf.Graf1=G*Vtotal;
              StGraf.Graf2=G*Vnuevas;
              StGraf.Graf3=G*Vviejas;              
          end
          %para dibujar en el osciloscopio
          G=get(handles.radiobuttonVX10,'UserData');                        
          Osc.V=[Osc.V,G*Vtotal(l==LongOsc)];                    
      end
      
      if CheckI==1
          Inuevas=(Vpro/Zo)*1000; %en mAps
          Iviejas=(+VLg1/Zog-VLg2/Zog)*1000;
          Itotal=Inuevas+Iviejas;
          if Cuantos>1
              if CheckV==0
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',1);
              else
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',0);                  
              end
              StGraf.Graf2=Itotal;                            
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'r',1);              
              StGraf.Graf1=Itotal;
              StGraf.Graf2=Inuevas;
              StGraf.Graf3=Iviejas;              
          end          
          %para dibujar en el osciloscopio
          Osc.I=[Osc.I,Itotal(l==LongOsc)];          
      end
      
      if CheckP==1
          Inuevas=(Vpro/Zo)*1000; %en mAps
          Iviejas=(+VLg1/Zog-VLg2/Zog)*1000;
          Itotal=Inuevas+Iviejas;
          
          Pnuevas=Vnuevas.*Inuevas; %en mWatts
          Pviejas=Vviejas.*Iviejas;
          Ptotal=Vtotal.*Itotal;
          if Cuantos>1
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',0);                  
              StGraf.Graf3=Ptotal;                                          
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',1);              
              StGraf.Graf1=Ptotal;
              StGraf.Graf2=Pnuevas;
              StGraf.Graf3=Pviejas;                            
          end          
          %para dibujar en el osciloscopio
          Osc.P=[Osc.P,Ptotal(l==LongOsc)];
      end
      %Guardamos las ondas temporales obtenidas
      set(handles.axesOsc,'UserData',Osc);
      
      %Ahora dibujamos en el osciloscopio si esta seleccionado!
      CheckOsc=get(handles.checkboxOsc,'Value');
      if CheckOsc==1
          dibujaOsc(handles,Factor,UnitT,FactorT,UnitL,FactorL);
      end
      
%---------- Fin de escoger que dibujamos; Tension, Corriente, Potencia... ---
      
      if Pause>0  %Si Pause =0 no hago pausa!
          pause(Pause);
      elseif (Pause==-1) %Si Pause = -1 tengo que pulsar una tecla
          
          %Y dejo que se pueda medir con los markers!
          StGraf.l=l;  %El vector de coordenadas de longitud
          StGraf.F=Factor; %El Factor para la escala vertical (Vpeak,Ipeak,Ppeak...)
          StGraf.handles=handles; %Los handles para coge rlo que necesite!
          set(handles.frameGraf,'UserData',StGraf);
          %Y ahora, si esta activado lo de Markers On dibujamos los markers!
          CheckMarker=get(handles.checkboxMarkers,'Value');
          if CheckMarker==1
              %Y dibujo los markers que toquen!
              dibujaEstructGraf(handles)    
          end
          
          pause;
      elseif Pause==0
          drawnow;
      end
      
  end %del for, iterar para hacer la animacion de la tercera parte!
  
%Tambien guardo el instante de tiempo por el q me habia quedado (en segundos)
%en UserData de textTime
set(handles.textTime,'UserData',to);
%Y el t anterior
set(handles.textUnitT,'UserData',tant);

set(handles.pushbuttonVer,'UserData',3); %para indicar q ya hemos hecho
     %la onda progresiva q llega hasta la carga desde el conector!

cadena=['Wave has reached the load. Press Continue, Repeat or Reset...'];
set(handles.textInfo,'String',cadena);  
%--------------- FIN de PASO # 2 -------------------------------------    
    

%----------------------------------------------------------------------------
%----------------- CASO de ONDAS REFLEXION desde CARGA a CONECTOR---------
elseif Cod==3
 % Ahora si q tenemos q analizar la onda reflejada q va desde la carga hasta
 % el generador
  if Pause==-1
     cadena=['Showing step # ',num2str(Cod),' ...','Press any key to show next frame!'];
     set(handles.textInfo,'String',cadena);     
 else
     cadena=['Showing step # ',num2str(Cod),' ...'];
     set(handles.textInfo,'String',cadena); 
 end
 
%-------------textos de valores de las ondas nuevas y anteriores!
 %Escogemos los textos de las ondas, primero mWatios, 
 %luego Voltios y luego Amperios! -Independientemente de la ESCALA!!
 if CheckP==1     
    cadena3=[num2str(Ppeak*(1-modRhoGP^2)*modRhoL^2),' mWatts <-'];     
    cadena2=[num2str(Ppeak*(1-modRhoGP^2)),' mWatts ->'];         
 elseif CheckV==1
    cadena3=[num2str(Vpeak*modTrsGP*modRhoL),' Volts <-'];
    cadena2=[num2str(Vpeak*modTrsGP),' Volts ->'];    
 elseif CheckI==1
    cadena3=[num2str(Ipeak*modTrsGP*modRhoL),' mAmps <-'];
    cadena2=[num2str(Ipeak*modTrsGP),' mAmps ->'];    
 end 
 cadena1='-';
 set(handles.textZona1,'String',cadena1,'BackgroundColor',[0.75 0.75 0.75]);
 set(handles.textZona2,'String',cadena2,'BackgroundColor',[0.75 0.75 0.75]);
 set(handles.textZona3,'String',cadena3,'BackgroundColor',[0.6 0.85 1]);
 %------ Ya estan puestos los rotulos de ondas! ------------------ 

%---------------------------------------------------------------------
 T=(L)/vp;      %Tiempo q tarda la onda reflejada en llegar al conecto
                % desde la carga!
 t=[tant:deltaT:T+tant];  %Vector de coordenadas de tiempo! 
                     %Para las iteraciones hasta la segunda reflexion!!
 NumIterL=floor(L/deltaL +1) ; %numero de iteraciones necesarias hasta que la onda                         
     %reflejada recorra toda la longitud de la linea hasta el conector! 
 NumIterLg=floor(Lgen/deltaL +1);  %Tambien lo usare...
% Vreg=zeros(size(l));   %esta sera la onda reflejada de la carga
% VLg=zeros(size(l));    %esta es la onda q ya esta ocupando toda la linea del gnrador
% VL=zeros(size(l));    %esta es la onda q ya esta ocupando toda la linea 
% Vtotal=zeros(size(l)); %Esta sera la onda total en TODA las LINEAS


 %Empezamos las iteraciones!

 for n=[1:NumIterL]
      cadena=['Iter= ',num2str(n),'/',num2str(NumIterL)];
      set(handles.textIter,'String',cadena);  
       %Actualizo el instante de tiempo
      to=t(n);  %instante q estoy evaluando!
      cadena=['TIME= ',num2str(to*FactorT)];  
      set(handles.textTime,'String',cadena);
      cadena=['( ',UnitT,' )'];
      set(handles.textUnitT,'String',cadena);
             
      %Onda transmitida desde la carga hacia el conector! 
      %limites: [NumIterL+NumIterLg-n:NumIterL+NumIterLg-2]; 
      %para la onda regresiva en L,y tener el vector regresivo desde la carga al conector
      Vreg=VNew(NumIterL+NumIterLg-n,NumIterL+NumIterLg-1,l,...
                Vpeak*modRhoL*modTrsGP,w,to,-beta,angleTrsGP+angleRhoL);
      
      %Y falta la onda que ya estaba en la linea del generador, que es
      %la suma de las dos ondas que ocupan toda la linea del generador!
      %limtes estacionarios: [1:NumIterLg];
      VLg1=VNew(0,NumIterLg,l,Vpeak,w,to,beta,0);
      VLg2=VNew(0,NumIterLg,l,Vpeak*modRhoGP,w,to,-beta,angleRhoGP);
      VLg=VLg1+VLg2;
      
      %Y tambien falta la onda progresiva que esta ya en toda la linea
      %ocupando toda la linea (st=estacionaria)
      %limites: [NumIterLg+1:NumIterLg+NumIterL-1]; %para la onda 
      %progresiva en L, cuando la onda regresiva en Lg ya llego al generador!
      VL=VNew(NumIterLg,NumIterLg+NumIterL-1,l,...
              Vpeak*modTrsGP,w,to,beta,angleTrsGP);
      
      %Y para cada instante la onda total es la suma de las dos:
      Vtotal=VLg+VL+Vreg;
      Vnuevas=Vreg;
      Vviejas=VLg+VL;

%para dibujar en el osciloscopio usamos Osc.time,V,I,P
      Osc.time=[Osc.time,to];  %asi vamos ampiando la escala de tiempo!
      
%------- Ahora dibujo la onda de tension total o la q me pidan y la linea...------
      mira=[CheckV,CheckI,CheckP];
      Cuantos=length(find(mira==1)); %par aver si hay mas de un tipo de onda
      if CheckV==1
              G=get(handles.radiobuttonVX10,'UserData');                        
          if Cuantos>1
              %Cojo la ganancia de la sonda de tension (G=1 o G=10)
              %que se aplica a la onda de tension total, y solo cuando
              %se representa con otras ondas (de corriente y/o potencia)
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'c',1);
              StGraf.Graf1=G*Vtotal;              
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'r',1);              
              StGraf.Graf1=G*Vtotal;
              StGraf.Graf2=G*Vnuevas;
              StGraf.Graf3=G*Vviejas;              
          end
          %para dibujar en el osciloscopio
          G=get(handles.radiobuttonVX10,'UserData');                        
          Osc.V=[Osc.V,G*Vtotal(l==LongOsc)];
      end
      
      if CheckI==1
          Inuevas=-Vreg/Zo*1000; %en mAps
          Iviejas=(+VLg1/Zog-VLg2/Zog+VL/Zo)*1000;
          Itotal=Inuevas+Iviejas;
          if Cuantos>1
              if CheckV==0
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',1);
              else
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',0);                  
              end
              StGraf.Graf2=Itotal;                            
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'r',1);              
              StGraf.Graf1=Itotal;
              StGraf.Graf2=Inuevas;
              StGraf.Graf3=Iviejas;              
          end          
          %para dibujar en el osciloscopio
          Osc.I=[Osc.I,Itotal(l==LongOsc)];          
      end
      
      if CheckP==1
          Inuevas=-Vreg/Zo*1000; %en mAps
          Iviejas=(+VLg1/Zog-VLg2/Zog+VL/Zo)*1000;
          Itotal=Inuevas+Iviejas;          
          
          Pnuevas=Vnuevas.*Inuevas; %en mWatts
          Pviejas=Vviejas.*Iviejas;
          Ptotal=Vtotal.*Itotal;
          if Cuantos>1
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',0);                  
              StGraf.Graf3=Ptotal;                                          
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',1);              
              StGraf.Graf1=Ptotal;
              StGraf.Graf2=Pnuevas;
              StGraf.Graf3=Pviejas;                            
          end          
          %para dibujar en el osciloscopio
          Osc.P=[Osc.P,Ptotal(l==LongOsc)];
      end
      %Guardamos las ondas temporales obtenidas
      set(handles.axesOsc,'UserData',Osc);
      
      %Ahora dibujamos en el osciloscopio si esta seleccionado!
      CheckOsc=get(handles.checkboxOsc,'Value');
      if CheckOsc==1
          dibujaOsc(handles,Factor,UnitT,FactorT,UnitL,FactorL);
      end
      
%---------- Fin de escoger que dibujamos; Tension, Corriente, Potencia... ---
      
      if Pause>0  %Si Pause =0 no hago pausa!
          pause(Pause);
      elseif (Pause==-1) %Si Pause = -1 tengo que pulsar una tecla
          
          %Y dejo que se pueda medir con los markers!
          StGraf.l=l;  %El vector de coordenadas de longitud
          StGraf.F=Factor; %El Factor para la escala vertical (Vpeak,Ipeak,Ppeak...)
          StGraf.handles=handles; %Los handles para coge rlo que necesite!
          set(handles.frameGraf,'UserData',StGraf);
          %Y ahora, si esta activado lo de Markers On dibujamos los markers!
          CheckMarker=get(handles.checkboxMarkers,'Value');
          if CheckMarker==1
              %Y dibujo los markers que toquen!
              dibujaEstructGraf(handles)    
          end
          
          pause;
      elseif Pause==0
          drawnow;
      end
      
  end %del for, iterar para hacer la animacion de la tercera parte!
  
%Tambien guardo el instante de tiempo por el q me habia quedado (en segundos)
%en UserData de textTime
set(handles.textTime,'UserData',to);
%Y el t anterior
set(handles.textUnitT,'UserData',tant);

set(handles.pushbuttonVer,'UserData',4); %para indicar q ya hemos hecho
     %la onda progresiva q llega hasta la carga desde el conector!

cadena=['Wave has reached the connector. Press Continue, Repeat or Reset...'];
set(handles.textInfo,'String',cadena);  
%--------------- FIN de PASO # 3 -------------------------------------  
    


%----------------------------------------------------------------------------
%----------------- CASO de ONDAS REFLEXION desde CONECTOR a CARGA---------
%------------- icnluyendo la onda transmitida del CONECTOR a GENERADOR
elseif (Cod>=4) & (mod(Cod,2)==0) %para Cod=4,6,8,10,12...
 % Ahora si q tenemos q analizar la onda reflejada q va desde la carga hasta
 % el generador y ademas la onda reflejada en el conector desde la carga
 % q va de nuevo a la carga y que a su vez tiene onda transmitida al genrdor.

%-- Paso 1, la onda transmitida desde el conector al gnrador debe llegar al mismo
 if Pause==-1
     cadena=['Showing step # ',num2str(Cod),' -1 ...','Press any key to show next frame!'];
     set(handles.textInfo,'String',cadena);     
 else
     cadena=['Showing step # ',num2str(Cod),' -1...'];
     set(handles.textInfo,'String',cadena);
 end
 
 %para calcular las amplitudes de las nuevas ondas necesitamos
 %conocer el paso en el q estamos!
 NumVeces=Cod-3-(Cod-4)/2;  %Numero de ondas a sumar! 
 Mod1=modTrsGP* modTrsG* modRhoL^NumVeces* modRhoG^(NumVeces-1); 
 Mod2=modTrsGP* (modRhoL* modRhoG)^NumVeces;
 Mod3=modTrsGP* modRhoL^NumVeces* modRhoG^(NumVeces-1);  
 %Coeficientes para las potencias!!
 ModP1=(1-modRhoGP^2)* (1-modRhoG^2)* modRhoL^(2*NumVeces)*modRhoG^(2*NumVeces-2); 
 ModP2=(1-modRhoGP^2)* (modRhoL* modRhoG)^(2*NumVeces);
 ModP3=(1-modRhoGP^2)* modRhoL^(2*NumVeces)* modRhoG^(2*NumVeces-2);  
 
 %-------------textos de valores de las ondas nuevas y anteriores!
 %Escogemos los textos de las ondas, primero mWatios, 
 %luego Voltios y luego Amperios! -Independientemente de la ESCALA!! 
 if CheckP==1     
    cadena1=[num2str(Ppeak*ModP1),' mWatts <-']; 
    cadena2=[num2str(Ppeak*ModP2),' mWatts ->']; 
    cadena3=[num2str(Ppeak*ModP3),' mWatts <-'];   
 elseif CheckV==1
    cadena1=[num2str(Vpeak*Mod1),' Volts <-']; 
    cadena2=[num2str(Vpeak*Mod2),' Volts ->']; 
    cadena3=[num2str(Vpeak*Mod3),' Volts <-'];   
 elseif CheckI==1
    cadena1=[num2str(Ipeak*Mod1),' mAmps <-']; 
    cadena2=[num2str(Ipeak*Mod2),' mAmps ->']; 
    cadena3=[num2str(Ipeak*Mod3),' mAmps <-'];   
 end 
 set(handles.textZona1,'String',cadena1,'BackgroundColor',[0.6 0.85 1]); 
 set(handles.textZona2,'String',cadena2,'BackgroundColor',[0.6 0.85 1]);
 set(handles.textZona3,'String',cadena3,'BackgroundColor',[0.75 0.75 0.75]);  
 %------ Ya estan puestos los rotulos de ondas! ------------------ 
 
%-------------------------------------------------------------------- 
 T=Lgen/vp;          %Tiempo q tarda la onda reflejada en llegar al geenrador
 t=[tant:deltaT:T+tant];  %Vector de coordenadas de tiempo! 
                     %Para las iteraciones hasta la absorcion del generador!!
 NumIterLg=floor(Lgen/deltaL +1) ; %numero de iteraciones necesarias hasta que la onda                         
     %reflejada recorra toda la longitud de la linea del generador! 
 NumIterL=floor(L/deltaL +1) ; %tambien lo usare!
 
 
 %Empezamos las iteraciones!

 for n=[1:NumIterLg]
      cadena=['Iter= ',num2str(n),'/',num2str(NumIterLg)];
      set(handles.textIter,'String',cadena);  
       %Actualizo el instante de tiempo
      to=t(n);  %instante q estoy evaluando!
      cadena=['TIME= ',num2str(to*FactorT)];  
      set(handles.textTime,'String',cadena);
      cadena=['( ',UnitT,' )'];
      set(handles.textUnitT,'String',cadena);

  %------ ONDAS EN LA LINEA PEQUE�A... -------------------------------      
      %La primera onda es la que ya estaba en la linea del generador, la primera
      %onda progresiva, que ya esta ocupando toda la linea
      % Como es estacionaria, los limtes seran [1:NumIterLg];
      VLgP1=VNew(0,NumIterLg-1,l,Vpeak,w,to,beta,0);
      %Y ademas tenemos varias onda estacionarias debidas por un lado a la
      %primera onda que se reflejo desde el generador en el conector
      VLgR2=VNew(0,NumIterLg-1,l,Vpeak*modRhoGP,w,to,-beta,angleRhoGP);
      %Y por otro lado las ondas q se hayan transmitido desde la carga al
      %chocar con el conector, y que dependera de la iteracion q este.
      %a partir de Cod=6,8,10 tenemos q sumar una onda nueva de este tipo!     
      VLgR3=zeros(size(l)); %la onda 3 en Lg que es regresiva!      
      VLgR3E2=zeros(size(l)); %para elevar alcuadrado cada onda!            
      if Cod>=6  %solo si estamos en Cod=6,8,10...
          NumVeces=Cod-5-(Cod-6)/2;  %Numero de ondas a sumar!
          for N=1:NumVeces
            Mod=Vpeak*modTrsGP*modTrsG*modRhoL^N*modRhoG^(N-1);    %su modulo
            Angle=angleTrsGP+angleTrsG+N*angleRhoL+angleRhoG*(N-1);         %su fase a�adida
            Vnueva=VNew(0,NumIterLg-1,l,Mod,w,to,-beta,Angle);
            VLgR3=VLgR3+Vnueva;
            %Para hallar la potencia total tengo q sumar los cuadrados de las
            %ondas V, que no es lo mismo q el cuadrado de la suma!
            VLgR3E2=VLgR3E2+Vnueva.^2;
          end
      end
      %--- Asi hemos formado la onda total VLgR3 ----------------
      
      %Y la onda no estacionaria es una Onda transmitida hacia el generador!
      %los limites [NumIterLg+1-n:NumIterLg]; %para la onda regresiva en Lg      
      %y asi formar el vector regresivo desde el conector al genrdor
        %Su modulo y fase depende de la iteracion en q estemos
        %a partir de Cod=4,6,8,10
      NumVeces=Cod-3-(Cod-4)/2;  %Numero de veces q se ha formado esta onda!               
      Mod=Vpeak*modTrsGP* modTrsG* modRhoL^NumVeces* modRhoG^(NumVeces-1);
                                                  %su modulo
      Angle=angleTrsGP+ angleTrsG+ angleRhoL*NumVeces +angleRhoG*(NumVeces-1);
                                                  %su fase a�adida
      VLgreg=VNew(NumIterLg+1-n,NumIterLg-1,l,...
                Mod,w,to,-beta,Angle);
        %Esta es la onda regresiva, calculada en los puntos por los q se
        %propaga, y para el resto de puntos vale cero!

  %------ ONDAS EN LA LINEA GRANDE... -------------------------------
      %Por otro lado, desde el conector a la carga existen por un lado
      %la primera onda q se transmitio en el paso # 1 y 2 desde el generador 
      %a la linea y que ya ocupa toda la linea
      VLP1=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,...
                Vpeak*modTrsGP,w,to,beta,angleTrsGP);
      %tambien la onda q se propago en el paso #3 regresiva desde la carga
      %al generador y que ya ocupa toda la linea
      VLR2=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,...
                Vpeak*modTrsGP*modRhoL,w,to,-beta,angleTrsGP+angleRhoL);
      
      %y las ondas q se hayan formado en la linea antes, ya propagadas
      %hasta el final de la linea dsde gnrador, tambien ocupan toda la linea!!
      %habra tantas dependiendo de la iteracion
      VLP3=zeros(size(l));   %la onda 2 en L que es progresiva!      
      VLP3E2=zeros(size(l)); %para calcular la suma de cuadrados!
      if Cod>=6  %solo si estamos en Cod=6,8,10...      
        NumVeces=Cod-5-(Cod-6)/2;  %Numero de ondas a sumar!
        for N=1:NumVeces
          Mod=Vpeak*modTrsGP*(modRhoL*modRhoG)^N;        %su modulo
          Angle=angleTrsGP+(angleRhoL+angleRhoG)*N;%su fase a�adida
          Vnueva=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,Mod,w,to,beta,Angle);
          VLP3=VLP3+Vnueva;
          VLP3E2=VLP3E2+Vnueva.^2;
        end
      end %Del if Cod>=6
     
      %--- Asi hemos formado la onda total VLP3 ----------------     
      
      %Onda transmitida hacia la carga mientras tanto!        
      %los limites [NumIterLg+1:NumIterLg-2+n]; %para la onda progresiva en L, 
       % mientras la onda regresiva en Lg se propaga hasta el generador
       % y asi formar el Vector progresivo desde conector a la carga
      NumVeces=Cod-3-(Cod-4)/2;  %Numero de veces q se ha formado esta onda!       
      Mod=Vpeak*modTrsGP*(modRhoL*modRhoG)^NumVeces;        %su modulo
      Angle=angleTrsGP+(angleRhoL+angleRhoG)*NumVeces;%su fase a�adida     
      VLprog=VNew(NumIterLg-1,NumIterLg-1+n,l,...
                 Mod,w,to,beta,Angle);
      
      % Y falta la suma de todas las ondas regresivas q se hayan acumulado
      %en toda la linea grande hasta este punto! Dsde la carga al gnrador
      VLR4=zeros(size(l));   %la onda 2 en L que es progresiva!      
      VLR4E2=zeros(size(l));   %para caulcuar la suma de cuadrados!            
      if Cod>=6  %solo si estamos en Cod=6,8,10...      
        NumVeces=Cod-5-(Cod-6)/2;  %Numero de ondas a sumar!
        for N=1:NumVeces
          Mod=Vpeak*modTrsGP*modRhoL*(modRhoL*modRhoG)^N;        %su modulo
          Angle=angleTrsGP+angleRhoL+(angleRhoL+angleRhoG)*N;%su fase a�adida
          Vnueva=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,Mod,w,to,-beta,Angle);
          VLR4=VLR4+Vnueva;
          VLR4E2=VLR4E2+Vnueva.^2;
        end
      end %Del if Cod>=6

           
      %Y para cada instante la onda total es la suma de las tres:
      Vnuevas=VLgreg+VLprog;
      Vviejas=VLgP1+VLgR2+VLgR3+VLP1+VLR2+VLP3+VLR4;
      Vtotal=Vnuevas+Vviejas;

%para dibujar en el osciloscopio usamos Osc.time,V,I,P
      Osc.time=[Osc.time,to];  %asi vamos ampiando la escala de tiempo!
      
%------- Ahora dibujo la onda de tension total o la q me pidan y la linea...------
      mira=[CheckV,CheckI,CheckP];
      Cuantos=length(find(mira==1)); %par aver si hay mas de un tipo de onda
      if CheckV==1
              G=get(handles.radiobuttonVX10,'UserData');          
          if Cuantos>1
              %Cojo la ganancia de la sonda de tension (G=1 o G=10)
              %que se aplica a la onda de tension total, y solo cuando
              %se representa con otras ondas (de corriente y/o potencia)
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'c',1);
              StGraf.Graf1=G*Vtotal;              
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'r',1);              
              StGraf.Graf1=G*Vtotal;
              StGraf.Graf2=G*Vnuevas;
              StGraf.Graf3=G*Vviejas;              
          end
          %para dibujar en el osciloscopio
          G=get(handles.radiobuttonVX10,'UserData');                        
          Osc.V=[Osc.V,G*Vtotal(l==LongOsc)];
      end
      
      if CheckI==1
          Inuevas=(-VLgreg/Zog+VLprog/Zo)*1000; %en mAps
          Iviejas=( (+VLgP1-VLgR2-VLgR3)/Zog...
                    +(+VLP1-VLR2+VLP3-VLR4)/Zo  )*1000;
          Itotal=Inuevas+Iviejas;
          if Cuantos>1
              if CheckV==0
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',1);
              else
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',0);                  
              end
              StGraf.Graf2=Itotal;                            
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'r',1);              
              StGraf.Graf1=Itotal;
              StGraf.Graf2=Inuevas;
              StGraf.Graf3=Iviejas;              
          end          
          %para dibujar en el osciloscopio
          Osc.I=[Osc.I,Itotal(l==LongOsc)];          
      end
      
      if CheckP==1
          Inuevas=(-VLgreg/Zog+VLprog/Zo)*1000; %en mAps
          Iviejas=( (+VLgP1-VLgR2-VLgR3)/Zog...
                    +(+VLP1-VLR2+VLP3-VLR4)/Zo  )*1000;
          Itotal=Inuevas+Iviejas;          
          
          Pnuevas=Vnuevas.*Inuevas; %en mWatts
          Pviejas=Vviejas.*Iviejas;
          Ptotal=Vtotal.*Itotal;
          if Cuantos>1
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',0);                  
              StGraf.Graf3=Ptotal;                                          
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',1);              
              StGraf.Graf1=Ptotal;
              StGraf.Graf2=Pnuevas;
              StGraf.Graf3=Pviejas;                            
          end          
          %para dibujar en el osciloscopio
          Osc.P=[Osc.P,Ptotal(l==LongOsc)];
      end
      %Guardamos las ondas temporales obtenidas
      set(handles.axesOsc,'UserData',Osc);
      
      %Ahora dibujamos en el osciloscopio si esta seleccionado!
      CheckOsc=get(handles.checkboxOsc,'Value');
      if CheckOsc==1
          dibujaOsc(handles,Factor,UnitT,FactorT,UnitL,FactorL);
      end
      
%---------- Fin de escoger que dibujamos; Tension, Corriente, Potencia... ---
      
      if Pause>0  %Si Pause =0 no hago pausa!
          pause(Pause);
      elseif (Pause==-1) %Si Pause = -1 tengo que pulsar una tecla
          
          %Y dejo que se pueda medir con los markers!
          StGraf.l=l;  %El vector de coordenadas de longitud
          StGraf.F=Factor; %El Factor para la escala vertical (Vpeak,Ipeak,Ppeak...)
          StGraf.handles=handles; %Los handles para coge rlo que necesite!
          set(handles.frameGraf,'UserData',StGraf);
          %Y ahora, si esta activado lo de Markers On dibujamos los markers!
          CheckMarker=get(handles.checkboxMarkers,'Value');
          if CheckMarker==1
              %Y dibujo los markers que toquen!
              dibujaEstructGraf(handles)    
          end
          
          pause;
      elseif Pause==0
          drawnow;
      end
      
  end %del for, iterar para hacer la animacion de la primera parte!
  
%Tambien guardo el instante de tiempo por el q me habia quedado (en segundos)
%en UserData de textTime
%set(handles.textTime,'UserData',to);
%Y el tiempo de inicio anterior en textUnitT
set(handles.textUnitT,'UserData',tant);

   
          %----------------------------------------------------%
%--- Paso 2, la onda transmitida al generador ha sido absorbida, continuamos!
%tant=get(handles.textTime,'UserData'); %cojo el instante en que me habia quedado (en segundos!)
 tant=to;
 
 if Pause==-1
     cadena=['Showing step # ',num2str(Cod),' -2 ...','Press any key to show next frame!'];
     set(handles.textInfo,'String',cadena);     
 else
     cadena=['Showing step # ',num2str(Cod),' -2 ...'];
     set(handles.textInfo,'String',cadena);  
 end

 NumVeces=Cod-3-(Cod-4)/2;  %Numero de ondas a sumar! 
 Mod=modTrsGP* (modRhoL* modRhoG)^NumVeces;
 ModP=(1-modRhoGP^2)* (modRhoL* modRhoG)^(2*NumVeces); 
 %-------------textos de valores de las ondas nuevas y anteriores!
 %Escogemos los textos de las ondas, primero mWatios, 
 %luego Voltios y luego Amperios! -Independientemente de la ESCALA!! 
 if CheckP==1     
    cadena3=[num2str(Ppeak*ModP),' mWatts ->']; 
 elseif CheckV==1
    cadena3=[num2str(Vpeak*Mod),' Volts ->']; 
 elseif CheckI==1
    cadena3=[num2str(Ipeak*Mod),' mAmps ->']; 
 end 
 set(handles.textZona3,'String',cadena3,'BackgroundColor',[0.6 0.85 1]);
 %------ Ya estan puestos los rotulos de ondas! ------------------ 
 
 %--------------------------------------------------------------------
 T=(L-Lgen)/vp; %Tiempo q tarda la onda transmitida en llegar a la carga
                %desde el conector + Lg
 t=[tant:deltaT:T+tant];  %Vector de coordenadas de tiempo! 
                     %Para las iteraciones hasta la segunda reflexion!!
 NumIterLg=floor(Lgen/deltaL +1) ; %numero de iteraciones necesarias hasta que la onda                         
     %reflejada recorra toda la longitud de la linea del generador! 
     %ya que lo neecsitaremos tambien!!
 NumIterL=floor(L/deltaL +1);  %Tambien lo usare...
 NumIterLmas=floor((L-Lgen)/deltaL +1) ; %numero de iteraciones necesarias hasta que la onda                         
     %transmitida recorra la longitud de la linea que le quedaba por recorrer! 
                          
 %Empezamos las iteraciones!------- Paso 2!

 for n=[1:NumIterLmas]
      cadena=['Iter= ',num2str(n),'/',num2str(NumIterLmas)];
      set(handles.textIter,'String',cadena);  
       %Actualizo el instante de tiempo
      to=t(n);  %instante q estoy evaluando!
      cadena=['TIME= ',num2str(to*FactorT)];  
      set(handles.textTime,'String',cadena);
      cadena=['( ',UnitT,' )'];
      set(handles.textUnitT,'String',cadena);
      
  %------ ONDAS EN LA LINEA PEQUE�A... -------------------------------      
      %La primera onda es la que ya estaba en la linea del generador, la primera
      %onda progresiva, que ya esta ocupando toda la linea
      % Como es estacionaria, los limtes seran [1:NumIterLg];
      VLgP1=VNew(0,NumIterLg-1,l,Vpeak,w,to,beta,0);
      %Y ademas tenemos varias onda estacionarias debidas por un lado a la
      %primera onda que se reflejo desde el generador en el conector
      VLgR2=VNew(0,NumIterLg-1,l,Vpeak*modRhoGP,w,to,-beta,angleRhoGP);
      %Y por otro lado las ondas q se hayan transmitido desde la carga al
      %chocar con el conector, y que dependera de la iteracion q este.
      %a partir de Cod=6,8,10 tenemos q sumar una onda nueva de este tipo!     
      VLgR3=zeros(size(l)); %la onda 3 en Lg que es regresiva!      
      VLgR3E2=zeros(size(l)); %para suma de cuadrados            
      if Cod>=6  %solo si estamos en Cod=6,8,10...
          NumVeces=Cod-5-(Cod-6)/2;  %Numero de ondas a sumar!
          for N=1:NumVeces
            Mod=Vpeak*modTrsGP*modTrsG*modRhoL^N*modRhoG^(N-1);    %su modulo
            Angle=angleTrsGP+angleTrsG+N*angleRhoL+angleRhoG*(N-1);%su fase a�adida            
            Vnueva=VNew(0,NumIterLg-1,l,Mod,w,to,-beta,Angle);
            VLgR3=VLgR3+Vnueva;
            VLgR3E2=VLgR3E2+Vnueva.^2;
          end
      end
      %--- Asi hemos formado la onda total VLgR3 ----------------
      
      %Y STA ONDA YA ES ESTACIONARIA es una Onda transmitida hacia el generador!
      %los limites [NumIterLg+1-n:NumIterLg]; %para la onda regresiva en Lg      
      %y asi formar el vector regresivo desde el conector al genrdor
        %Su modulo y fase depende de la iteracion en q estemos
        %a partir de Cod=4,6,8,10
      NumVeces=Cod-3-(Cod-4)/2; %Numero de veces q se ha formado esta onda!
      Mod=Vpeak*modTrsGP* modTrsG* modRhoL^NumVeces* modRhoG^(NumVeces-1);
                                                  %su modulo
      Angle=angleTrsGP+ angleTrsG+ angleRhoL*NumVeces +angleRhoG*(NumVeces-1);
                                                  %su fase a�adida
      VLgreg=VNew(0,NumIterLg-1,l,...
                  Mod,w,to,-beta,Angle);
        %Esta es la onda regresiva, calculada en los puntos por los q se
        %propaga, y para el resto de puntos vale cero!

  %------ ONDAS EN LA LINEA GRANDE... -------------------------------
      %Por otro lado, desde el conector a la carga existen por un lado
      %la primera onda q se transmitio en el paso # 1 y 2 desde el generador 
      %a la linea y que ya ocupa toda la linea
      VLP1=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,...
                Vpeak*modTrsGP,w,to,beta,angleTrsGP);
      %tambien la onda q se propago en el paso #3 regresiva desde la carga
      %al generador y que ya ocupa toda la linea
      VLR2=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,...
                Vpeak*modTrsGP*modRhoL,w,to,-beta,angleTrsGP+angleRhoL);
      
      %y las ondas q se hayan formado en la linea antes, ya propagadas
      %hasta el final de la linea dsde gnrador, tambien ocupan toda la linea!!
      %habra tantas dependiendo de la iteracion
      VLP3=zeros(size(l));   %la onda 2 en L que es progresiva!      
      VLP3E2=zeros(size(l));   %para suma de cuadrados            
      if Cod>=6  %solo si estamos en Cod=6,8,10...      
        NumVeces=Cod-5-(Cod-6)/2;  %Numero de ondas a sumar!
        for N=1:NumVeces
          Mod=Vpeak*modTrsGP*(modRhoL*modRhoG)^N;        %su modulo
          Angle=angleTrsGP+(angleRhoL+angleRhoG)*N;%su fase a�adida
          Vnueva=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,Mod,w,to,beta,Angle);
          VLP3=VLP3+Vnueva;
          VLP3E2=VLP3E2+Vnueva.^2;
        end
      end %Del if Cod>=6
     
      %--- Asi hemos formado la onda total VLP3 ----------------     
      
      %Onda transmitida hacia la carga q le queda camino!!        
      %los limites [NumIterLg+1:NumIterLg-2+n]; %para la onda progresiva en L, 
       % mientras la onda regresiva en Lg se propaga hasta el generador
       % y asi formar el Vector progresivo desde conector a la carga
      NumVeces=Cod-3-(Cod-4)/2;  %Numero de veces q se ha formado esta onda!       
      Mod=Vpeak*modTrsGP*(modRhoL*modRhoG)^NumVeces;        %su modulo
      Angle=angleTrsGP+(angleRhoL+angleRhoG)*NumVeces;%su fase a�adida     
      VLprog=VNew(NumIterLg-1,2*NumIterLg-2+n,l,...
                 Mod,w,to,beta,Angle);
             
      % Y falta la suma de todas las ondas regresivas q se hayan acumulado
      %en toda la linea grande hasta este punto! Dsde la carga al gnrador
      VLR4=zeros(size(l));   %la onda 2 en L que es progresiva!      
      VLR4E2=zeros(size(l));   %par suma de cuadrados            
      if Cod>=6  %solo si estamos en Cod=6,8,10...      
        NumVeces=Cod-5-(Cod-6)/2;  %Numero de ondas a sumar!
        for N=1:NumVeces
          Mod=Vpeak*modTrsGP*modRhoL*(modRhoL*modRhoG)^N;        %su modulo
          Angle=angleTrsGP+angleRhoL+(angleRhoL+angleRhoG)*N;%su fase a�adida
          Vnueva=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,Mod,w,to,-beta,Angle);
          VLR4=VLR4+Vnueva;
          VLR4E2=VLR4E2+Vnueva.^2;
        end
      end %Del if Cod>=6

           
      %Y para cada instante la onda total es la suma de las tres:
      Vnuevas=VLgreg+VLprog;
      Vviejas=VLgP1+VLgR2+VLgR3+VLP1+VLR2+VLP3+VLR4;
      Vtotal=Vnuevas+Vviejas;
      
%para dibujar en el osciloscopio usamos Osc.time,V,I,P
      Osc.time=[Osc.time,to];  %asi vamos ampiando la escala de tiempo!
                         
%------- Ahora dibujo la onda de tension total o la q me pidan y la linea...------
      mira=[CheckV,CheckI,CheckP];
      Cuantos=length(find(mira==1)); %par aver si hay mas de un tipo de onda
      if CheckV==1
              G=get(handles.radiobuttonVX10,'UserData');          
          if Cuantos>1
              %Cojo la ganancia de la sonda de tension (G=1 o G=10)
              %que se aplica a la onda de tension total, y solo cuando
              %se representa con otras ondas (de corriente y/o potencia)
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'c',1);
              StGraf.Graf1=G*Vtotal;              
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'r',1);              
              StGraf.Graf1=G*Vtotal;
              StGraf.Graf2=G*Vnuevas;
              StGraf.Graf3=G*Vviejas;              
          end
          %para dibujar en el osciloscopio
          G=get(handles.radiobuttonVX10,'UserData');                        
          Osc.V=[Osc.V,G*Vtotal(l==LongOsc)];
      end
      
      if CheckI==1
          Inuevas=(-VLgreg/Zog+VLprog/Zo)*1000; %en mAps
          Iviejas=( (+VLgP1-VLgR2-VLgR3)/Zog...
                    +(+VLP1-VLR2+VLP3-VLR4)/Zo  )*1000;
          Itotal=Inuevas+Iviejas;
          if Cuantos>1
              if CheckV==0
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',1);
              else
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',0);                  
              end
              StGraf.Graf2=Itotal;                            
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'r',1);              
              StGraf.Graf1=Itotal;
              StGraf.Graf2=Inuevas;
              StGraf.Graf3=Iviejas;              
          end          
          %para dibujar en el osciloscopio
          Osc.I=[Osc.I,Itotal(l==LongOsc)];
      end
      
      if CheckP==1
          Inuevas=(-VLgreg/Zog+VLprog/Zo)*1000; %en mAps
          Iviejas=( (+VLgP1-VLgR2-VLgR3)/Zog...
                    +(+VLP1-VLR2+VLP3-VLR4)/Zo  )*1000;
          Itotal=Inuevas+Iviejas;          
          
          Pnuevas=Vnuevas.*Inuevas; %en mWatts
          Pviejas=Vviejas.*Iviejas;
          Ptotal=Vtotal.*Itotal;
          if Cuantos>1
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',0);                  
              StGraf.Graf3=Ptotal;                                          
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',1);              
              StGraf.Graf1=Ptotal;
              StGraf.Graf2=Pnuevas;
              StGraf.Graf3=Pviejas;                            
          end          
          %para dibujar en el osciloscopio
          Osc.P=[Osc.P,Ptotal(l==LongOsc)];
      end
      %Guardamos las ondas temporales obtenidas
      set(handles.axesOsc,'UserData',Osc);
      
      %Ahora dibujamos en el osciloscopio si esta seleccionado!
      CheckOsc=get(handles.checkboxOsc,'Value');
      if CheckOsc==1
          dibujaOsc(handles,Factor,UnitT,FactorT,UnitL,FactorL);
      end
      
%---------- Fin de escoger que dibujamos; Tension, Corriente, Potencia... ---
      
      if Pause>0  %Si Pause =0 no hago pausa!
          pause(Pause);
      elseif (Pause==-1) %Si Pause = -1 tengo que pulsar una tecla
          
          %Y dejo que se pueda medir con los markers!
          StGraf.l=l;  %El vector de coordenadas de longitud
          StGraf.F=Factor; %El Factor para la escala vertical (Vpeak,Ipeak,Ppeak...)
          StGraf.handles=handles; %Los handles para coge rlo que necesite!
          set(handles.frameGraf,'UserData',StGraf);
          %Y ahora, si esta activado lo de Markers On dibujamos los markers!
          CheckMarker=get(handles.checkboxMarkers,'Value');
          if CheckMarker==1
              %Y dibujo los markers que toquen!
              dibujaEstructGraf(handles)    
          end
          
          pause;
      elseif Pause==0
          drawnow;
      end
      
  end %del for, iterar para hacer la animacion de la segunda parte!
  
%Tambien guardo el instante de tiempo por el q me habia quedado (en segundos)
%en UserData de textTime
set(handles.textTime,'UserData',to);
%Y el t anterior
%set(handles.textUnitT,'UserData',tant);

Cod=Cod+1;
set(handles.pushbuttonVer,'UserData',Cod); %para indicar q ya hemos hecho
     %la onda progresiva q llega hasta la carga desde el conector!

cadena=['Wave has reached the load. Press Continue, Repeat or Reset...'];
set(handles.textInfo,'String',cadena);  
%--------------- FIN de PASO # 4,6,8,10... -------------------------------  


%----------------------------------------------------------------------------
%----------------- CASO de ONDAS REFLEXION desde CARGA a CONECTOR ---------

elseif (Cod>=5) & (mod(Cod,2)==1) %para Cod=5,7,9,11,13...
          %----------------------------------------------------%
 if Pause==-1
     cadena=['Showing step # ',num2str(Cod),' ...','Press any key to show next frame!'];
     set(handles.textInfo,'String',cadena);     
 else
     cadena=['Showing step # ',num2str(Cod),' ...'];
     set(handles.textInfo,'String',cadena);  
 end
 
 %para calcular las amplitudes de las nuevas ondas necesitamos
 %conocer el paso en el q estamos!
 NumVeces=Cod-4-(Cod-5)/2;  %Numero de ondas a sumar! 
 Mod1=modTrsGP* modTrsG* modRhoL^NumVeces* modRhoG^(NumVeces-1);
 Mod2=modTrsGP* (modRhoL* modRhoG)^NumVeces;
 Mod3=modTrsGP* modRhoL^(NumVeces+1)* modRhoG^NumVeces; 
 %Coeficientes para las potencias!!
 ModP1=(1-modRhoGP^2)* (1-modRhoG^2)* modRhoL^(2*NumVeces)*modRhoG^(2*NumVeces-2); 
 ModP2=(1-modRhoGP^2)* (modRhoL* modRhoG)^(2*NumVeces);
 ModP3=(1-modRhoGP^2)* modRhoL^(2*NumVeces+2)* modRhoG^(2*NumVeces);  
 
 %-------------textos de valores de las ondas nuevas y anteriores!
 %Escogemos los textos de las ondas, primero mWatios, 
 %luego Voltios y luego Amperios! -Independientemente de la ESCALA!! 
 if CheckP==1     
    cadena1=[num2str(Ppeak*ModP1),' mWatts <-']; 
    cadena2=[num2str(Ppeak*ModP2),' mWatts ->']; 
    cadena3=[num2str(Ppeak*ModP3),' mWatts <-'];   
 elseif CheckV==1
    cadena1=[num2str(Vpeak*Mod1),' Volts <-']; 
    cadena2=[num2str(Vpeak*Mod2),' Volts ->']; 
    cadena3=[num2str(Vpeak*Mod3),' Volts <-'];
 elseif CheckI==1
    cadena1=[num2str(Ipeak*Mod1),' mAmps <-']; 
    cadena2=[num2str(Ipeak*Mod2),' mAmps ->']; 
    cadena3=[num2str(Ipeak*Mod3),' mAmps <-'];   
 end 
 set(handles.textZona1,'String',cadena1,'BackgroundColor',[0.75 0.75 0.75]); 
 set(handles.textZona2,'String',cadena2,'BackgroundColor',[0.75 0.75 0.75]);
 set(handles.textZona3,'String',cadena3,'BackgroundColor',[0.6 0.85 1]);  
 %------ Ya estan puestos los rotulos de ondas! ------------------ 
  

%-------------------------------------------------------------------- 
 T=L/vp;        %Tiempo q tarda la onda transmitida en llegar de la carga
                %hasta el conector (distancia L)
 t=[tant:deltaT:T+tant];  %Vector de coordenadas de tiempo! 
                     %Para las iteraciones hasta la segunda reflexion!!
 NumIterLg=floor(Lgen/deltaL +1) ; %numero de iteraciones necesarias hasta que la onda                         
     %reflejada recorra toda la longitud de la linea del generador! 
     %ya que lo neecsitaremos tambien!!
 NumIterL=floor(L/deltaL +1);  %Tambien lo usare...
 NumIterLmas=floor((L-Lgen)/deltaL +1) ; %numero de iteraciones necesarias hasta que la onda                         
     %transmitida recorra la longitud de la linea que le quedaba por recorrer! 

     
 %Empezamos las iteraciones!------- 

 for n=[1:NumIterL]
      cadena=['Iter= ',num2str(n),'/',num2str(NumIterL)];
      set(handles.textIter,'String',cadena);  
       %Actualizo el instante de tiempo
      to=t(n);  %instante q estoy evaluando!
      cadena=['TIME= ',num2str(to*FactorT)];  
      set(handles.textTime,'String',cadena);
      cadena=['( ',UnitT,' )'];
      set(handles.textUnitT,'String',cadena);
      
  %------ ONDAS EN LA LINEA PEQUE�A... -------------------------------      
      %La primera onda es la que ya estaba en la linea del generador, la primera
      %onda progresiva, que ya esta ocupando toda la linea
      % Como es estacionaria, los limtes seran [1:NumIterLg];
      VLgP1=VNew(0,NumIterLg-1,l,Vpeak,w,to,beta,0);
      %Y ademas tenemos varias onda estacionarias debidas por un lado a la
      %primera onda que se reflejo desde el generador en el conector
      VLgR2=VNew(0,NumIterLg-1,l,Vpeak*modRhoGP,w,to,-beta,angleRhoGP);
      %Y por otro lado las ondas q se hayan transmitido desde la carga al
      %chocar con el conector, y que dependera de la iteracion q este.
      %a partir de Cod=6,8,10 tenemos q sumar una onda nueva de este tipo!     
      VLgR3=zeros(size(l)); %la onda 3 en Lg que es regresiva!      
      VLgR3E2=zeros(size(l)); %pra suma rlos cuadrados            
      if Cod>=7  %solo si estamos en Cod=7,9,11...
          NumVeces=Cod-6-(Cod-7)/2;  %Numero de ondas a sumar!
          for N=1:NumVeces
            Mod=Vpeak*modTrsGP*modTrsG*modRhoL^N*modRhoG^(N-1);    %su modulo
            Angle=angleTrsGP+angleTrsG+N*angleRhoL+angleRhoG*(N-1);%su fase a�adida            
            Vnueva=VNew(0,NumIterLg-1,l,Mod,w,to,-beta,Angle);
            VLgR3=VLgR3+Vnueva;
            VLgR3E2=VLgR3E2+Vnueva.^2;
          end
      end
      %--- Asi hemos formado la onda total VLgR3 ----------------
      
      %Y STA ONDA YA ES ESTACIONARIA es una Onda transmitida hacia el generador!
      %los limites [NumIterLg+1-n:NumIterLg]; %para la onda regresiva en Lg      
      %y asi formar el vector regresivo desde el conector al genrdor
        %Su modulo y fase depende de la iteracion en q estemos
        %a partir de Cod=4,6,8,10
      NumVeces=Cod-4-(Cod-5)/2; %Numero de veces q se ha formado esta onda!
      Mod=Vpeak*modTrsGP* modTrsG* modRhoL^NumVeces* modRhoG^(NumVeces-1);
                                                  %su modulo
      Angle=angleTrsGP+ angleTrsG+ angleRhoL*NumVeces +angleRhoG*(NumVeces-1);
                                                  %su fase a�adida
      VLgR4=VNew(0,NumIterLg-1,l,...
                  Mod,w,to,-beta,Angle);
        %Esta es la onda regresiva, calculada en los puntos por los q se
        %propaga, y para el resto de puntos vale cero!

  %------ ONDAS EN LA LINEA GRANDE... -------------------------------
      %Por otro lado, desde el conector a la carga existen por un lado
      %la primera onda q se transmitio en el paso # 1 y 2 desde el generador 
      %a la linea y que ya ocupa toda la linea
      VLP1=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,...
                Vpeak*modTrsGP,w,to,beta,angleTrsGP);
      %tambien la onda q se propago en el paso #3 regresiva desde la carga
      %al generador y que ya ocupa toda la linea
      VLR2=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,...
                Vpeak*modTrsGP*modRhoL,w,to,-beta,angleTrsGP+angleRhoL);
      
      %y las ondas q se hayan formado en la linea antes, ya propagadas
      %hasta el final de la linea dsde gnrador, tambien ocupan toda la linea!!
      %habra tantas dependiendo de la iteracion
      VLP3=zeros(size(l));   %la onda 2 en L que es progresiva!      
      VLP3E2=zeros(size(l));   %pra suma de cuadrados            
%      if Cod>=7  %solo si estamos en Cod=7,9,11...      
        NumVeces=Cod-4-(Cod-5)/2;  %Numero de ondas a sumar!
        for N=1:NumVeces
          Mod=Vpeak*modTrsGP*(modRhoL*modRhoG)^N;        %su modulo
          Angle=angleTrsGP+(angleRhoL+angleRhoG)*N;%su fase a�adida
          Vnueva=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,Mod,w,to,beta,Angle);
          VLP3=VLP3+Vnueva;
          VLP3E2=VLP3E2+Vnueva.^2;
        end
%      end %Del if Cod>=7
     
      %--- Asi hemos formado la onda total VLP3 ----------------     
      
      %Onda transmitida hacia la carga q le queda camino!!        
      %los limites [NumIterLg+1:NumIterLg-2+n]; %para la onda progresiva en L, 
       % mientras la onda regresiva en Lg se propaga hasta el generador
       % y asi formar el Vector progresivo desde conector a la carga
      NumVeces=Cod-4-(Cod-5)/2;  %Numero de veces q se ha formado esta onda!       
      Mod=Vpeak*modTrsGP*modRhoL*(modRhoL*modRhoG)^NumVeces;        %su modulo
      Angle=angleTrsGP+angleRhoL+(angleRhoL+angleRhoG)*NumVeces;%su fase a�adida
      VLreg=VNew(NumIterL+NumIterLg-n,NumIterL+NumIterLg-1,l,...
                 Mod,w,to,-beta,Angle);
             
      % Y falta la suma de todas las ondas regresivas q se hayan acumulado
      %en toda la linea grande hasta este punto! Dsde la carga al gnrador
      VLR4=zeros(size(l));   %la onda 2 en L que es progresiva!      
      VLR4E2=zeros(size(l));   %pras umar de cuadrados        
      if Cod>=7  %solo si estamos en Cod=7,9,11...      
        NumVeces=Cod-6-(Cod-7)/2;  %Numero de ondas a sumar!
        for N=1:NumVeces
          Mod=Vpeak*modTrsGP*modRhoL*(modRhoL*modRhoG)^(N);        %su modulo
          Angle=angleTrsGP+angleRhoL+(angleRhoL+angleRhoG)*(N);%su fase a�adida
          Vnueva=VNew(NumIterLg-1,NumIterLg+NumIterL-1,l,Mod,w,to,-beta,Angle);
          VLR4=VLR4+Vnueva;
          VLR4E2=VLR4E2+Vnueva.^2;
        end
      end %Del if Cod>=7

           
      %Y para cada instante la onda total es la suma de las tres:
      Vnuevas=VLreg;
      Vviejas=VLgP1+VLgR2+VLgR3+VLgR4+VLP1+VLR2+VLP3+VLR4;
      Vtotal=Vnuevas+Vviejas;
      
%para dibujar en el osciloscopio usamos Osc.time,V,I,P
      Osc.time=[Osc.time,to];  %asi vamos ampiando la escala de tiempo!
                         
%------- Ahora dibujo la onda de tension total o la q me pidan y la linea...------
      mira=[CheckV,CheckI,CheckP];
      Cuantos=length(find(mira==1)); %par aver si hay mas de un tipo de onda
      if CheckV==1
              G=get(handles.radiobuttonVX10,'UserData');          
          if Cuantos>1
              %Cojo la ganancia de la sonda de tension (G=1 o G=10)
              %que se aplica a la onda de tension total, y solo cuando
              %se representa con otras ondas (de corriente y/o potencia)
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'c',1);
              StGraf.Graf1=G*Vtotal;              
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,G*Vtotal,G*Vnuevas,G*Vviejas,'r',1);              
              StGraf.Graf1=G*Vtotal;
              StGraf.Graf2=G*Vnuevas;
              StGraf.Graf3=G*Vviejas;              
          end
          %para dibujar en el osciloscopio
          G=get(handles.radiobuttonVX10,'UserData');                        
          Osc.V=[Osc.V,G*Vtotal(l==LongOsc)];
      end
      
      if CheckI==1
          Inuevas=(-VLreg/Zo)*1000; %en mAps
          Iviejas=( (+VLgP1-VLgR2-VLgR3-VLgR4)/Zog...
                    +(+VLP1-VLR2+VLP3-VLR4)/Zo  )*1000;
          Itotal=Inuevas+Iviejas;
          if Cuantos>1
              if CheckV==0
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',1);
              else
                  dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'y',0);                  
              end
              StGraf.Graf2=Itotal;                            
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Itotal,Inuevas,Iviejas,'r',1);              
              StGraf.Graf1=Itotal;
              StGraf.Graf2=Inuevas;
              StGraf.Graf3=Iviejas;              
          end          
          %para dibujar en el osciloscopio
          Osc.I=[Osc.I,Itotal(l==LongOsc)];          
      end
      
      if CheckP==1
          Inuevas=(-VLreg/Zo)*1000; %en mAps
          Iviejas=( (+VLgP1-VLgR2-VLgR3-VLgR4)/Zog...
                    +(+VLP1-VLR2+VLP3-VLR4)/Zo  )*1000;
          Itotal=Inuevas+Iviejas;        
          
          Pnuevas=Vnuevas.*Inuevas; %en mWatts
          Pviejas=Vviejas.*Iviejas;
          Ptotal=Vtotal.*Itotal;
          if Cuantos>1
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',0);                  
              StGraf.Graf3=Ptotal;                                          
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Ptotal,Pnuevas,Pviejas,'r',1);              
              StGraf.Graf1=Ptotal;
              StGraf.Graf2=Pnuevas;
              StGraf.Graf3=Pviejas;                            
          end          
          %para dibujar en el osciloscopio
          Osc.P=[Osc.P,Ptotal(l==LongOsc)];
      end
      %Guardamos las ondas temporales obtenidas
      set(handles.axesOsc,'UserData',Osc);
      
      %Ahora dibujamos en el osciloscopio si esta seleccionado!
      CheckOsc=get(handles.checkboxOsc,'Value');
      if CheckOsc==1
          dibujaOsc(handles,Factor,UnitT,FactorT,UnitL,FactorL);
      end
      
%---------- Fin de escoger que dibujamos; Tension, Corriente, Potencia... ---
      
      if Pause>0  %Si Pause =0 no hago pausa!
          pause(Pause);
      elseif (Pause==-1) %Si Pause = -1 tengo que pulsar una tecla
          
          %Y dejo que se pueda medir con los markers!
          StGraf.l=l;  %El vector de coordenadas de longitud
          StGraf.F=Factor; %El Factor para la escala vertical (Vpeak,Ipeak,Ppeak...)
          StGraf.handles=handles; %Los handles para coge rlo que necesite!
          set(handles.frameGraf,'UserData',StGraf);
          %Y ahora, si esta activado lo de Markers On dibujamos los markers!
          CheckMarker=get(handles.checkboxMarkers,'Value');
          if CheckMarker==1
              %Y dibujo los markers que toquen!
              dibujaEstructGraf(handles)    
          end
          
          pause;
      elseif Pause==0
          drawnow;
      end
      
  end %del for, iterar para hacer la animacion de la segunda parte!
  
%Tambien guardo el instante de tiempo por el q me habia quedado (en segundos)
%en UserData de textTime
set(handles.textTime,'UserData',to);
%Y el t anterior
set(handles.textUnitT,'UserData',tant);

Cod=Cod+1;
set(handles.pushbuttonVer,'UserData',Cod); %para indicar q ya hemos hecho
     %la onda progresiva q llega hasta la carga desde el conector!

cadena=['Wave has reached the connector. Press Continue, Repeat or Reset...'];
set(handles.textInfo,'String',cadena);  
%--------------- FIN de PASO # 5,7,9,11... ------------------------------- 

end  %del if si Cod==1, para ver que caso estabamos!

 %Ponemos el siguiente parametro a 0 para indicar q YA NO 
 %estamos en medio de iteracion y asi no hacemos caso de las teclas!
 set(handles.textIter,'UserData',0);
 
 %------------------------------------------------------------------
    %La imagen la guardo por si quiero dibujar sobre ella markers!
   %sera la estructura de la imagen reinicializada!
    StGraf.l=l;  %El vector de coordenadas de longitud
    StGraf.F=Factor; %El Factor para la escala vertical (Vpeak,Ipeak,Ppeak...)
    StGraf.handles=handles; %Los handles para coge rlo que necesite!
    %Las graficas que almaceno depende de lo que haya representado
    %pueden ser las ondas de tension,corriente y potencia (V,I,P)
    %o de cualquiera de estas tres ondas sus ondas Totales,Nuevas y Viejas
    % handles.frameGraf.'UserData'.Graf1=grafica1;  
    % handles.frameGraf.'UserData'.Graf2=grafica2;
    % handles.frameGraf.'UserData'.Graf3=grafica3;    
    %Con handles.frameGraf.'UserData'.GrafActual digo cual es la grafica 
    %activa, que es la que hemos escogido para representar los markers!
    %Guardo al estrucutra asi creada en UserData de frameGraf!!
    set(handles.frameGraf,'UserData',StGraf);
    
    %Y ahora, si esta activado lo de Markers On dibujamos los markers!
    CheckMarker=get(handles.checkboxMarkers,'Value');
    if CheckMarker==1
     %Y dibujo los markers que toquen!
     dibujaEstructGraf(handles)    
    end
    
%--------------------------------------------------------------------------
 

%------ Fin de CONTINUE, para rpresentar ondas en cualquier instante! ---
%--------------------------------------------------------------------------








%----------------------FUNCION MUY IMPORTANTE ------------------------
%-------- Para formar ondas en cada instante de tiempo y poner ceros
%----- donde todavia no haya llegado la onda!
function Vnew=VNew(lmin,lmax,l,Amp,w,to,beta,fase);
indL=[lmin+1:lmax]; 
L=l(indL);    %Vector regresivo o progresivo, o incluso estacionario!
L=L-l(1);  %Para que en la salida del generador tengamos tension nula
           %en t=0!!
Vnew=zeros(size(l));
Vnew(indL)=Amp*sin(w*to-beta*L+fase);
%NOTA: si beta es real positivo se propaga a la derecha (progresiva),
%pero si beta es real negativo se propaga hacia la izquierda (regresiva)
%-------------------------------------------------------------------------

%---- Funcion q dibuja las ondas totales, nuevas y/o viejas ----------
function dibujaOndasV(handles,Lgen,L,F,l,Vtotal,Vnuevas,Vviejas,Color,borra);
      graf=handles.axesLinea;
      axes(graf) %seleccionamos la grafica
      if borra==1
          cla;       %borro lo que hubiera!
          dibujaLinea(Lgen,L,F,handles);  %dibujo la linea e impedancias...
      end
      
      %Ahora dibujo la onda total si esta seleccionado     
      Check=get(handles.radiobuttonTotalW,'Value');
      if Check==1
          plot(l,Vtotal,Color,'LineWidth',2);
      end
      %Ahora dibujo la onda nueva si esta seleccionado
      Check=get(handles.radiobuttonNewW,'Value');
      if Check==1
          plot(l,Vnuevas,'c','LineWidth',1);
      end
      %Ahora dibujo la antigua onda si esta seleccionado
      Check=get(handles.radiobuttonOldW,'Value');
      if Check==1
          plot(l,Vviejas,'y','LineWidth',1);          
      end
      
%-----------------------------------------------------------------



%----------- BOTON de REPEAT -----------------------------------------
% --------------------------------------------------------------------
function varargout = pushbuttonRepeat_Callback(h, eventdata, handles, varargin)
%Cojo el codigo y le resto uno si es mayor que cero para repetir el paso
%anterior!
Cod=get(handles.pushbuttonVer,'UserData');
Cod=Cod-1;
tant=get(handles.textUnitT,'UserData'); %El tiempo de inicio del paso anterior!
to=get(handles.textTime,'UserData');    %el instante en el q estoy
if (Cod>0)
      %pero antes, para que salga bien el osciloscopio tengo que corregir
       Osc=get(handles.axesOsc,'UserData');
       time=Osc.time; %El vector de tiempos!
       V=Osc.V;
       I=Osc.I;
       P=Osc.P;
       
    IndQuita=find(time==tant);
    IndQuita=IndQuita(1);  %Me dice hasta donde tengo que coger los datos!!
%    IndFinQuita=find(time==to);
    time=time(1:IndQuita);  %construimos nuevo vector de tiempos!!
    if length(V)>1
        V=V(1:IndQuita);
    end
    if length(I)>1
        I=I(1:IndQuita);
    end
    if length(P)>1
        P=P(1:IndQuita);
    end
    
    Osc.time=time;
    Osc.V=V;
    Osc.I=I;
    Osc.P=P;
    %Guardamos las ondas temporales obtenidas
    set(handles.axesOsc,'UserData',Osc);
    
    set(handles.textTime,'UserData',tant); %el tant lo pongo como nuevo inicio!
    set(handles.pushbuttonVer,'UserData',Cod);
    pushbuttonContinue_Callback(h, eventdata, handles, varargin);
elseif (Cod==0)
    
    
    set(handles.textTime,'UserData',tant); %el tant lo pongo como nuevo inicio!    
    set(handles.pushbuttonVer,'UserData',Cod);
    pushbuttonVer_Callback(h, eventdata, handles, varargin);    
else
    cadena=['You must first Launch a wave to repeat any step...'];
    set(handles.textInfo,'String',cadena);  
end    
%------------------------------------------------------------







% --------------------------BOTON DE RESET------------------------------
function varargout = pushbuttonReset_Callback(h, eventdata, handles, varargin)
 
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     return;
 end
 L=X(5);
 Lgen=L/4;
 
 CheckIter=get(handles.textIter,'UserData');
 if CheckIter==1
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);     
     return;     
 end
 
set(handles.pushbuttonVer,'UserData',0); %Reinicio el contador de reflexiones
set(handles.pushbuttonContinue,'UserData',0);  %Me cargo la onda total
set(handles.pushbuttonReset,'UserData',0);     %Y la onda incidente!

%Borro las se�ales y dibujo la linea...
graf=handles.axesLinea;
axes(graf) %seleccionamos la grafica
cla;       %borro lo que hubiera!
dibujaLinea(Lgen,L,1,handles);  %dibujo la linea e impedancias...
axis([-Lgen-Lgen/8 L+Lgen/8 -4.3 4.3]);
set(graf,'YTick',[-4 -2 0 2 4]);
set(graf,'YTickLabel',[-4 -2 0 2 4]);
%Reseteo el contador de iteraciones y de tiempo
cadena=['Iter= -/-'];
set(handles.textIter,'String',cadena);  
cadena=['TIME= -'];  
set(handles.textTime,'String',cadena);
%Reseteo los textos de amplitudes de ondas
set(handles.textZona1,'String','-','BackgroundColor',[0.75 0.75 0.75]);
set(handles.textZona2,'String','-','BackgroundColor',[0.75 0.75 0.75]);
set(handles.textZona3,'String','-','BackgroundColor',[0.75 0.75 0.75]);
%Mensaje de info...
cadena=['Reflection counter initialized, you can restart the simulation!'];
set(handles.textInfo,'String',cadena);  
 %Ponemos el siguiente parametro a 0 para indicar q YA NO 
 %estamos en medio de iteracion y asi no hacemos caso de las teclas!
 set(handles.textIter,'UserData',0);
 %Y ponemos la memoria del osciloscopio a cero!
 Osc.time=zeros(1);
 Osc.V=zeros(1);
 Osc.I=zeros(1);
 Osc.P=zeros(1); 
 set(handles.axesOsc,'UserData',Osc);
 %Y la grafica del osciloscopio!
 grafOsc=handles.axesOsc;
 axes(grafOsc) %seleccionamos la grafica
 cla;       %borro lo que hubiera!
 axis([0 1 -1 1]);
 line([0 1],[0 0],'Color','k');
 
 %La imagen la guardo por si quiero dibujar sobre ella markers!
 %sera la estructura de la imagen reinicializada!
  Graf.l=zeros(1);
  Graf.F=0;
  Graf.handles=handles;
  Graf.Graf1=zeros(1);
  Graf.Graf2=zeros(1);
  Graf.Graf3=zeros(1);    
  Graf.GrafActual=0;  
  set(handles.frameGraf,'UserData',Graf);
 




% --------------------------------------------------------------------
function varargout = editRes_Callback(h, eventdata, handles, varargin)
Res=str2num(get(handles.editRes,'String'));
if (Res<=0) | (mod(Res,1)~=0)
   cadena=['Sorry, but number of points per wavelength must be an integer number greater than zero!'];
   set(handles.textInfo,'String',cadena);  
   set(handles.editRes,'UserData',0);   
   set(handles.editRes,'String','-');         
   return;
end
set(handles.editRes,'UserData',Res);  %Lo guardo en UserData
cadena=['Spatial Resolution is set to ',num2str(Res),' points/wavelength'];
set(handles.textInfo,'String',cadena);  
    

% --------------------------------------------------------------------
function varargout = editPause_Callback(h, eventdata, handles, varargin)
Pause=str2num(get(handles.editPause,'String'));
if (Pause<=-2)
   cadena=['Sorry, but pause between each frame must be greater or equal to 0 secs.Key Pause=-1'];
   set(handles.textInfo,'String',cadena);  
   set(handles.editPause,'UserData',-2);   
   set(handles.editPause,'String','-');      
   return;
end
set(handles.editPause,'UserData',Pause);  %Lo guardo en UserData
if Pause>0
    cadena=['Pause between each frame of animation is set to ',num2str(Pause),' secs/frame'];
    set(handles.textInfo,'String',cadena);  
elseif Pause==0
    cadena=['Pause is set to Maximum Speed!'];
    set(handles.textInfo,'String',cadena);         
elseif Pause==-1
    cadena=['Pause is set to Press-Key mode'];
    set(handles.textInfo,'String',cadena);     
end


%------------ Funcion que dibuja la linea, las impedancias....-------
function dibujaLinea(Lgen,L,F,handles);
 %Dibujo la linea de transmision!-----------------------------------
 line([-Lgen,L],[-F*4.2,-F*4.2],'LineWidth',4);
 line([-Lgen,L],[+F*4.2,+F*4.2],'LineWidth',4);
 line([-Lgen,-Lgen],[-F*4.2,+F*4.2],'LineWidth',4);
 line([L,L],[-F*4.2,+F*4.2],'LineWidth',4);
 line([-Lgen,L],[0,0],'LineWidth',1,'Color','k');   
 %Dibujo la fuente de tension y su Zgen!
 plot(-Lgen,0,'ro','MarkerSize',20,'MarkerFaceColor','m',...
      'MarkerEdgeColor','k');
 patch([-Lgen-Lgen/16,-Lgen-Lgen/16,-Lgen+Lgen/16,-Lgen+Lgen/16],...
        [F*1.6,F*2.8,F*2.8,F*1.6],'m');
 %Y la impedancia de carga ZL   
 patch([L-Lgen/16,L-Lgen/16,L+Lgen/16,L+Lgen/16],...
        [-F,F,F,-F],'c');
 %Y la discontinuidad del conector que une el generador con la linea!
 line([0,0],[-F*4.2,F*4.2],'Color','k','LineWidth',2);
 
 %Por ultimo dibujo una linea roja discontinua donde tengo
 %situada la sonda del osciloscopio si esta activado!
 CheckOsc=get(handles.checkboxOsc,'Value');
 %En UserData de textLOsc tenemos la posicion de la sonda!
 Losc=get(handles.textLOsc,'UserData');
 if CheckOsc==1
    line([Losc,Losc],[-F*4.2,F*4.2],'Color','r','LineWidth',1);            
 end

 %------------------------------------------------------------------  


% --------------------------------------------------------------------
function varargout = radiobuttonTotalW_Callback(h, eventdata, handles, varargin)
if (get(handles.radiobuttonTotalW,'Value'))==1
  cadena=['You�ve chosen to see total waves'];
  set(handles.textInfo,'String',cadena);
else
  cadena=['You�ve chosen NOT to see total waves'];
  set(handles.textInfo,'String',cadena);
end    

% --------------------------------------------------------------------
function varargout = radiobuttonNewW_Callback(h, eventdata, handles, varargin)
if (get(handles.radiobuttonNewW,'Value'))==1

  CheckV=get(handles.radiobuttonVolt,'Value');
  CheckI=get(handles.radiobuttonCurr,'Value');
  CheckP=get(handles.radiobuttonPow,'Value');
  mira=[CheckV,CheckI,CheckP];
  Cuantos=length(find(mira==1));
  if Cuantos>1
     cadena=['Sorry, but this mode is only active if just a kind of wave is represented (Volts,Amps,Watts)'];
     set(handles.textInfo,'String',cadena);     
     set(handles.radiobuttonNewW,'Value',0);
  else
     cadena=['You�ve chosen to see new waves created in each discontinuity'];
     set(handles.textInfo,'String',cadena);     
  end
else
  cadena=['You�ve chosen NOT to see new waves created in each discontinuity'];
  set(handles.textInfo,'String',cadena);
end    

% --------------------------------------------------------------------
function varargout = radiobuttonOldW_Callback(h, eventdata, handles, varargin)
if (get(handles.radiobuttonOldW,'Value'))==1
    
  CheckV=get(handles.radiobuttonVolt,'Value');
  CheckI=get(handles.radiobuttonCurr,'Value');
  CheckP=get(handles.radiobuttonPow,'Value');
  mira=[CheckV,CheckI,CheckP];
  Cuantos=length(find(mira==1));
  if Cuantos>1
     cadena=['Sorry, but this mode is only active if just a kind of wave is represented (Volts,Amps,Watts)'];
     set(handles.textInfo,'String',cadena);     
     set(handles.radiobuttonOldW,'Value',0);
  else
     cadena=['You�ve chosen to see old waves wich stay in quasi-stational mode'];
     set(handles.textInfo,'String',cadena);     
  end
else
  cadena=['You�ve chosen NOT to see old waves wich stay in quasi-stational mode'];
  set(handles.textInfo,'String',cadena);
end    

%-------------------------------------------------------------------------

% --------------------------------------------------------------------
function varargout = radiobuttonVolt_Callback(h, eventdata, handles, varargin)
CheckV=get(handles.radiobuttonVolt,'Value');

if (CheckV==0)
    CheckI=get(handles.radiobuttonCurr,'Value');
    CheckP=get(handles.radiobuttonPow,'Value');
    if (CheckI==1)|(CheckP==1)  %Si estaba ya escogido Corriente o potencia    
       set(handles.radiobuttonVolt,'Value',0); %desactivo el boton!
       cadena=['You�ve chosen NOT to see Voltage Waves!'];
       set(handles.textInfo,'String',cadena);
       if (CheckI==0)|(CheckP==0) %Si ya habia laguno inactivo solo qda un boton!
         set(handles.frameCyan,'Visible','on');  %Pongo lo d otras ondas 
         set(handles.frameAmarillo,'Visible','on');
         set(handles.frameRojo,'Visible','on');                 
         set(handles.frameV,'Visible','off');  %Quito lo d ondas V,I,P
         set(handles.frameI,'Visible','off');    
         set(handles.frameP,'Visible','off');                   
       end
    elseif (CheckI==0)&(CheckP==0)  %Si NO estaba escogido Corriente ni potencia    
       cadena=['Sorry, but at least one kind of wave must be chosen!'];
       set(handles.textInfo,'String',cadena);
       set(handles.radiobuttonVolt,'Value',1);       
    end
    
else
    
set(handles.radiobuttonVolt,'Value',1);
CheckI=get(handles.radiobuttonCurr,'Value');
CheckP=get(handles.radiobuttonPow,'Value');
if (CheckI==1)|(CheckP==1)  %Si estaba ya escogido Corriente o potencia
    
    set(handles.radiobuttonNewW,'Value',0);  %solo vere la ondas
    set(handles.radiobuttonOldW,'Value',0);  %totales
    set(handles.frameCyan,'Visible','off');  %Quito lo d otras ondas 
    set(handles.frameAmarillo,'Visible','off');    
    set(handles.frameRojo,'Visible','off');            
    set(handles.frameV,'Visible','on');  %Pongo lo d ondas V,I,P
    set(handles.frameI,'Visible','on');    
    set(handles.frameP,'Visible','on');        
    
    if (CheckI==1)&(CheckP==1)
      cadena=['You�ve chosen to see Voltage, Current and Power waves. Only total waves will be shown!'];
    elseif (CheckI==1)&(CheckP==0)
      cadena=['You�ve chosen to see Voltage and Current waves. Only total waves will be shown!'];        
      %Desactivo la opcion de osciloscopio si cambio las ondas!!
      set(handles.checkboxOsc,'Value',0);
       %Y la grafica del osciloscopio!
      grafOsc=handles.axesOsc;
      axes(grafOsc) %seleccionamos la grafica
      cla;       %borro lo que hubiera!
      axis([0 1 -1 1]);
      line([0 1],[0 0],'Color','k');      
    elseif (CheckI==0)&(CheckP==1)
      cadena=['You�ve chosen to see Voltage and Power waves. Only total waves will be shown!'];                
      %Desactivo la opcion de osciloscopio si cambio las ondas!!
      set(handles.checkboxOsc,'Value',0);                         
       %Y la grafica del osciloscopio!
      grafOsc=handles.axesOsc;
      axes(grafOsc) %seleccionamos la grafica
      cla;       %borro lo que hubiera!
      axis([0 1 -1 1]);
      line([0 1],[0 0],'Color','k');      
      
    end
else
    set(handles.frameCyan,'Visible','on');  %Pongo lo d otras ondas 
    set(handles.frameAmarillo,'Visible','on');        
    set(handles.frameRojo,'Visible','on');            
    set(handles.frameV,'Visible','off');  %Quito lo d ondas V,I,P
    set(handles.frameI,'Visible','off');    
    set(handles.frameP,'Visible','off');        
    
    cadena=['You�ve chosen to see only Voltage waves. You can choose to show Total,New and/or Old Waves !'];                    
end
set(handles.textInfo,'String',cadena);     
end %del if CheckV==0

% --------------------------------------------------------------------
function varargout = radiobuttonCurr_Callback(h, eventdata, handles, varargin)
CheckI=get(handles.radiobuttonCurr,'Value');

if (CheckI==0)
    CheckV=get(handles.radiobuttonVolt,'Value');
    CheckP=get(handles.radiobuttonPow,'Value');
    if (CheckV==1)|(CheckP==1)  %Si estaba ya escogido tension o potencia    
       set(handles.radiobuttonCurr,'Value',0); %desactivo el boton!
       cadena=['You�ve chosen NOT to see Current Waves!'];
       set(handles.textInfo,'String',cadena);
       if (CheckV==0)|(CheckP==0) %Si ya habia laguno inactivo solo qda un boton!
         set(handles.frameCyan,'Visible','on');  %Pongo lo d otras ondas 
         set(handles.frameAmarillo,'Visible','on');        
         set(handles.frameRojo,'Visible','on');                 
         set(handles.frameV,'Visible','off');  %Quito lo d ondas V,I,P
         set(handles.frameI,'Visible','off');    
         set(handles.frameP,'Visible','off');                   
       end
    elseif (CheckV==0)&(CheckP==0)  %Si NO estaba escogido tension ni potencia    
       cadena=['Sorry, but at least one kind of wave must be chosen!'];
       set(handles.textInfo,'String',cadena);        
       set(handles.radiobuttonCurr,'Value',1);              
    end
    
else

set(handles.radiobuttonCurr,'Value',1);
CheckV=get(handles.radiobuttonVolt,'Value');
CheckP=get(handles.radiobuttonPow,'Value');
if (CheckV==1)|(CheckP==1)  %Si estaba ya escogido tension o potencia
    
    set(handles.radiobuttonNewW,'Value',0);  %solo vere la ondas
    set(handles.radiobuttonOldW,'Value',0);  %totales
    set(handles.frameCyan,'Visible','off');  %Quito lo d otras ondas 
    set(handles.frameAmarillo,'Visible','off');    
    set(handles.frameRojo,'Visible','off');            
    set(handles.frameV,'Visible','on');  %Pongo lo d ondas V,I,P
    set(handles.frameI,'Visible','on');    
    set(handles.frameP,'Visible','on');            
    
    if (CheckV==1)&(CheckP==1)
      cadena=['You�ve chosen to see Voltage, Current and Power waves. Only total waves will be shown!'];
    elseif (CheckV==1)&(CheckP==0)
      cadena=['You�ve chosen to see Voltage and Current waves. Only total waves will be shown!'];        
      %Desactivo la opcion de osciloscopio si cambio las ondas!!
      set(handles.checkboxOsc,'Value',0);                               
       %Y la grafica del osciloscopio!
      grafOsc=handles.axesOsc;
      axes(grafOsc) %seleccionamos la grafica
      cla;       %borro lo que hubiera!
      axis([0 1 -1 1]);
      line([0 1],[0 0],'Color','k');            
    elseif (CheckV==0)&(CheckP==1)
      cadena=['You�ve chosen to see Current and Power waves. Only total waves will be shown!'];                
      %Desactivo la opcion de osciloscopio si cambio las ondas!!
      set(handles.checkboxOsc,'Value',0);                         
       %Y la grafica del osciloscopio!
      grafOsc=handles.axesOsc;
      axes(grafOsc) %seleccionamos la grafica
      cla;       %borro lo que hubiera!
      axis([0 1 -1 1]);
      line([0 1],[0 0],'Color','k');      
    end
else
    set(handles.frameCyan,'Visible','on');  %Pongo lo d otras ondas 
    set(handles.frameAmarillo,'Visible','on');        
    set(handles.frameRojo,'Visible','on');            
    set(handles.frameV,'Visible','off');  %Quito lo d ondas V,I,P
    set(handles.frameI,'Visible','off');    
    set(handles.frameP,'Visible','off');        
    
    cadena=['You�ve chosen to see only Current waves. You can choose to show Total,New and/or Old Waves !'];                    
end
set(handles.textInfo,'String',cadena);     
end %del If CheckI==0

% --------------------------------------------------------------------
function varargout = radiobuttonPow_Callback(h, eventdata, handles, varargin)
CheckP=get(handles.radiobuttonPow,'Value');

if (CheckP==0)
    CheckV=get(handles.radiobuttonVolt,'Value');
    CheckI=get(handles.radiobuttonCurr,'Value');
    if (CheckV==1)|(CheckI==1)  %Si estaba ya escogido tension o corriente    
       set(handles.radiobuttonPow,'Value',0); %desactivo el boton!
       cadena=['You�ve chosen NOT to see Power Waves!'];
       set(handles.textInfo,'String',cadena);
       if (CheckV==0)|(CheckI==0) %Si ya habia laguno inactivo solo qda un boton!
         set(handles.frameCyan,'Visible','on');  %Pongo lo d otras ondas 
         set(handles.frameAmarillo,'Visible','on');  
         set(handles.frameRojo,'Visible','on');                 
         set(handles.frameV,'Visible','off');  %Quito lo d ondas V,I,P
         set(handles.frameI,'Visible','off');    
         set(handles.frameP,'Visible','off');                   
       end
    elseif (CheckV==0)&(CheckI==0)  %Si NO estaba escogido ni tension ni corriente    
       cadena=['Sorry, but at least one kind of wave must be chosen!'];
       set(handles.textInfo,'String',cadena);             
       set(handles.radiobuttonPow,'Value',1);              
    end
    
else

set(handles.radiobuttonPow,'Value',1);
CheckV=get(handles.radiobuttonVolt,'Value');
CheckI=get(handles.radiobuttonCurr,'Value');
if (CheckV==1)|(CheckI==1)  %Si estaba ya escogido Tension o Corriente
    
    set(handles.radiobuttonNewW,'Value',0);  %solo vere la ondas
    set(handles.radiobuttonOldW,'Value',0);  %totales
    set(handles.frameCyan,'Visible','off');  %Quito lo d otras ondas 
    set(handles.frameAmarillo,'Visible','off');    
    set(handles.frameRojo,'Visible','off');        
    set(handles.frameV,'Visible','on');  %Pongo lo d ondas V,I,P
    set(handles.frameI,'Visible','on');    
    set(handles.frameP,'Visible','on');        

    
    if (CheckV==1)&(CheckI==1)
      cadena=['You�ve chosen to see Voltage, Current and Power waves. Only total waves will be shown!'];
    elseif (CheckV==1)&(CheckI==0)
      cadena=['You�ve chosen to see Voltage and Current waves. Only total waves will be shown!'];        
      %Desactivo la opcion de osciloscopio si cambio las ondas!!
      set(handles.checkboxOsc,'Value',0);                         
       %Y la grafica del osciloscopio!
      grafOsc=handles.axesOsc;
      axes(grafOsc) %seleccionamos la grafica
      cla;       %borro lo que hubiera!
      axis([0 1 -1 1]);
      line([0 1],[0 0],'Color','k');      
    elseif (CheckV==0)&(CheckI==1)
      cadena=['You�ve chosen to see Current and Power waves. Only total waves will be shown!'];                
      %Desactivo la opcion de osciloscopio si cambio las ondas!!
      set(handles.checkboxOsc,'Value',0);                               
       %Y la grafica del osciloscopio!
      grafOsc=handles.axesOsc;
      axes(grafOsc) %seleccionamos la grafica
      cla;       %borro lo que hubiera!
      axis([0 1 -1 1]);
      line([0 1],[0 0],'Color','k');      
    end
else
    set(handles.frameCyan,'Visible','on');  %Pongo lo d otras ondas 
    set(handles.frameAmarillo,'Visible','on');    
    set(handles.frameRojo,'Visible','on');            
    set(handles.frameV,'Visible','off');  %Quito lo d ondas V,I,P
    set(handles.frameI,'Visible','off');    
    set(handles.frameP,'Visible','off');        
    
    cadena=['You�ve chosen to see only Voltage waves. You can choose to show Total,New and/or Old Waves !'];                    
end
set(handles.textInfo,'String',cadena);     
end  %del if CheckP==0




% --------------------------------------------------------------------
function varargout = radiobuttonVX10_Callback(h, eventdata, handles, varargin)

%primero miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if CheckIter==1
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);     
     return;     
 end

Valor=get(handles.radiobuttonVX10,'Value');
if Valor==1
    set(handles.radiobuttonVX10,'UserData',10);  %ponemos un factor de 10
            %para representar la tension y que salga del mismo orden de magnitud
            %que la corriente (mA) y la potencia (mW)
    cadena=['Voltage Probe X10 selected! You will see the voltage amplified 10 times !'];
    set(handles.textInfo,'String',cadena);     
elseif Valor==0
    set(handles.radiobuttonVX10,'UserData',1);  %ponemos un factor de 1
            %para ver los niveles de tension reales!
    cadena=['Voltage Probe X1 selected! You will see the actual voltage levels !'];
    set(handles.textInfo,'String',cadena);     
end    
      
    
    
%--- Funcion q dibuja las ondas TOTALES V,I,P frente al tiempo dependiendo 
%--  del tipo de seleccion hecha ----------------------------------------
%-----------------------------------------------------------------------
function dibujaOsc(handles,Factor,UnitT,FactorT,UnitL,FactorL)
grafOsc=handles.axesOsc;
axes(grafOsc) %seleccionamos la grafica
cla;       %borro lo que hubiera!
%Cojo la estructura con los datos de tiempo,V,I,P actualizados!
Osc=get(handles.axesOsc,'UserData');

%pongo la escala temporal y de amplitud de pendiendo de lo q represente 
%y del tiempo representado!!
Tstart=0;
TUni=1/FactorT;  %cojo como tiempo final la unidad de tiempo q usemos
                 %e ire ampliandola conforme lleguen mas datos
tfinal=Osc.time(length(Osc.time));  %El ultimo instante de tiempo computado!
N=ceil(tfinal/TUni);
N=N+1;  %El numero de veces q voy a dibujar TUni en eje X (de tiempos)
Tend=TUni*N;

axis([Tstart Tend -4*Factor 4*Factor]);
line([Tstart Tend],[0 0],'Color','k');
xLabel(['Time in ',UnitT]);
IndTime=[0:(Tend/4):Tend];
set(grafOsc,'XTick',(IndTime));
set(grafOsc,'XTickLabel',(IndTime)*FactorT);

%miro lo que tengo que representar en cada momemto!
CheckV=get(handles.radiobuttonVolt,'Value');
CheckI=get(handles.radiobuttonCurr,'Value');
CheckP=get(handles.radiobuttonPow,'Value');

if CheckV==1
    plot(Osc.time,Osc.V,'c');
end
if CheckI==1
    plot(Osc.time,Osc.I,'y');
end
if CheckP==1
    plot(Osc.time,Osc.P,'r');
end






% --------------------------------------------------------------------
function varargout = checkboxOsc_Callback(h, eventdata, handles, varargin)

 Valor=get(handles.checkboxOsc,'Value'); 
 ValorAnt=abs(Valor-1); %el valor anterior, 1-->0 0-->1
 %primero miro q esten introducidos todos los datos!
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     set(handles.checkboxOsc,'Value',ValorAnt);          
     return;
 end

%miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if CheckIter==1
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);  
     set(handles.checkboxOsc,'Value',ValorAnt);     
     return;     
 end

LOsc=get(handles.textLOsc,'UserData');
if LOsc==inf
     cadena=['Sorry, but you must first introduce a value for the point where the probe must be...'];
     set(handles.textInfo,'String',cadena);  
     set(handles.checkboxOsc,'Value',ValorAnt);     
     return;     
 end
    

if Valor==0
     cadena=['Oscilloscope UnActivated!'];
     set(handles.textInfo,'String',cadena);       
elseif Valor==1
     cadena=['Oscilloscope Activated! Vertical red line in simulations represents the point in the line where the probe is located! Press any key to reset simulation!'];
     set(handles.textInfo,'String',cadena);
     %Ahora viene la rutina de coger con el raton
     %LOsc es la longitud en metros, q es la ESCALA REAL de la linea,
              %aunqe usamos el factor FactorL para expresarlo mejor!
     FactorL=get(handles.textDeltaL,'UserData');
     if FactorL==1
         UnitL='m';
     elseif FactorL==1/1000
         UnitL='Km';
     elseif FactorL==1000
         UnitL='mm';
     elseif FactorL==1000000
         UnitL='microm';
     elseif FactorL==0
         UnitL='m';      
     end
     
     %reseteo para no tener problemas!
     pause;     
     pushbuttonReset_Callback(h, eventdata, handles, varargin);
end




% --------------------------------------------------------------------
%  introducimos el punto donde estara la sonda en la linea
%  en metros !!!! ---------------------------------------------
function varargout = editLOsc_Callback(h, eventdata, handles, varargin)
 %primero miro q esten introducidos todos los datos!
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     set(handles.editLOsc,'String','-');
     set(handles.textLOsc,'UserData',inf);     %para indicar q no es correcto!
     return;
 end

%miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if CheckIter==1
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);  
     set(handles.editLOsc,'String','-');
     set(handles.textLOsc,'UserData',inf);     %para indicar q no es correcto!
     return;     
 end

     Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
     Pause=get(handles.editPause,'UserData');
     if (Res==0)|(Pause==-2)
       cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
       set(handles.textInfo,'String',cadena);     
       set(handles.editLOsc,'String','-');
       set(handles.textLOsc,'UserData',inf);     %para indicar q no es correcto!           
       return;
     end    
 
L=X(5);    %longitud de la linea en Metros!
Lgen=L/4;   %de los datos cogidos!
lambda=X(3);   %longitud de onda en metros!
deltaL=lambda/Res;
l=[-Lgen:deltaL:L];  %Vector de coordenadas de longitud TOTAL
Lmin=l(1);  %Coordenada minima que ha calculado el ordenador!
Lmax=l(length(l)); %Coordenada maxima!
 
LOsc=get(handles.editLOsc,'String');
LOsc=str2num(LOsc);
if (LOsc<Lmin) | (LOsc>Lmax)
     cadena=['Sorry, but the probe must be between ',num2str(Lmin),' and '...
             ,num2str(Lmax),' meters!'];
     set(handles.textInfo,'String',cadena);  
     set(handles.editLOsc,'String','-');
     set(handles.textLOsc,'UserData',inf);     %para indicar q no es correcto!    
else
     %Tengo q buscar el valor de l que se parece mas al valor de LOsc
     % y ese valor lo pondre en el String de editLOsc
     % y en UserData de textLOsc      

        %Busco el l q esta mas cerca de LOsc
     Min=min(abs(l-LOsc));
     IndL=find(abs(l-LOsc)==Min);
     LOsc=l(IndL);   %Este es el punto q buscabamos!
     LOsc=LOsc(1);   %Por si acaso habia dos!
     
     %longitud en metros, q es la ESCALA REAL de la linea,
     %aunqe usamos el factor FactorL para expresarlo mejor!
     %lo guardamos en UserData de textLOsc
     set(handles.textLOsc,'UserData',LOsc);  %Guardo el valor!
     set(handles.editLOsc,'String',num2str(LOsc));  %Guardo el valor!  
     %texto informativo!
     cadena=['Point ',num2str(LOsc),' meters is the current probe position!Press any key to reset the simulation...'];
     set(handles.textInfo,'String',cadena); 

     %reseteo para no tener problemas!
     pause;
     pushbuttonReset_Callback(h, eventdata, handles, varargin);
 end
 

%----- MANDOS PARA LA MANIPULACION DE LOS MARKERS --------------------



% --------------------------------------------------------------------
function varargout = checkboxMarkers_Callback(h, eventdata, handles, varargin)

Valor=get(handles.checkboxMarkers,'Value');
ValorAnterior=abs(Valor-1);  %Si es 1 era 0, y si es 0 era 1
 %primero miro q esten introducidos todos los datos!
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     set(handles.checkboxMarkers,'Value',ValorAnterior);     %para indicar q no es correcto!     
     return;
 end

 Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
 Pause=get(handles.editPause,'UserData');

 %miro que este puesta la resolucion espacial! Me movere deltaL!
 if (Res==0)|(Pause==-2)
     cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
     set(handles.textInfo,'String',cadena);     
     return;
 end         
 
%miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if (CheckIter==1) & (Pause~=-1)
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);  
     set(handles.checkboxMarkers,'Value',ValorAnterior);     %para indicar q no es correcto!
     return;     
 end
 
 %Miro que se haya hecho alguna simulacion no resetada para poder representar
 %los markers con la figura!
 CheckStart=get(handles.pushbuttonVer,'UserData');
 if CheckStart==0
     cadena=['Sorry, but you must first launch any simulation to show markers!'];
     set(handles.textInfo,'String',cadena);  
     set(handles.checkboxMarkers,'Value',ValorAnterior);     %para indicar q no es correcto!
     return;     
 end
 
 
 
 if Valor==1
   cadena=['Two markers will be displayed in the line. You can move them to measure wave amplitudes'];
   set(handles.textInfo,'String',cadena);
   %Y dibujo los markers que toquen!
   dibujaEstructGraf(handles)
 elseif Valor==0
   cadena=['No markers will be displayed!'];
   set(handles.textInfo,'String',cadena);
 end
  


% --------------------------------------------------------------------
function varargout = radiobuttonMarker1_Callback(h, eventdata, handles, varargin)

CheckMarker=get(handles.checkboxMarkers,'Value');
Valor=get(handles.radiobuttonMarker1,'Value');
ValorAnterior=abs(Valor-1);  %Si es 1 era 0, y si es 0 era 1
 %primero miro q esten introducidos todos los datos!
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     set(handles.radiobuttonMarker1,'Value',ValorAnterior);     %para indicar q no es correcto!
     return;
 end

 Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
 Pause=get(handles.editPause,'UserData');

 %miro que este puesta la resolucion espacial! Me movere deltaL!
 if (Res==0)|(Pause==-2)
     cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
     set(handles.textInfo,'String',cadena);     
     return;
 end         
 
%miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if (CheckIter==1) & (Pause~=-1)
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);  
     set(handles.radiobuttonMarker1,'Value',ValorAnterior);     %para indicar q no es correcto!
     return;     
 end

 if (Valor==1)&(CheckMarker==1)
%     set(handles.radiobuttonMarker2,'Value',0);
     cadena=['You can move marker 1 by using left and right arrow buttons or by typing coordinates...'];
     set(handles.textInfo,'String',cadena);       
 elseif (Valor==0)&(CheckMarker==1)
%     set(handles.radiobuttonMarker2,'Value',1);
     cadena=['You can move marker 2 by using left and right arrow buttons or by typing coordinates...'];
     set(handles.textInfo,'String',cadena);            
 elseif (CheckMarker==0)&(Valor==1)
     cadena=['You must first select Markers On in order to choose one Marker to move!'];
     set(handles.textInfo,'String',cadena);    
     set(handles.radiobuttonMarker1,'Value',0);     
     set(handles.radiobuttonMarker2,'Value',0);          
 end

% --------------------------------------------------------------------
function varargout = radiobuttonMarker2_Callback(h, eventdata, handles, varargin)

CheckMarker=get(handles.checkboxMarkers,'Value');
Valor=get(handles.radiobuttonMarker2,'Value');
ValorAnterior=abs(Valor-1);  %Si es 1 era 0, y si es 0 era 1
 %primero miro q esten introducidos todos los datos!
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     set(handles.radiobuttonMarker2,'Value',ValorAnterior);     %para indicar q no es correcto!
     return;
 end

 Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
 Pause=get(handles.editPause,'UserData');

 %miro que este puesta la resolucion espacial! Me movere deltaL!
 if (Res==0)|(Pause==-2)
     cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
     set(handles.textInfo,'String',cadena);     
     return;
 end         
 
%miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if (CheckIter==1) & (Pause~=-1)
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);  
     set(handles.radiobuttonMarker2,'Value',ValorAnterior);     %para indicar q no es correcto!
     return;     
 end

 if (Valor==1)&(CheckMarker==1)
 %    set(handles.radiobuttonMarker1,'Value',0);
     cadena=['You can move marker 2 by using left and right arrow buttons or by typing coordinates...'];
     set(handles.textInfo,'String',cadena);       
 elseif (Valor==0)&(CheckMarker==1)
 %    set(handles.radiobuttonMarker1,'Value',1);
     cadena=['You can move marker 1 by using left and right arrow buttons or by typing coordinates...'];
     set(handles.textInfo,'String',cadena);            
 elseif (CheckMarker==0)&(Valor==1)
     cadena=['You must first select Markers On in order to choose one Marker to move!'];
     set(handles.textInfo,'String',cadena);    
     set(handles.radiobuttonMarker1,'Value',0);     
     set(handles.radiobuttonMarker2,'Value',0);          
 end
 
 

%----------- variacion de las coordenadas de los markers por teclado --
% ---------------------------------------------------------------------
function varargout = editM1L_Callback(h, eventdata, handles, varargin)
 %primero miro q esten introducidos todos los datos!
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     set(handles.editM1L,'String','-');
     set(handles.editM1L,'UserData',inf);     %para indicar q no es correcto!
     return;
 end

%miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if CheckIter==1
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);  
     set(handles.editM1L,'String','-');
     set(handles.editM1L,'UserData',inf);     %para indicar q no es correcto!
     return;     
 end

     Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
     Pause=get(handles.editPause,'UserData');
     if (Res==0)|(Pause==-2)
       cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
       set(handles.textInfo,'String',cadena);     
       set(handles.editM1L,'String','-');
       set(handles.editM1L,'UserData',inf);     %para indicar q no es correcto!           
       return;
     end  
     
L=X(5);    %longitud de la linea en Metros!
Lgen=L/4;   %de los datos cogidos!
lambda=X(3);   %longitud de onda en metros!
deltaL=lambda/Res;
l=[-Lgen:deltaL:L];  %Vector de coordenadas de longitud TOTAL
Lmin=l(1);  %Coordenada minima que ha calculado el ordenador!
Lmax=l(length(l)); %Coordenada maxima!
 
M1L=get(handles.editM1L,'String');
M1L=str2num(M1L);
if (M1L<Lmin) | (M1L>Lmax)
     cadena=['Sorry, but markers must be between ',num2str(Lmin),' and '...
             ,num2str(Lmax),' meters!'];
     set(handles.textInfo,'String',cadena);  
     set(handles.editM1L,'String','-');
     set(handles.editM1L,'UserData',inf);     %para indicar q no es correcto!    
else
     %Tengo q buscar el valor de l que se parece mas al valor de M1L
     % y ese valor lo pondre en el String de editM1L
     % y en UserData de editM1L     

        %Busco el l q esta mas cerca de LOsc
     Min=min(abs(l-M1L));
     IndL=find(abs(l-M1L)==Min);
     M1L=l(IndL);   %Este es el punto q buscabamos!
     M1L=M1L(1);   %Por si acaso habia dos!
     
     %longitud en metros, q es la ESCALA REAL de la linea,
     %aunqe usamos el factor FactorL para expresarlo mejor!
     %lo guardamos en UserData de editM1L
     set(handles.editM1L,'UserData',M1L);  %Guardo el valor!
     set(handles.editM1L,'String',num2str(M1L));  %Guardo el valor!  
     %texto informativo!
     cadena=['Point ',num2str(M1L),' meters is the current marker 1 position...'];
     set(handles.textInfo,'String',cadena); 
     
     %Y dibujo los markers que toquen!
     dibujaEstructGraf(handles)

 end




% --------------------------------------------------------------------
function varargout = editM2L_Callback(h, eventdata, handles, varargin)
 %primero miro q esten introducidos todos los datos!
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     set(handles.editM1L,'String','-');
     set(handles.editM1L,'UserData',inf);     %para indicar q no es correcto!
     return;
 end

 Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
 Pause=get(handles.editPause,'UserData');

 %miro que este puesta la resolucion espacial! Me movere deltaL!
 if (Res==0)|(Pause==-2)
     cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
     set(handles.textInfo,'String',cadena);     
     return;
 end         
 
%miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if (CheckIter==1) & (Pause~=-1)
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);  
     set(handles.editM1L,'String','-');
     set(handles.editM1L,'UserData',inf);     %para indicar q no es correcto!
     return;     
 end

     Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
     Pause=get(handles.editPause,'UserData');
     if (Res==0)|(Pause==-2)
       cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
       set(handles.textInfo,'String',cadena);     
       set(handles.editM2L,'String','-');
       set(handles.editM2L,'UserData',inf);     %para indicar q no es correcto!           
       return;
     end   
     
L=X(5);    %longitud de la linea en Metros!
Lgen=L/4;   %de los datos cogidos!
lambda=X(3);   %longitud de onda en metros!
deltaL=lambda/Res;
l=[-Lgen:deltaL:L];  %Vector de coordenadas de longitud TOTAL
Lmin=l(1);  %Coordenada minima que ha calculado el ordenador!
Lmax=l(length(l)); %Coordenada maxima!
 
M2L=get(handles.editM2L,'String');
M2L=str2num(M2L);
if (M2L<Lmin) | (M2L>Lmax)
     cadena=['Sorry, but markers must be between ',num2str(min),' and '...
             ,num2str(Lmax),' meters!'];
     set(handles.textInfo,'String',cadena);  
     set(handles.editM2L,'String','-');
     set(handles.editM2L,'UserData',inf);     %para indicar q no es correcto!    
else
     %Tengo q buscar el valor de l que se parece mas al valor de M1L
     % y ese valor lo pondre en el String de editM1L
     % y en UserData de editM1L
      
        %Busco el l q esta mas cerca de LOsc
     Min=min(abs(l-M2L));
     IndL=find(abs(l-M2L)==Min);
     M2L=l(IndL);   %Este es el punto q buscabamos!
     M2L=M2L(1);   %Por si acaso habia dos!
     
     %longitud en metros, q es la ESCALA REAL de la linea,
     %aunqe usamos el factor FactorL para expresarlo mejor!
     %lo guardamos en UserData de editM1L
     set(handles.editM2L,'UserData',M2L);  %Guardo el valor!
     set(handles.editM2L,'String',num2str(M2L));  %Guardo el valor!  
     %texto informativo!
     cadena=['Point ',num2str(M2L),' meters is the current marker 1 position...'];
     set(handles.textInfo,'String',cadena); 

     %Y dibujo los markers que toquen!
     dibujaEstructGraf(handles)
     
 end



%------ botones de variar los markers con cursores! ---------------
% --------------------------------------------------------------------
function varargout = pushbuttonLeft_Callback(h, eventdata, handles, varargin)
 %primero miro q esten introducidos todos los datos!
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     return;
 end
 
 Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
 Pause=get(handles.editPause,'UserData');

 %miro que este puesta la resolucion espacial! Me movere deltaL!
 if (Res==0)|(Pause==-2)
     cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
     set(handles.textInfo,'String',cadena);     
     return;
 end         
 
%miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if (CheckIter==1) & (Pause~=-1)
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);  
     return;     
 end
 
 %y miro q este seleccionado Markers ON y algun Marker!
CheckMarker=get(handles.checkboxMarkers,'Value');
Marker1=get(handles.radiobuttonMarker1,'Value');
Marker2=get(handles.radiobuttonMarker2,'Value');

if (CheckMarker==0) | ( (Marker1==0)&(Marker2==0) )
     cadena=['Sorry, but a you must pick up Makers ON and select either Marker 1 or Marker 2 to be moved...'];
     set(handles.textInfo,'String',cadena);  
     return;         
end

 lambda=X(3);  %longitud de onda en m
 L=X(5);       %longitud de la linea en m
 Lgen=L/4;       %longitud de la linea del generador, que esta adaptada a la 
 deltaL=lambda/Res;  %resolucion en L en metros
 l=[-Lgen:deltaL:L];  %el vector de posiciones!
 
%muevo el que toque siempre y cuando no pase los limites!
if Marker1==1
    %Muevo el marker 1 restandole deltaL
   M1L=get(handles.editM1L,'UserData');
   M1L=M1L-deltaL;   %Lo muevo a la izquierda!!
   %Ahora me aseguro de que la longitud escogida este dentro de las
   %posibles longitudes!
   Min=min(abs(l-M1L));
   IndL=find(abs(l-M1L)==Min);
   M1L=l(IndL);   %Este es el punto q buscabamos!
   M1L=M1L(1);   %Por si acaso habia dos!
   
   if (M1L<-Lgen) | (M1L>L)
     cadena=['Sorry, but markers must be between ',num2str(-Lgen),' and '...
             ,num2str(L),' meters!'];
     set(handles.textInfo,'String',cadena);  
     return;
   else
     set(handles.editM1L,'UserData',M1L);  
     set(handles.editM1L,'String',num2str(M1L));       
     cadena=['Marker 1 is set to point ',num2str(M1L),' m'];
     set(handles.textInfo,'String',cadena);  
   end
end
if Marker2==1
    %Muevo el marker 1 restandole deltaL
   M2L=get(handles.editM2L,'UserData');
   M2L=M2L-deltaL;   %Lo muevo a la izquierda!!
   %Ahora me aseguro de que la longitud escogida este dentro de las
   %posibles longitudes!
   Min=min(abs(l-M2L));
   IndL=find(abs(l-M2L)==Min);
   M2L=l(IndL);   %Este es el punto q buscabamos!
   M2L=M2L(1);   %Por si acaso habia dos!
   
   if (M2L<-Lgen) | (M2L>L)
     cadena=['Sorry, but markers must be between ',num2str(-Lgen),' and '...
             ,num2str(L),' meters!'];
     set(handles.textInfo,'String',cadena);  
     return;
   else
     set(handles.editM2L,'UserData',M2L);  
     set(handles.editM2L,'String',num2str(M2L));       
     cadena=['Marker 2 is set to point ',num2str(M2L),' m'];
     set(handles.textInfo,'String',cadena);  
   end    
end
     
%Y dibujo los markers que toquen   
%NOTA: al dibujar los amrkers ademas se calculan las amplitudes 
%correspondientes!!
dibujaEstructGraf(handles)



% --------------------------------------------------------------------
function varargout = pushbuttonRight_Callback(h, eventdata, handles, varargin)
 %primero miro q esten introducidos todos los datos!
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     return;
 end

 Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
 Pause=get(handles.editPause,'UserData');

 %miro que este puesta la resolucion espacial! Me movere deltaL!
 if (Res==0)|(Pause==-2)
     cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
     set(handles.textInfo,'String',cadena);     
     return;
 end         
 
 %miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if (CheckIter==1) & (Pause~=-1)
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);  
     return;     
 end
 
 %y miro q este seleccionado Markers ON y algun Marker!
CheckMarker=get(handles.checkboxMarkers,'Value');
Marker1=get(handles.radiobuttonMarker1,'Value');
Marker2=get(handles.radiobuttonMarker2,'Value');

if (CheckMarker==0) | ( (Marker1==0)&(Marker2==0) )
     cadena=['Sorry, but a you must pick up Makers ON and select either Marker 1 or Marker 2 to be moved...'];
     set(handles.textInfo,'String',cadena);  
     return;         
end

 lambda=X(3);  %longitud de onda en m
 L=X(5);       %longitud de la linea en m
 Lgen=L/4;       %longitud de la linea del generador, que esta adaptada a la 
 deltaL=lambda/Res;  %resolucion en L en metros
 l=[-Lgen:deltaL:L];  %el vector de posiciones!
 
%muevo el que toque siempre y cuando no pase los limites!
if Marker1==1
    %Muevo el marker 1 restandole deltaL
   M1L=get(handles.editM1L,'UserData');
   M1L=M1L+deltaL;   %Lo muevo a la izquierda!!
   %Ahora me aseguro de que la longitud escogida este dentro de las
   %posibles longitudes!
   Min=min(abs(l-M1L));
   IndL=find(abs(l-M1L)==Min);
   M1L=l(IndL);   %Este es el punto q buscabamos!
   M1L=M1L(1);   %Por si acaso habia dos!
   
   if (M1L<-Lgen) | (M1L>L)
     cadena=['Sorry, but markers must be between ',num2str(-Lgen),' and '...
             ,num2str(L),' meters!'];
     set(handles.textInfo,'String',cadena);  
     return;
   else
     set(handles.editM1L,'UserData',M1L);  
     set(handles.editM1L,'String',num2str(M1L));       
     cadena=['Marker 1 is set to point ',num2str(M1L),' m'];
     set(handles.textInfo,'String',cadena);  
   end
end
if Marker2==1
    %Muevo el marker 1 restandole deltaL
   M2L=get(handles.editM2L,'UserData');
   M2L=M2L+deltaL;   %Lo muevo a la izquierda!!
   %Ahora me aseguro de que la longitud escogida este dentro de las
   %posibles longitudes!
   Min=min(abs(l-M2L));
   IndL=find(abs(l-M2L)==Min);
   M2L=l(IndL);   %Este es el punto q buscabamos!
   M2L=M2L(1);   %Por si acaso habia dos!
   
   if (M2L<-Lgen) | (M2L>L)
     cadena=['Sorry, but markers must be between ',num2str(-Lgen),' and '...
             ,num2str(L),' meters!'];
     set(handles.textInfo,'String',cadena);  
     return;
   else
     set(handles.editM2L,'UserData',M2L);  
     set(handles.editM2L,'String',num2str(M2L));       
     cadena=['Marker 2 is set to point ',num2str(M2L),' m'];
     set(handles.textInfo,'String',cadena);  
   end    
end
     
%Y dibujo los markers que toquen   
%NOTA: al dibujar los markers ademas se calculan las amplitudes 
%correspondientes!!
dibujaEstructGraf(handles) 
 
%------ boton de cambiar la grafica donde dibujo los markers ! ---------
% --------------------------------------------------------------------
function varargout = pushbuttonChangeG_Callback(h, eventdata, handles, varargin)
 %primero miro q esten introducidos todos los datos!
 X=cogeDatos(handles);
 %Compruebo que todos los datos esten introducidos
 if ( any(X==-1) | any(X==inf) )
     cadena=['Please, check all parameters are initialized, please!'];
     set(handles.textInfo,'String',cadena);
     return;
 end

 Res=get(handles.editRes,'UserData'); %resolucion en puntos/longitud de onda
 Pause=get(handles.editPause,'UserData');

 %miro que este puesta la resolucion espacial! Me movere deltaL!
 if (Res==0)|(Pause==-2)
     cadena=['Please, introduce first the Resolution and Pause parameters, please...'];
     set(handles.textInfo,'String',cadena);     
     return;
 end  
 
 %miro q no interrumpa una simulacion!
 CheckIter=get(handles.textIter,'UserData');
 if (CheckIter==1) & (Pause~=-1)
     cadena=['Sorry, but a simulation is in progress...'];
     set(handles.textInfo,'String',cadena);  
     return;     
 end
 
%tambien comrpuebo que haya alguna marker activo con Marker ON
 %y miro q este seleccionado Markers ON y algun Marker!
CheckMarker=get(handles.checkboxMarkers,'Value');
Marker1=get(handles.radiobuttonMarker1,'Value');
Marker2=get(handles.radiobuttonMarker2,'Value');

if (CheckMarker==0) | ( (Marker1==0)&(Marker2==0) )
     cadena=['Sorry, but a you must pick up Makers ON and select either Marker 1 or Marker 2 to be moved...'];
     set(handles.textInfo,'String',cadena);  
     return;         
end

%y lo unico que hago es coger el SructGraf y cambiar su campo GrafActual
%que debe valer 0 1 o 2 para representar Graf1, Graf2 o Graf3
StGraf=get(handles.frameGraf,'UserData');
GrafAct=StGraf.GrafActual;
GrafAct=mod(GrafAct+1,3);  %para cambiar a la grafica siguiente
                           %Hago mod 3 pra q salga 1,2 o 3!
StGraf.GrafActual=GrafAct;
set(handles.frameGraf,'UserData',StGraf);

%Y dibujo los markers que toquen   
%NOTA: al dibujar los markers ademas se calculan las amplitudes 
%correspondientes!!
dibujaEstructGraf(handles) 



 
 %------------- MUY IMPORTANTE ------------------------------
 
%---------------------------------------------------------------------
%---- Para dibujar la grafica que hubiera y luego ponerle los markers! 
 function dibujaEstructGraf(handles)
    graf=handles.axesLinea;
    axes(graf) %seleccionamos la grafica
    cla;       %borro lo que hubiera!
 
    %La estructura de datos de la grafica representada!
    StructGraf=get(handles.frameGraf,'UserData');
      
    l=StructGraf.l;
    L=get(handles.textL,'UserData');  %longitud de la linea en m
    Lgen=L/4;                         %longitdu del generador!
    %Factor sirve para establecer la escala vertical de las graficas!!
    Factor=get(handles.checkboxMarkers,'UserData');
    %Dibujo la linea, generador, impedancias...
    dibujaLinea(Lgen,L,Factor,handles);
    
  %Vemos que tipos de ondas hay que representar!------------------------
  CheckV=get(handles.radiobuttonVolt,'Value');
  CheckI=get(handles.radiobuttonCurr,'Value');
  CheckP=get(handles.radiobuttonPow,'Value');
  %las graficas que puede que tengamos que dibujar!
  Graf1=StructGraf.Graf1;
  Graf2=StructGraf.Graf2;
  Graf3=StructGraf.Graf3;
  %los markers que tenemos que dibujar!
  LM1=get(handles.editM1L,'UserData');  %la longitud donde tengo que colocar
                                        %el marker 1
  LM2=get(handles.editM2L,'UserData');
  
  %Si falta por introducir algun marker, lo dibujo como si estuviera en L/4
  % y tambien si se sale de los limites
  if (LM1==inf) | (LM1<-Lgen) | (LM1>L)
    LM1=L/4;
    Min=min(abs(l-LM1));
    IndL=find(abs(l-LM1)==Min);
    LM1=l(IndL);   %Este es el punto q buscabamos!
    LM1=LM1(1);   %Por si acaso habia dos!    
    set(handles.editM1L,'UserData',LM1);
    set(handles.editM1L,'String',num2str(LM1));    
  end
  %y el segundo marker en 3*L/4
  if (LM2==inf)| (LM2<-Lgen) | (LM2>L)
    LM2=3*L/4;
    Min=min(abs(l-LM2));
    IndL=find(abs(l-LM2)==Min);
    LM2=l(IndL);   %Este es el punto q buscabamos!
    LM2=LM2(1);   %Por si acaso habia dos!    
    set(handles.editM2L,'UserData',LM2);
    set(handles.editM2L,'String',num2str(LM2));    
  end
   
  
  %pues ahora a dibujar!
      mira=[CheckV,CheckI,CheckP];
      Cuantos=length(find(mira==1)); %par aver si hay mas de un tipo de onda
      CualGraf=StructGraf.GrafActual;
      if CheckV==1
          if Cuantos>1
              dibujaOndasV(handles,Lgen,L,Factor,l,Graf1,Graf2,Graf3,'c',1);

              %Dibujo el marker de tension total pues esta escogida en Graf1
              %pero solo si asi lo dice CualGraf
              if (CualGraf==0)
                  %Marker #1
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf1(l==LM1);

                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'co','MarkerSize',6,'MarkerFaceColor',...
                                    'c','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal                  
                  %Marker #2
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf1(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'co','MarkerSize',6,'MarkerFaceColor',...
                                    'c','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal                   
              end            
              
          else %del if Cuantos >1
              dibujaOndasV(handles,Lgen,L,Factor,l,Graf1,Graf2,Graf3,'r',1);              
              
              %Dibujo el marker de tension total,nueva y vieja pues 
              %esta escogida en Graf1,2 y 3 pero solo el que diga  CualGraf
              if CualGraf==0
                  %Marker #1

                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf1(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'ro','MarkerSize',6,'MarkerFaceColor',...
                                    'r','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf1(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'ro','MarkerSize',6,'MarkerFaceColor',...
                                    'r','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              elseif CualGraf==1
                  %Marker #1

                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf2(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'co','MarkerSize',6,'MarkerFaceColor',...
                                    'c','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf2(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'co','MarkerSize',6,'MarkerFaceColor',...
                                    'c','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              elseif CualGraf==2
                  %Marker #1
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf3(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'yo','MarkerSize',6,'MarkerFaceColor',...
                                    'y','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf3(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'yo','MarkerSize',6,'MarkerFaceColor',...
                                    'y','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              end            
              
          end
      end
      
      if CheckI==1
          if Cuantos>1
              if CheckV==0
                  dibujaOndasV(handles,Lgen,L,Factor,l,Graf2,Graf2,Graf3,'y',1);
              else
                  dibujaOndasV(handles,Lgen,L,Factor,l,Graf2,Graf2,Graf3,'y',0);                  
              end

              %Dibujo el marker de corriente total pues esta escogida en Graf2
              %pero solo si asi lo dice CualGraf y esta activo CheckI
              if CualGraf==1
                  %Marker #1
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf2(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'yo','MarkerSize',6,'MarkerFaceColor',...
                                    'y','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2

                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf2(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'yo','MarkerSize',6,'MarkerFaceColor',...
                                    'y','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              end            
              
              
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Graf1,Graf2,Graf3,'r',1);              

              %Dibujo el marker de corriente total,nueva y vieja pues 
              %esta escogida en Graf1,2 y 3 pero solo el que diga  CualGraf
              if CualGraf==0
                  %Marker #1
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf1(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'ro','MarkerSize',6,'MarkerFaceColor',...
                                    'r','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf1(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'ro','MarkerSize',6,'MarkerFaceColor',...
                                    'r','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              elseif CualGraf==1
                  %Marker #1
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf2(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'co','MarkerSize',6,'MarkerFaceColor',...
                                    'c','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf2(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'co','MarkerSize',6,'MarkerFaceColor',...
                                    'c','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              elseif CualGraf==2
                  %Marker #1

                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf3(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'yo','MarkerSize',6,'MarkerFaceColor',...
                                    'y','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf3(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'yo','MarkerSize',6,'MarkerFaceColor',...
                                    'y','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              end            
              
          end          
      end
      
      if CheckP==1
          if Cuantos>1
              dibujaOndasV(handles,Lgen,L,Factor,l,Graf3,Graf2,Graf3,'r',0);                  
              
              %Dibujo el marker de potencia total pues esta escogida en Graf3
              %pero solo si asi lo dice CualGraf
              if CualGraf==2
                  %Marker #1

                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf3(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'ro','MarkerSize',6,'MarkerFaceColor',...
                                    'r','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf3(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'ro','MarkerSize',6,'MarkerFaceColor',...
                                    'r','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              end            
              
          else
              dibujaOndasV(handles,Lgen,L,Factor,l,Graf1,Graf2,Graf3,'r',1);              

              %Dibujo el marker de potencia total,nueva y vieja pues 
              %esta escogida en Graf1,2 y 3 pero solo el que diga  CualGraf
              if CualGraf==0
                  %Marker #1

                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf1(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'ro','MarkerSize',6,'MarkerFaceColor',...
                                    'r','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf1(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'ro','MarkerSize',6,'MarkerFaceColor',...
                                    'r','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              elseif CualGraf==1
                  %Marker #1

                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf2(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'co','MarkerSize',6,'MarkerFaceColor',...
                                    'c','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2
                  
                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf2(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'co','MarkerSize',6,'MarkerFaceColor',...
                                    'c','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              elseif CualGraf==2
                  %Marker #1

                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM1));
                   IndL=find(abs(l-LM1)==Min);
                   LM1=l(IndL);   %Este es el punto q buscabamos!
                   LM1=LM1(1);   %Por si acaso habia dos!
                   AM1=Graf3(l==LM1);
                  
                  set(handles.textM1A,'UserData',AM1);
                  set(handles.textM1A,'String',num2str(AM1));
                  plot(LM1,AM1,'yo','MarkerSize',6,'MarkerFaceColor',...
                                    'y','MarkerEdgeColor','k');
                  line([-Lgen L],[AM1 AM1]); %linea horizontal
                  line([LM1 LM1],[-4*Factor 4*Factor]); %linea horizontal 
                  %Marker #2

                   %Ahora me aseguro de que la longitud escogida este dentro de las
                   %posibles longitudes!
                   Min=min(abs(l-LM2));
                   IndL=find(abs(l-LM2)==Min);
                   LM2=l(IndL);   %Este es el punto q buscabamos!
                   LM2=LM2(1);   %Por si acaso habia dos!
                   AM2=Graf3(l==LM2);
                  
                  set(handles.textM2A,'UserData',AM2);
                  set(handles.textM2A,'String',num2str(AM2));
                  plot(LM2,AM2,'yo','MarkerSize',6,'MarkerFaceColor',...
                                    'y','MarkerEdgeColor','k');
                  line([-Lgen L],[AM2 AM2]); %linea horizontal
                  line([LM2 LM2],[-4*Factor 4*Factor]); %linea horizontal 
              end            

          end          
      end

  %y los markers los he dibujado dependiendo del numero de graficas, y basandome
  %en los valores de las graficas Graf1,Graf2,Graf3 en las coordenadas
  %que sean, y dependiendo de la grafica donde quiera poner los markers
  %que se obtiene de handles.frameGraf.'UserData'.GrafActual
  
  %Ahora calculo el delta de L y de amplitud!!
  LM1=get(handles.editM1L,'UserData');  
  LM2=get(handles.editM2L,'UserData');  
  AM1=get(handles.textM1A,'UserData');  
  AM2=get(handles.textM2A,'UserData');  
  DeltaML=abs(LM1-LM2);
  DeltaMA=abs(AM1-AM2);
  set(handles.textDeltaML,'UserData',DeltaML);
  set(handles.textDeltaML,'String',num2str(DeltaML));  
  set(handles.textDeltaMA,'UserData',DeltaMA);
  set(handles.textDeltaMA,'String',num2str(DeltaMA));  
      
  
%---- Fin de dibujar grafica alamcenada y markers nuevos!! --------------------------
