/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import common.IToJsonObject;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author juanangel
 */
public abstract class AbstractGameObject implements IGameObject, IToJsonObject{
    
    protected Position position;  
    int value;
    int lifes = 1;    
    int mode = 0;
        
    public AbstractGameObject(){
        position = new Position();
    }
    
    public AbstractGameObject(Position position){
        this.position = position;
    }
    
    public AbstractGameObject(Position position, int value, int life){
        this(position);
        this.value = value;
        this.lifes = life;
    }
    
    public AbstractGameObject(JSONObject obj){
        String type = obj.getString(IToJsonObject.TypeLabel);
        if (type.compareTo(getClass().getSimpleName()) != 0){
            throw new JSONException("Incompatible argument");
        }
        
        value = obj.getInt("value");
        lifes = obj.getInt("lifes");
        mode = obj.getInt("mode");
        
        position = new Position (obj.getJSONObject("position"));        
    }
    
    
    @Override
    public String toString(){
        return this.getClass().getSimpleName() + ", " + 
               position + 
               ", value: " + value + ", lifes: " + lifes + ", mode: " + mode;
    }
    
    @Override
    public JSONObject toJSONObject() {
        JSONObject jObj = new JSONObject();
        jObj.put(IToJsonObject.TypeLabel, this.getClass().getSimpleName());
        jObj.put("value", this.value);
        jObj.put("lifes", this.lifes);
        jObj.put("mode", this.mode);
        jObj.put("position", this.position.toJSONObject());
        return jObj;     
    }

    @Override
    public Position getPosition() {
        return position;
    }

    @Override
    public void setPosition(Position position) {
        this.position = position;       
    }
    
     @Override
    public Position moveToNextPosition(){
        return position;       
    }  

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public int getLifes() {
        return lifes;
    }

    @Override
    public void incLifes(int value) {
        lifes += value;
    }
    
    @Override
    public void setGameMode(int mode){
        this.mode = mode;
    }
   
    // p4, con junit
    public static double distance(Position p1, Position p2){
        
        if (p1 == null || p2 == null){
            return 0;
        }
        
        int dx = p1.x - p2.x;
        int dy = p1.y - p2.y;
        return Math.sqrt(dx*dx + dy*dy);        
    }
     
    
    // p4 con junit
    public static double getDistance(IGameObject jObj1, IGameObject jObj2){
        return distance(jObj1.getPosition(), jObj2.getPosition());        
    }
    
    // p7
        public static IGameObject getClosest(Position p, IGameObject jObjs []){

        if (jObjs == null || jObjs.length == 0){
            return null;
        }
                
        IGameObject closest = jObjs[0];
        double minD = distance(p, closest.getPosition());
        
        for(IGameObject b: jObjs){
            double d = distance(p, b.getPosition());
            if (d < minD){
                closest = b;
                minD = d;
            }
        }        
        return closest;        
    }       
    
    public static IGameObject getClosest(IGameObject jObj, IGameObject jObjs []) {
        return getClosest(jObj.getPosition(), jObjs);
    }
}
